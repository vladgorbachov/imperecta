--
-- PostgreSQL database dump
--

\restrict 5XxcEUzlgIedfZbhmbWRZ0gPYUb2izZQXN3JEhcJSCJ6be3RwJSXeati8bOWqi9

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alembic_meta; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA alembic_meta;


ALTER SCHEMA alembic_meta OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: alembic_meta; Owner: postgres
--

CREATE TABLE alembic_meta.alembic_version (
    version_num character varying(255) NOT NULL
);


ALTER TABLE alembic_meta.alembic_version OWNER TO postgres;

--
-- Name: ai_chat_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_chat_messages (
    id bigint NOT NULL,
    session_id uuid NOT NULL,
    role character varying(10) NOT NULL,
    content text NOT NULL,
    tokens_used integer,
    model_used character varying(50),
    duration_ms integer,
    tool_calls jsonb,
    user_rating smallint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ai_chat_messages_user_rating_check CHECK (((user_rating >= 1) AND (user_rating <= 5)))
);


ALTER TABLE public.ai_chat_messages OWNER TO postgres;

--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ai_chat_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_chat_messages_id_seq OWNER TO postgres;

--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ai_chat_messages_id_seq OWNED BY public.ai_chat_messages.id;


--
-- Name: ai_chat_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_chat_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title character varying(300),
    context_type character varying(30) DEFAULT 'general'::character varying,
    context_id uuid,
    message_count integer DEFAULT 0,
    total_tokens integer DEFAULT 0,
    is_archived boolean DEFAULT false,
    last_message_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_chat_sessions OWNER TO postgres;

--
-- Name: alert_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alert_events (
    id bigint NOT NULL,
    alert_id uuid NOT NULL,
    listing_id uuid,
    fact_price_id bigint,
    old_value numeric(12,2),
    new_value numeric(12,2),
    change_pct numeric(8,4),
    message text NOT NULL,
    severity character varying(10) DEFAULT 'medium'::character varying,
    ai_explanation text,
    ai_recommendation text,
    ai_recommended_price numeric(12,2),
    ai_confidence numeric(3,2),
    sent_via character varying(20),
    delivered_at timestamp with time zone,
    read_at timestamp with time zone,
    triggered_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_events OWNER TO postgres;

--
-- Name: alert_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.alert_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alert_events_id_seq OWNER TO postgres;

--
-- Name: alert_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.alert_events_id_seq OWNED BY public.alert_events.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid,
    listing_id uuid,
    marketplace_id uuid,
    category_id uuid,
    country_code character varying(2),
    alert_type character varying(30) NOT NULL,
    threshold_pct numeric(5,2),
    threshold_value numeric(12,2),
    channel character varying(20) DEFAULT 'email'::character varying,
    webhook_url text,
    cooldown_minutes integer DEFAULT 60,
    last_triggered_at timestamp with time zone,
    trigger_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alerts OWNER TO postgres;

--
-- Name: api_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_logs (
    id bigint NOT NULL,
    service character varying(50) NOT NULL,
    endpoint character varying(500),
    method character varying(10) DEFAULT 'GET'::character varying,
    status character varying(20) NOT NULL,
    status_code smallint,
    duration_ms integer,
    tokens_used integer,
    request_size_bytes integer,
    response_size_bytes integer,
    error_message text,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT api_logs_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'error'::character varying, 'timeout'::character varying, 'rate_limited'::character varying])::text[])))
);


ALTER TABLE public.api_logs OWNER TO postgres;

--
-- Name: api_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_logs_id_seq OWNER TO postgres;

--
-- Name: api_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_logs_id_seq OWNED BY public.api_logs.id;


--
-- Name: data_exports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_exports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    export_type character varying(30) NOT NULL,
    tables_included character varying(50)[] NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb,
    row_count integer,
    file_size_bytes bigint,
    file_url text,
    expires_at timestamp with time zone,
    status character varying(20) DEFAULT 'pending'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    CONSTRAINT data_exports_export_type_check CHECK (((export_type)::text = ANY ((ARRAY['csv'::character varying, 'xlsx'::character varying, 'json'::character varying, 'parquet'::character varying, 'pdf_report'::character varying, 'powerbi_dataset'::character varying, 'api_bulk'::character varying])::text[]))),
    CONSTRAINT data_exports_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'generating'::character varying, 'ready'::character varying, 'downloaded'::character varying, 'expired'::character varying, 'error'::character varying])::text[])))
);


ALTER TABLE public.data_exports OWNER TO postgres;

--
-- Name: digests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.digests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    period_type character varying(10) NOT NULL,
    digest_type character varying(30) DEFAULT 'market_overview'::character varying,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    title character varying(300),
    content_md text,
    summary_json jsonb,
    product_ids uuid[] DEFAULT '{}'::uuid[],
    marketplace_ids uuid[] DEFAULT '{}'::uuid[],
    country_codes character varying(2)[] DEFAULT '{}'::character varying[],
    sent_at timestamp with time zone,
    sent_via character varying(20),
    tokens_used integer,
    model_used character varying(50),
    generation_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.digests OWNER TO postgres;

--
-- Name: dim_brand; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_brand (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    name_normalized character varying(200) NOT NULL,
    country_code character varying(2),
    website_url text,
    logo_url text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dim_brand OWNER TO postgres;

--
-- Name: dim_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_category (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    name_en character varying(200),
    slug character varying(200) NOT NULL,
    parent_id uuid,
    level smallint DEFAULT 1 NOT NULL,
    path text NOT NULL,
    hs_code_prefix character varying(10),
    icon character varying(50),
    is_active boolean DEFAULT true,
    product_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dim_category OWNER TO postgres;

--
-- Name: dim_country; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_country (
    country_code character varying(2) NOT NULL,
    name character varying(100) NOT NULL,
    name_local character varying(100),
    region character varying(30) NOT NULL,
    subregion character varying(50),
    currency_code character varying(3) NOT NULL,
    vat_rate_std numeric(5,2),
    vat_rate_reduced numeric(5,2),
    ecommerce_market_size_eur bigint,
    population bigint,
    is_active boolean DEFAULT true,
    CONSTRAINT dim_country_region_check CHECK (((region)::text = ANY ((ARRAY['CIS'::character varying, 'EU'::character varying, 'EFTA'::character varying, 'Balkans'::character varying, 'Caucasus'::character varying, 'Central_Asia'::character varying, 'Turkey'::character varying, 'Other'::character varying])::text[])))
);


ALTER TABLE public.dim_country OWNER TO postgres;

--
-- Name: dim_currency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_currency (
    currency_code character varying(3) NOT NULL,
    name character varying(50) NOT NULL,
    symbol character varying(5) NOT NULL,
    decimal_places smallint DEFAULT 2,
    is_active boolean DEFAULT true
);


ALTER TABLE public.dim_currency OWNER TO postgres;

--
-- Name: dim_date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_date (
    date_id integer NOT NULL,
    full_date date NOT NULL,
    year smallint NOT NULL,
    quarter smallint NOT NULL,
    month smallint NOT NULL,
    month_name character varying(20) NOT NULL,
    week_iso smallint NOT NULL,
    day_of_month smallint NOT NULL,
    day_of_week smallint NOT NULL,
    day_name character varying(15) NOT NULL,
    is_weekend boolean NOT NULL,
    is_last_day_of_month boolean NOT NULL,
    fiscal_year smallint,
    fiscal_quarter smallint,
    CONSTRAINT ck_dim_date_month CHECK (((month >= 1) AND (month <= 12))),
    CONSTRAINT ck_dim_date_quarter CHECK (((quarter >= 1) AND (quarter <= 4)))
);


ALTER TABLE public.dim_date OWNER TO postgres;

--
-- Name: dim_marketplace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_marketplace (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    marketplace_code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    source_type character varying(30) NOT NULL,
    country_code character varying(2) NOT NULL,
    operates_in character varying(2)[] DEFAULT '{}'::character varying[],
    domain character varying(255) NOT NULL,
    base_url text NOT NULL,
    api_available boolean DEFAULT false,
    api_type character varying(30),
    scraper_type character varying(30) DEFAULT 'web_api'::character varying,
    currency_code character varying(3) NOT NULL,
    locale character varying(10),
    is_active boolean DEFAULT true,
    reliability_score numeric(3,2) DEFAULT 0.00,
    avg_response_ms integer,
    last_scrape_at timestamp with time zone,
    last_scrape_status character varying(20),
    logo_url text,
    monthly_visits bigint,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    product_quota integer DEFAULT 0,
    products_in_pool integer DEFAULT 0,
    requires_js boolean DEFAULT false,
    rate_limit_delay numeric(4,1) DEFAULT 2.0,
    custom_product_link_selector text,
    custom_next_page_selector text,
    custom_price_selector text,
    custom_title_selector text,
    last_discovery_at timestamp with time zone,
    last_discovery_status character varying(20),
    last_discovery_products_found integer DEFAULT 0,
    discovery_error_count integer DEFAULT 0,
    CONSTRAINT dim_marketplace_scraper_type_check CHECK (((scraper_type)::text = ANY ((ARRAY['web_api'::character varying, 'playwright'::character varying, 'httpx'::character varying, 'api_official'::character varying, 'rss'::character varying, 'feed'::character varying])::text[]))),
    CONSTRAINT dim_marketplace_source_type_check CHECK (((source_type)::text = ANY ((ARRAY['marketplace'::character varying, 'price_aggregator'::character varying, 'direct_retail'::character varying, 'classified'::character varying, 'b2b_platform'::character varying, 'brand_store'::character varying])::text[])))
);


ALTER TABLE public.dim_marketplace OWNER TO postgres;

--
-- Name: dim_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_product (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(500) NOT NULL,
    name_normalized character varying(500) NOT NULL,
    sku_universal character varying(100),
    mpn character varying(100),
    category_id uuid,
    brand_id uuid,
    attributes jsonb DEFAULT '{}'::jsonb,
    image_url text,
    image_urls text[] DEFAULT '{}'::text[],
    hs_code character varying(12),
    weight_kg numeric(10,3),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dim_product OWNER TO postgres;

--
-- Name: dim_seller; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dim_seller (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(300) NOT NULL,
    name_normalized character varying(300) NOT NULL,
    marketplace_id uuid NOT NULL,
    external_seller_id character varying(200),
    seller_type character varying(30) DEFAULT 'third_party'::character varying,
    store_url text,
    rating numeric(3,2),
    review_count integer,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT dim_seller_seller_type_check CHECK (((seller_type)::text = ANY ((ARRAY['first_party'::character varying, 'third_party'::character varying, 'brand_official'::character varying, 'unknown'::character varying])::text[])))
);


ALTER TABLE public.dim_seller OWNER TO postgres;

--
-- Name: fact_commodity_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_commodity_price (
    id bigint NOT NULL,
    date_id integer NOT NULL,
    symbol character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    commodity_type character varying(20) NOT NULL,
    price_usd numeric(12,4) NOT NULL,
    price_eur numeric(12,4),
    change_24h_pct numeric(8,4),
    change_7d_pct numeric(8,4),
    unit character varying(20) NOT NULL,
    source character varying(30) NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_commodity_source CHECK (((source)::text = ANY ((ARRAY['goldapi'::character varying, 'alpha_vantage'::character varying, 'eia'::character varying, 'custom'::character varying])::text[]))),
    CONSTRAINT ck_commodity_type CHECK (((commodity_type)::text = ANY ((ARRAY['metal'::character varying, 'energy'::character varying, 'agricultural'::character varying])::text[])))
);


ALTER TABLE public.fact_commodity_price OWNER TO postgres;

--
-- Name: fact_commodity_price_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_commodity_price ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fact_commodity_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fact_crypto_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_crypto_price (
    id bigint NOT NULL,
    date_id integer NOT NULL,
    symbol character varying(20) NOT NULL,
    name character varying(100),
    price_usd numeric(18,8) NOT NULL,
    price_eur numeric(18,8),
    market_cap_usd numeric(20,2),
    volume_24h_usd numeric(20,2),
    change_1h_pct numeric(8,4),
    change_24h_pct numeric(8,4),
    change_7d_pct numeric(8,4),
    high_24h_usd numeric(18,8),
    low_24h_usd numeric(18,8),
    circulating_supply numeric(20,2),
    total_supply numeric(20,2),
    source character varying(30) NOT NULL,
    rank smallint,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_crypto_source CHECK (((source)::text = ANY ((ARRAY['binance'::character varying, 'coingecko'::character varying, 'coinmarketcap'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.fact_crypto_price OWNER TO postgres;

--
-- Name: fact_crypto_price_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_crypto_price ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fact_crypto_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fact_currency_rate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_currency_rate (
    id bigint NOT NULL,
    date_id integer NOT NULL,
    currency_code character varying(3) NOT NULL,
    rate_to_eur numeric(18,8) NOT NULL,
    rate_to_usd numeric(18,8) NOT NULL,
    source character varying(30) NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT fact_currency_rate_source_check CHECK (((source)::text = ANY ((ARRAY['ecb'::character varying, 'cbr'::character varying, 'nbu'::character varying, 'nbk'::character varying, 'nbb'::character varying, 'cbu'::character varying, 'nbg'::character varying, 'cba'::character varying, 'cbar'::character varying, 'openexchangerates'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.fact_currency_rate OWNER TO postgres;

--
-- Name: fact_currency_rate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fact_currency_rate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fact_currency_rate_id_seq OWNER TO postgres;

--
-- Name: fact_currency_rate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fact_currency_rate_id_seq OWNED BY public.fact_currency_rate.id;


--
-- Name: fact_fuel_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_fuel_price (
    id bigint NOT NULL,
    date_id integer NOT NULL,
    country_code character varying(2) NOT NULL,
    fuel_type character varying(20) NOT NULL,
    price_local numeric(8,4) NOT NULL,
    currency_code character varying(3) NOT NULL,
    price_eur numeric(8,4),
    change_week_pct numeric(8,4),
    change_month_pct numeric(8,4),
    source character varying(50) NOT NULL,
    fetched_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_fuel_type CHECK (((fuel_type)::text = ANY ((ARRAY['gasoline_92'::character varying, 'gasoline_95'::character varying, 'gasoline_98'::character varying, 'gasoline_100'::character varying, 'diesel'::character varying, 'diesel_premium'::character varying, 'lpg'::character varying, 'cng'::character varying, 'electricity'::character varying])::text[])))
);


ALTER TABLE public.fact_fuel_price OWNER TO postgres;

--
-- Name: fact_fuel_price_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_fuel_price ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fact_fuel_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fact_listing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_listing (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    product_id uuid NOT NULL,
    marketplace_id uuid NOT NULL,
    seller_id uuid,
    external_url text NOT NULL,
    external_id character varying(200),
    external_name character varying(500),
    last_price numeric(12,2),
    last_price_eur numeric(12,2),
    last_original_price numeric(12,2),
    last_currency_code character varying(3),
    last_in_stock boolean,
    last_rating numeric(3,2),
    last_review_count integer,
    last_checked_at timestamp with time zone,
    scraper_type character varying(30) DEFAULT 'web_api'::character varying,
    scraper_config jsonb DEFAULT '{}'::jsonb,
    scrape_interval_minutes integer DEFAULT 360,
    is_active boolean DEFAULT true,
    consecutive_errors integer DEFAULT 0,
    last_error text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    url_hash character varying(64)
);


ALTER TABLE public.fact_listing OWNER TO postgres;

--
-- Name: fact_price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
)
PARTITION BY RANGE (date_id);


ALTER TABLE public.fact_price OWNER TO postgres;

--
-- Name: fact_price_202601; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202601 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202601 OWNER TO postgres;

--
-- Name: fact_price_202602; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202602 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202602 OWNER TO postgres;

--
-- Name: fact_price_202603; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202603 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202603 OWNER TO postgres;

--
-- Name: fact_price_202604; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202604 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202604 OWNER TO postgres;

--
-- Name: fact_price_202605; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202605 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202605 OWNER TO postgres;

--
-- Name: fact_price_202606; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202606 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202606 OWNER TO postgres;

--
-- Name: fact_price_202607; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202607 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202607 OWNER TO postgres;

--
-- Name: fact_price_202608; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202608 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202608 OWNER TO postgres;

--
-- Name: fact_price_202609; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202609 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202609 OWNER TO postgres;

--
-- Name: fact_price_202610; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202610 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202610 OWNER TO postgres;

--
-- Name: fact_price_202611; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202611 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202611 OWNER TO postgres;

--
-- Name: fact_price_202612; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_price_202612 (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    price numeric(12,2) NOT NULL,
    original_price numeric(12,2),
    currency_code character varying(3) NOT NULL,
    price_eur numeric(12,2),
    discount_pct numeric(5,2),
    price_change_pct numeric(8,4),
    in_stock boolean DEFAULT true,
    delivery_days smallint,
    delivery_cost numeric(8,2),
    seller_name character varying(300),
    promo_label character varying(300),
    is_promoted boolean DEFAULT false,
    promo_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    scrape_job_id uuid
);


ALTER TABLE public.fact_price_202612 OWNER TO postgres;

--
-- Name: fact_price_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_price ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.fact_price_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: fact_promo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_promo (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    listing_id uuid,
    marketplace_id uuid NOT NULL,
    start_date_id integer NOT NULL,
    end_date_id integer,
    promo_type character varying(30) NOT NULL,
    promo_name character varying(300),
    discount_pct numeric(5,2),
    discount_amount numeric(12,2),
    currency_code character varying(3),
    is_marketplace_wide boolean DEFAULT false,
    category_id uuid,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT fact_promo_promo_type_check CHECK (((promo_type)::text = ANY ((ARRAY['flash_sale'::character varying, 'seasonal'::character varying, 'clearance'::character varying, 'bundle'::character varying, 'coupon'::character varying, 'loyalty'::character varying, 'marketplace_campaign'::character varying, 'black_friday'::character varying, 'singles_day'::character varying, 'new_year'::character varying, 'other'::character varying])::text[])))
);


ALTER TABLE public.fact_promo OWNER TO postgres;

--
-- Name: fact_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_review (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    rating_avg numeric(3,2),
    review_count integer DEFAULT 0 NOT NULL,
    rating_1_count integer DEFAULT 0,
    rating_2_count integer DEFAULT 0,
    rating_3_count integer DEFAULT 0,
    rating_4_count integer DEFAULT 0,
    rating_5_count integer DEFAULT 0,
    sentiment_score numeric(4,3),
    sentiment_summary text,
    new_reviews_24h integer DEFAULT 0,
    scraped_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fact_review OWNER TO postgres;

--
-- Name: fact_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fact_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fact_review_id_seq OWNER TO postgres;

--
-- Name: fact_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fact_review_id_seq OWNED BY public.fact_review.id;


--
-- Name: fact_search_trend; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_search_trend (
    id bigint NOT NULL,
    date_id integer NOT NULL,
    country_code character varying(2) NOT NULL,
    keyword character varying(300) NOT NULL,
    keyword_normalized character varying(300) NOT NULL,
    trend_index smallint NOT NULL,
    search_volume integer,
    source character varying(30) NOT NULL,
    category_id uuid,
    related_product_id uuid,
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT fact_search_trend_source_check CHECK (((source)::text = ANY ((ARRAY['google_trends'::character varying, 'ozon_trends'::character varying, 'wb_trends'::character varying, 'kaspi_trends'::character varying, 'amazon_trends'::character varying, 'allegro_trends'::character varying, 'custom'::character varying])::text[])))
);


ALTER TABLE public.fact_search_trend OWNER TO postgres;

--
-- Name: fact_search_trend_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fact_search_trend_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fact_search_trend_id_seq OWNER TO postgres;

--
-- Name: fact_search_trend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fact_search_trend_id_seq OWNED BY public.fact_search_trend.id;


--
-- Name: fact_stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_stock (
    id bigint NOT NULL,
    listing_id uuid NOT NULL,
    date_id integer NOT NULL,
    in_stock boolean NOT NULL,
    stock_quantity integer,
    stock_status character varying(30),
    delivery_days_min smallint,
    delivery_days_max smallint,
    delivery_cost numeric(8,2),
    delivery_type character varying(30),
    scraped_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.fact_stock OWNER TO postgres;

--
-- Name: fact_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fact_stock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fact_stock_id_seq OWNER TO postgres;

--
-- Name: fact_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fact_stock_id_seq OWNED BY public.fact_stock.id;


--
-- Name: fact_tariff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fact_tariff (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hs_code character varying(12) NOT NULL,
    origin_country character varying(2) NOT NULL,
    destination_country character varying(2) NOT NULL,
    duty_pct numeric(6,3) NOT NULL,
    vat_pct numeric(5,2),
    excise_pct numeric(5,2),
    trade_agreement character varying(100),
    effective_from date NOT NULL,
    effective_to date,
    source character varying(100),
    source_url text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.fact_tariff OWNER TO postgres;

--
-- Name: mv_daily_price_summary; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.mv_daily_price_summary AS
 SELECT fp.date_id,
    fl.product_id,
    fl.marketplace_id,
    dp.category_id,
    dp.brand_id,
    dm.country_code,
    count(DISTINCT fl.id) AS listing_count,
    min(fp.price_eur) AS min_price_eur,
    max(fp.price_eur) AS max_price_eur,
    (avg(fp.price_eur))::numeric(12,2) AS avg_price_eur,
    percentile_cont((0.5)::double precision) WITHIN GROUP (ORDER BY ((fp.price_eur)::double precision)) AS median_price_eur,
    count(*) FILTER (WHERE (fp.in_stock = true)) AS in_stock_count,
    count(*) FILTER (WHERE (fp.in_stock = false)) AS out_of_stock_count,
    count(*) FILTER (WHERE (fp.is_promoted = true)) AS promoted_count,
    avg(fp.discount_pct) FILTER (WHERE (fp.discount_pct > (0)::numeric)) AS avg_discount_pct
   FROM (((public.fact_price fp
     JOIN public.fact_listing fl ON ((fp.listing_id = fl.id)))
     JOIN public.dim_product dp ON ((fl.product_id = dp.id)))
     JOIN public.dim_marketplace dm ON ((fl.marketplace_id = dm.id)))
  GROUP BY fp.date_id, fl.product_id, fl.marketplace_id, dp.category_id, dp.brand_id, dm.country_code
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_daily_price_summary OWNER TO postgres;

--
-- Name: scrape_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scrape_logs (
    id bigint NOT NULL,
    scrape_job_id uuid,
    listing_id uuid NOT NULL,
    marketplace_id uuid NOT NULL,
    status character varying(50) NOT NULL,
    url text NOT NULL,
    price_found numeric(12,2),
    in_stock_found boolean,
    duration_ms integer,
    response_code smallint,
    proxy_used character varying(100),
    scraper_type character varying(30),
    error_message text,
    error_category character varying(30),
    retry_count smallint DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_scrape_logs_status CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'error'::character varying, 'timeout'::character varying, 'blocked'::character varying, 'captcha'::character varying, 'not_found'::character varying, 'price_not_found'::character varying, 'parse_error'::character varying, 'missing_critical_data'::character varying, 'technical_error'::character varying])::text[]))),
    CONSTRAINT scrape_logs_status_check CHECK (((status)::text = ANY ((ARRAY['success'::character varying, 'error'::character varying, 'timeout'::character varying, 'blocked'::character varying, 'captcha'::character varying, 'not_found'::character varying, 'price_not_found'::character varying, 'parse_error'::character varying, 'missing_critical_data'::character varying, 'technical_error'::character varying])::text[])))
);


ALTER TABLE public.scrape_logs OWNER TO postgres;

--
-- Name: mv_marketplace_health; Type: MATERIALIZED VIEW; Schema: public; Owner: postgres
--

CREATE MATERIALIZED VIEW public.mv_marketplace_health AS
 SELECT dm.id AS marketplace_id,
    dm.marketplace_code,
    dm.name,
    dm.country_code,
    count(DISTINCT fl.id) AS active_listings,
    count(DISTINCT sl.id) FILTER (WHERE (sl.created_at > (now() - '24:00:00'::interval))) AS scrapes_24h,
    count(DISTINCT sl.id) FILTER (WHERE (((sl.status)::text = 'success'::text) AND (sl.created_at > (now() - '24:00:00'::interval)))) AS success_24h,
    count(DISTINCT sl.id) FILTER (WHERE (((sl.status)::text = 'error'::text) AND (sl.created_at > (now() - '24:00:00'::interval)))) AS errors_24h,
        CASE
            WHEN (count(DISTINCT sl.id) FILTER (WHERE (sl.created_at > (now() - '24:00:00'::interval))) = 0) THEN (0)::numeric
            ELSE ((count(DISTINCT sl.id) FILTER (WHERE (((sl.status)::text = 'success'::text) AND (sl.created_at > (now() - '24:00:00'::interval)))))::numeric / (NULLIF(count(DISTINCT sl.id) FILTER (WHERE (sl.created_at > (now() - '24:00:00'::interval))), 0))::numeric)
        END AS success_rate_24h,
    avg(sl.duration_ms) FILTER (WHERE (sl.created_at > (now() - '24:00:00'::interval))) AS avg_duration_ms_24h
   FROM ((public.dim_marketplace dm
     LEFT JOIN public.fact_listing fl ON (((dm.id = fl.marketplace_id) AND (fl.is_active = true))))
     LEFT JOIN public.scrape_logs sl ON ((dm.id = sl.marketplace_id)))
  GROUP BY dm.id, dm.marketplace_code, dm.name, dm.country_code
  WITH NO DATA;


ALTER MATERIALIZED VIEW public.mv_marketplace_health OWNER TO postgres;

--
-- Name: scrape_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scrape_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    job_type character varying(30) NOT NULL,
    marketplace_id uuid,
    status character varying(20) DEFAULT 'pending'::character varying,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    duration_ms integer,
    total_listings integer DEFAULT 0,
    successful integer DEFAULT 0,
    failed integer DEFAULT 0,
    skipped integer DEFAULT 0,
    config jsonb DEFAULT '{}'::jsonb,
    triggered_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT scrape_jobs_job_type_check CHECK (((job_type)::text = ANY ((ARRAY['scheduled'::character varying, 'manual'::character varying, 'retry'::character varying, 'backfill'::character varying, 'discovery'::character varying])::text[]))),
    CONSTRAINT scrape_jobs_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.scrape_jobs OWNER TO postgres;

--
-- Name: scrape_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.scrape_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scrape_logs_id_seq OWNER TO postgres;

--
-- Name: scrape_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.scrape_logs_id_seq OWNED BY public.scrape_logs.id;


--
-- Name: user_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    product_id uuid NOT NULL,
    custom_name character varying(500),
    custom_sku character varying(100),
    target_price numeric(12,2),
    cost_price numeric(12,2),
    currency_code character varying(3) DEFAULT 'EUR'::character varying,
    notes text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_products OWNER TO postgres;

--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    payment_provider character varying(30),
    external_id character varying(255),
    amount_cents integer,
    currency_code character varying(3) DEFAULT 'EUR'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT user_subscriptions_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'cancelled'::character varying, 'expired'::character varying, 'past_due'::character varying])::text[])))
);


ALTER TABLE public.user_subscriptions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(100),
    company_name character varying(200),
    plan character varying(20) DEFAULT 'trial'::character varying,
    trial_ends_at timestamp with time zone,
    language character varying(5) DEFAULT 'en'::character varying,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    ai_tone character varying(20) DEFAULT 'balanced'::character varying,
    default_currency character varying(3) DEFAULT 'EUR'::character varying,
    telegram_chat_id bigint,
    telegram_link_code character varying(20),
    telegram_username character varying(100),
    is_superuser boolean DEFAULT false,
    force_password_change boolean DEFAULT false,
    is_active boolean DEFAULT true,
    avatar_url text,
    last_login_at timestamp with time zone,
    last_login_ip inet,
    login_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT ck_users_plan CHECK (((plan)::text = ANY ((ARRAY['trial'::character varying, 'starter'::character varying, 'business'::character varying, 'pro'::character varying, 'enterprise'::character varying])::text[]))),
    CONSTRAINT users_ai_tone_check CHECK (((ai_tone)::text = ANY ((ARRAY['concise'::character varying, 'balanced'::character varying, 'detailed'::character varying])::text[]))),
    CONSTRAINT users_plan_check CHECK (((plan)::text = ANY (ARRAY[('trial'::character varying)::text, ('starter'::character varying)::text, ('business'::character varying)::text, ('pro'::character varying)::text, ('enterprise'::character varying)::text])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: fact_price_202601; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202601 FOR VALUES FROM (20260101) TO (20260201);


--
-- Name: fact_price_202602; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202602 FOR VALUES FROM (20260201) TO (20260301);


--
-- Name: fact_price_202603; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202603 FOR VALUES FROM (20260301) TO (20260401);


--
-- Name: fact_price_202604; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202604 FOR VALUES FROM (20260401) TO (20260501);


--
-- Name: fact_price_202605; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202605 FOR VALUES FROM (20260501) TO (20260601);


--
-- Name: fact_price_202606; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202606 FOR VALUES FROM (20260601) TO (20260701);


--
-- Name: fact_price_202607; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202607 FOR VALUES FROM (20260701) TO (20260801);


--
-- Name: fact_price_202608; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202608 FOR VALUES FROM (20260801) TO (20260901);


--
-- Name: fact_price_202609; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202609 FOR VALUES FROM (20260901) TO (20261001);


--
-- Name: fact_price_202610; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202610 FOR VALUES FROM (20261001) TO (20261101);


--
-- Name: fact_price_202611; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202611 FOR VALUES FROM (20261101) TO (20261201);


--
-- Name: fact_price_202612; Type: TABLE ATTACH; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price ATTACH PARTITION public.fact_price_202612 FOR VALUES FROM (20261201) TO (20270101);


--
-- Name: ai_chat_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_messages ALTER COLUMN id SET DEFAULT nextval('public.ai_chat_messages_id_seq'::regclass);


--
-- Name: alert_events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_events ALTER COLUMN id SET DEFAULT nextval('public.alert_events_id_seq'::regclass);


--
-- Name: api_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_logs ALTER COLUMN id SET DEFAULT nextval('public.api_logs_id_seq'::regclass);


--
-- Name: fact_currency_rate id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_currency_rate ALTER COLUMN id SET DEFAULT nextval('public.fact_currency_rate_id_seq'::regclass);


--
-- Name: fact_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_review ALTER COLUMN id SET DEFAULT nextval('public.fact_review_id_seq'::regclass);


--
-- Name: fact_search_trend id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend ALTER COLUMN id SET DEFAULT nextval('public.fact_search_trend_id_seq'::regclass);


--
-- Name: fact_stock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_stock ALTER COLUMN id SET DEFAULT nextval('public.fact_stock_id_seq'::regclass);


--
-- Name: scrape_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_logs ALTER COLUMN id SET DEFAULT nextval('public.scrape_logs_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: alembic_meta; Owner: postgres
--

COPY alembic_meta.alembic_version (version_num) FROM stdin;
009_full_v2_schema_rebuild
\.


--
-- Data for Name: ai_chat_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_chat_messages (id, session_id, role, content, tokens_used, model_used, duration_ms, tool_calls, user_rating, created_at) FROM stdin;
\.


--
-- Data for Name: ai_chat_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_chat_sessions (id, user_id, title, context_type, context_id, message_count, total_tokens, is_archived, last_message_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alert_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alert_events (id, alert_id, listing_id, fact_price_id, old_value, new_value, change_pct, message, severity, ai_explanation, ai_recommendation, ai_recommended_price, ai_confidence, sent_via, delivered_at, read_at, triggered_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alerts (id, user_id, product_id, listing_id, marketplace_id, category_id, country_code, alert_type, threshold_pct, threshold_value, channel, webhook_url, cooldown_minutes, last_triggered_at, trigger_count, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_logs (id, service, endpoint, method, status, status_code, duration_ms, tokens_used, request_size_bytes, response_size_bytes, error_message, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: data_exports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_exports (id, user_id, export_type, tables_included, filters, row_count, file_size_bytes, file_url, expires_at, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: digests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.digests (id, user_id, period_type, digest_type, period_start, period_end, title, content_md, summary_json, product_ids, marketplace_ids, country_codes, sent_at, sent_via, tokens_used, model_used, generation_ms, created_at) FROM stdin;
\.


--
-- Data for Name: dim_brand; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_brand (id, name, slug, name_normalized, country_code, website_url, logo_url, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: dim_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_category (id, name, name_en, slug, parent_id, level, path, hs_code_prefix, icon, is_active, product_count, created_at) FROM stdin;
\.


--
-- Data for Name: dim_country; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_country (country_code, name, name_local, region, subregion, currency_code, vat_rate_std, vat_rate_reduced, ecommerce_market_size_eur, population, is_active) FROM stdin;
RU	Russia	Россия	CIS	\N	RUB	20.00	\N	\N	\N	t
KZ	Kazakhstan	Қазақстан	CIS	\N	KZT	12.00	\N	\N	\N	t
UA	Ukraine	Україна	CIS	\N	UAH	20.00	\N	\N	\N	t
BY	Belarus	Беларусь	CIS	\N	BYN	20.00	\N	\N	\N	t
UZ	Uzbekistan	Oʻzbekiston	Central_Asia	\N	UZS	12.00	\N	\N	\N	t
MD	Moldova	Moldova	CIS	\N	MDL	20.00	\N	\N	\N	t
GE	Georgia	საქართველო	Caucasus	\N	GEL	18.00	\N	\N	\N	t
AM	Armenia	Հայաստան	Caucasus	\N	AMD	20.00	\N	\N	\N	t
AZ	Azerbaijan	Azərbaycan	Caucasus	\N	AZN	18.00	\N	\N	\N	t
KG	Kyrgyzstan	Кыргызстан	Central_Asia	\N	KGS	12.00	\N	\N	\N	t
TJ	Tajikistan	Тоҷикистон	Central_Asia	\N	TJS	15.00	\N	\N	\N	t
DE	Germany	Deutschland	EU	\N	EUR	19.00	\N	\N	\N	t
PL	Poland	Polska	EU	\N	PLN	23.00	\N	\N	\N	t
FR	France	France	EU	\N	EUR	20.00	\N	\N	\N	t
NL	Netherlands	Nederland	EU	\N	EUR	21.00	\N	\N	\N	t
CZ	Czech Republic	Česko	EU	\N	CZK	21.00	\N	\N	\N	t
SK	Slovakia	Slovensko	EU	\N	EUR	20.00	\N	\N	\N	t
AT	Austria	Österreich	EU	\N	EUR	20.00	\N	\N	\N	t
LV	Latvia	Latvija	EU	\N	EUR	21.00	\N	\N	\N	t
LT	Lithuania	Lietuva	EU	\N	EUR	21.00	\N	\N	\N	t
EE	Estonia	Eesti	EU	\N	EUR	22.00	\N	\N	\N	t
RO	Romania	România	EU	\N	RON	19.00	\N	\N	\N	t
HU	Hungary	Magyarország	EU	\N	HUF	27.00	\N	\N	\N	t
BG	Bulgaria	България	EU	\N	BGN	20.00	\N	\N	\N	t
HR	Croatia	Hrvatska	EU	\N	EUR	25.00	\N	\N	\N	t
SI	Slovenia	Slovenija	EU	\N	EUR	22.00	\N	\N	\N	t
GR	Greece	Ελλάδα	EU	\N	EUR	24.00	\N	\N	\N	t
IT	Italy	Italia	EU	\N	EUR	22.00	\N	\N	\N	t
ES	Spain	España	EU	\N	EUR	21.00	\N	\N	\N	t
PT	Portugal	Portugal	EU	\N	EUR	23.00	\N	\N	\N	t
RS	Serbia	Србија	Balkans	\N	RSD	20.00	\N	\N	\N	t
BA	Bosnia and Herzegovina	Bosna i Hercegovina	Balkans	\N	BAM	17.00	\N	\N	\N	t
MK	North Macedonia	Северна Македонија	Balkans	\N	MKD	18.00	\N	\N	\N	t
ME	Montenegro	Crna Gora	Balkans	\N	EUR	21.00	\N	\N	\N	t
AL	Albania	Shqipëria	Balkans	\N	ALL	20.00	\N	\N	\N	t
TR	Turkey	Türkiye	Turkey	\N	TRY	20.00	\N	\N	\N	t
FI	Finland	Suomi	EU	\N	EUR	25.50	\N	\N	\N	t
SE	Sweden	Sverige	EU	\N	SEK	25.00	\N	\N	\N	t
DK	Denmark	Danmark	EU	\N	DKK	25.00	\N	\N	\N	t
NO	Norway	Norge	EFTA	\N	NOK	25.00	\N	\N	\N	t
UK	United Kingdom	United Kingdom	Other	\N	GBP	20.00	\N	\N	\N	t
CH	Switzerland	Schweiz	EFTA	\N	CHF	8.10	\N	\N	\N	t
BE	Belgium	België	EU	\N	EUR	21.00	\N	\N	\N	t
IE	Ireland	Éire	EU	\N	EUR	23.00	\N	\N	\N	t
\.


--
-- Data for Name: dim_currency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_currency (currency_code, name, symbol, decimal_places, is_active) FROM stdin;
EUR	Euro	€	2	t
USD	US Dollar	$	2	t
RUB	Russian Ruble	₽	2	t
UAH	Ukrainian Hryvnia	₴	2	t
KZT	Kazakh Tenge	₸	2	t
BYN	Belarusian Ruble	Br	2	t
UZS	Uzbek Sum	сўм	2	t
GEL	Georgian Lari	₾	2	t
AMD	Armenian Dram	֏	2	t
AZN	Azerbaijani Manat	₼	2	t
KGS	Kyrgyz Som	сом	2	t
TJS	Tajik Somoni	SM	2	t
MDL	Moldovan Leu	L	2	t
PLN	Polish Zloty	zł	2	t
CZK	Czech Koruna	Kč	2	t
HUF	Hungarian Forint	Ft	0	t
RON	Romanian Leu	lei	2	t
BGN	Bulgarian Lev	лв	2	t
HRK	Croatian Kuna	kn	2	t
RSD	Serbian Dinar	din	2	t
TRY	Turkish Lira	₺	2	t
GBP	British Pound	£	2	t
CHF	Swiss Franc	CHF	2	t
SEK	Swedish Krona	kr	2	t
NOK	Norwegian Krone	kr	2	t
DKK	Danish Krone	kr	2	t
ISK	Icelandic Krona	kr	0	t
BAM	Bosnia and Herzegovina Convertible Mark	KM	2	t
MKD	Macedonian Denar	ден	2	t
ALL	Albanian Lek	L	2	t
\.


--
-- Data for Name: dim_date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_date (date_id, full_date, year, quarter, month, month_name, week_iso, day_of_month, day_of_week, day_name, is_weekend, is_last_day_of_month, fiscal_year, fiscal_quarter) FROM stdin;
20240101	2024-01-01	2024	1	1	January	1	1	1	Monday	f	f	\N	\N
20240102	2024-01-02	2024	1	1	January	1	2	2	Tuesday	f	f	\N	\N
20240103	2024-01-03	2024	1	1	January	1	3	3	Wednesday	f	f	\N	\N
20240104	2024-01-04	2024	1	1	January	1	4	4	Thursday	f	f	\N	\N
20240105	2024-01-05	2024	1	1	January	1	5	5	Friday	f	f	\N	\N
20240106	2024-01-06	2024	1	1	January	1	6	6	Saturday	t	f	\N	\N
20240107	2024-01-07	2024	1	1	January	1	7	7	Sunday	t	f	\N	\N
20240108	2024-01-08	2024	1	1	January	2	8	1	Monday	f	f	\N	\N
20240109	2024-01-09	2024	1	1	January	2	9	2	Tuesday	f	f	\N	\N
20240110	2024-01-10	2024	1	1	January	2	10	3	Wednesday	f	f	\N	\N
20240111	2024-01-11	2024	1	1	January	2	11	4	Thursday	f	f	\N	\N
20240112	2024-01-12	2024	1	1	January	2	12	5	Friday	f	f	\N	\N
20240113	2024-01-13	2024	1	1	January	2	13	6	Saturday	t	f	\N	\N
20240114	2024-01-14	2024	1	1	January	2	14	7	Sunday	t	f	\N	\N
20240115	2024-01-15	2024	1	1	January	3	15	1	Monday	f	f	\N	\N
20240116	2024-01-16	2024	1	1	January	3	16	2	Tuesday	f	f	\N	\N
20240117	2024-01-17	2024	1	1	January	3	17	3	Wednesday	f	f	\N	\N
20240118	2024-01-18	2024	1	1	January	3	18	4	Thursday	f	f	\N	\N
20240119	2024-01-19	2024	1	1	January	3	19	5	Friday	f	f	\N	\N
20240120	2024-01-20	2024	1	1	January	3	20	6	Saturday	t	f	\N	\N
20240121	2024-01-21	2024	1	1	January	3	21	7	Sunday	t	f	\N	\N
20240122	2024-01-22	2024	1	1	January	4	22	1	Monday	f	f	\N	\N
20240123	2024-01-23	2024	1	1	January	4	23	2	Tuesday	f	f	\N	\N
20240124	2024-01-24	2024	1	1	January	4	24	3	Wednesday	f	f	\N	\N
20240125	2024-01-25	2024	1	1	January	4	25	4	Thursday	f	f	\N	\N
20240126	2024-01-26	2024	1	1	January	4	26	5	Friday	f	f	\N	\N
20240127	2024-01-27	2024	1	1	January	4	27	6	Saturday	t	f	\N	\N
20240128	2024-01-28	2024	1	1	January	4	28	7	Sunday	t	f	\N	\N
20240129	2024-01-29	2024	1	1	January	5	29	1	Monday	f	f	\N	\N
20240130	2024-01-30	2024	1	1	January	5	30	2	Tuesday	f	f	\N	\N
20240131	2024-01-31	2024	1	1	January	5	31	3	Wednesday	f	t	\N	\N
20240201	2024-02-01	2024	1	2	February	5	1	4	Thursday	f	f	\N	\N
20240202	2024-02-02	2024	1	2	February	5	2	5	Friday	f	f	\N	\N
20240203	2024-02-03	2024	1	2	February	5	3	6	Saturday	t	f	\N	\N
20240204	2024-02-04	2024	1	2	February	5	4	7	Sunday	t	f	\N	\N
20240205	2024-02-05	2024	1	2	February	6	5	1	Monday	f	f	\N	\N
20240206	2024-02-06	2024	1	2	February	6	6	2	Tuesday	f	f	\N	\N
20240207	2024-02-07	2024	1	2	February	6	7	3	Wednesday	f	f	\N	\N
20240208	2024-02-08	2024	1	2	February	6	8	4	Thursday	f	f	\N	\N
20240209	2024-02-09	2024	1	2	February	6	9	5	Friday	f	f	\N	\N
20240210	2024-02-10	2024	1	2	February	6	10	6	Saturday	t	f	\N	\N
20240211	2024-02-11	2024	1	2	February	6	11	7	Sunday	t	f	\N	\N
20240212	2024-02-12	2024	1	2	February	7	12	1	Monday	f	f	\N	\N
20240213	2024-02-13	2024	1	2	February	7	13	2	Tuesday	f	f	\N	\N
20240214	2024-02-14	2024	1	2	February	7	14	3	Wednesday	f	f	\N	\N
20240215	2024-02-15	2024	1	2	February	7	15	4	Thursday	f	f	\N	\N
20240216	2024-02-16	2024	1	2	February	7	16	5	Friday	f	f	\N	\N
20240217	2024-02-17	2024	1	2	February	7	17	6	Saturday	t	f	\N	\N
20240218	2024-02-18	2024	1	2	February	7	18	7	Sunday	t	f	\N	\N
20240219	2024-02-19	2024	1	2	February	8	19	1	Monday	f	f	\N	\N
20240220	2024-02-20	2024	1	2	February	8	20	2	Tuesday	f	f	\N	\N
20240221	2024-02-21	2024	1	2	February	8	21	3	Wednesday	f	f	\N	\N
20240222	2024-02-22	2024	1	2	February	8	22	4	Thursday	f	f	\N	\N
20240223	2024-02-23	2024	1	2	February	8	23	5	Friday	f	f	\N	\N
20240224	2024-02-24	2024	1	2	February	8	24	6	Saturday	t	f	\N	\N
20240225	2024-02-25	2024	1	2	February	8	25	7	Sunday	t	f	\N	\N
20240226	2024-02-26	2024	1	2	February	9	26	1	Monday	f	f	\N	\N
20240227	2024-02-27	2024	1	2	February	9	27	2	Tuesday	f	f	\N	\N
20240228	2024-02-28	2024	1	2	February	9	28	3	Wednesday	f	f	\N	\N
20240229	2024-02-29	2024	1	2	February	9	29	4	Thursday	f	t	\N	\N
20240301	2024-03-01	2024	1	3	March	9	1	5	Friday	f	f	\N	\N
20240302	2024-03-02	2024	1	3	March	9	2	6	Saturday	t	f	\N	\N
20240303	2024-03-03	2024	1	3	March	9	3	7	Sunday	t	f	\N	\N
20240304	2024-03-04	2024	1	3	March	10	4	1	Monday	f	f	\N	\N
20240305	2024-03-05	2024	1	3	March	10	5	2	Tuesday	f	f	\N	\N
20240306	2024-03-06	2024	1	3	March	10	6	3	Wednesday	f	f	\N	\N
20240307	2024-03-07	2024	1	3	March	10	7	4	Thursday	f	f	\N	\N
20240308	2024-03-08	2024	1	3	March	10	8	5	Friday	f	f	\N	\N
20240309	2024-03-09	2024	1	3	March	10	9	6	Saturday	t	f	\N	\N
20240310	2024-03-10	2024	1	3	March	10	10	7	Sunday	t	f	\N	\N
20240311	2024-03-11	2024	1	3	March	11	11	1	Monday	f	f	\N	\N
20240312	2024-03-12	2024	1	3	March	11	12	2	Tuesday	f	f	\N	\N
20240313	2024-03-13	2024	1	3	March	11	13	3	Wednesday	f	f	\N	\N
20240314	2024-03-14	2024	1	3	March	11	14	4	Thursday	f	f	\N	\N
20240315	2024-03-15	2024	1	3	March	11	15	5	Friday	f	f	\N	\N
20240316	2024-03-16	2024	1	3	March	11	16	6	Saturday	t	f	\N	\N
20240317	2024-03-17	2024	1	3	March	11	17	7	Sunday	t	f	\N	\N
20240318	2024-03-18	2024	1	3	March	12	18	1	Monday	f	f	\N	\N
20240319	2024-03-19	2024	1	3	March	12	19	2	Tuesday	f	f	\N	\N
20240320	2024-03-20	2024	1	3	March	12	20	3	Wednesday	f	f	\N	\N
20240321	2024-03-21	2024	1	3	March	12	21	4	Thursday	f	f	\N	\N
20240322	2024-03-22	2024	1	3	March	12	22	5	Friday	f	f	\N	\N
20240323	2024-03-23	2024	1	3	March	12	23	6	Saturday	t	f	\N	\N
20240324	2024-03-24	2024	1	3	March	12	24	7	Sunday	t	f	\N	\N
20240325	2024-03-25	2024	1	3	March	13	25	1	Monday	f	f	\N	\N
20240326	2024-03-26	2024	1	3	March	13	26	2	Tuesday	f	f	\N	\N
20240327	2024-03-27	2024	1	3	March	13	27	3	Wednesday	f	f	\N	\N
20240328	2024-03-28	2024	1	3	March	13	28	4	Thursday	f	f	\N	\N
20240329	2024-03-29	2024	1	3	March	13	29	5	Friday	f	f	\N	\N
20240330	2024-03-30	2024	1	3	March	13	30	6	Saturday	t	f	\N	\N
20240331	2024-03-31	2024	1	3	March	13	31	7	Sunday	t	t	\N	\N
20240401	2024-04-01	2024	2	4	April	14	1	1	Monday	f	f	\N	\N
20240402	2024-04-02	2024	2	4	April	14	2	2	Tuesday	f	f	\N	\N
20240403	2024-04-03	2024	2	4	April	14	3	3	Wednesday	f	f	\N	\N
20240404	2024-04-04	2024	2	4	April	14	4	4	Thursday	f	f	\N	\N
20240405	2024-04-05	2024	2	4	April	14	5	5	Friday	f	f	\N	\N
20240406	2024-04-06	2024	2	4	April	14	6	6	Saturday	t	f	\N	\N
20240407	2024-04-07	2024	2	4	April	14	7	7	Sunday	t	f	\N	\N
20240408	2024-04-08	2024	2	4	April	15	8	1	Monday	f	f	\N	\N
20240409	2024-04-09	2024	2	4	April	15	9	2	Tuesday	f	f	\N	\N
20240410	2024-04-10	2024	2	4	April	15	10	3	Wednesday	f	f	\N	\N
20240411	2024-04-11	2024	2	4	April	15	11	4	Thursday	f	f	\N	\N
20240412	2024-04-12	2024	2	4	April	15	12	5	Friday	f	f	\N	\N
20240413	2024-04-13	2024	2	4	April	15	13	6	Saturday	t	f	\N	\N
20240414	2024-04-14	2024	2	4	April	15	14	7	Sunday	t	f	\N	\N
20240415	2024-04-15	2024	2	4	April	16	15	1	Monday	f	f	\N	\N
20240416	2024-04-16	2024	2	4	April	16	16	2	Tuesday	f	f	\N	\N
20240417	2024-04-17	2024	2	4	April	16	17	3	Wednesday	f	f	\N	\N
20240418	2024-04-18	2024	2	4	April	16	18	4	Thursday	f	f	\N	\N
20240419	2024-04-19	2024	2	4	April	16	19	5	Friday	f	f	\N	\N
20240420	2024-04-20	2024	2	4	April	16	20	6	Saturday	t	f	\N	\N
20240421	2024-04-21	2024	2	4	April	16	21	7	Sunday	t	f	\N	\N
20240422	2024-04-22	2024	2	4	April	17	22	1	Monday	f	f	\N	\N
20240423	2024-04-23	2024	2	4	April	17	23	2	Tuesday	f	f	\N	\N
20240424	2024-04-24	2024	2	4	April	17	24	3	Wednesday	f	f	\N	\N
20240425	2024-04-25	2024	2	4	April	17	25	4	Thursday	f	f	\N	\N
20240426	2024-04-26	2024	2	4	April	17	26	5	Friday	f	f	\N	\N
20240427	2024-04-27	2024	2	4	April	17	27	6	Saturday	t	f	\N	\N
20240428	2024-04-28	2024	2	4	April	17	28	7	Sunday	t	f	\N	\N
20240429	2024-04-29	2024	2	4	April	18	29	1	Monday	f	f	\N	\N
20240430	2024-04-30	2024	2	4	April	18	30	2	Tuesday	f	t	\N	\N
20240501	2024-05-01	2024	2	5	May	18	1	3	Wednesday	f	f	\N	\N
20240502	2024-05-02	2024	2	5	May	18	2	4	Thursday	f	f	\N	\N
20240503	2024-05-03	2024	2	5	May	18	3	5	Friday	f	f	\N	\N
20240504	2024-05-04	2024	2	5	May	18	4	6	Saturday	t	f	\N	\N
20240505	2024-05-05	2024	2	5	May	18	5	7	Sunday	t	f	\N	\N
20240506	2024-05-06	2024	2	5	May	19	6	1	Monday	f	f	\N	\N
20240507	2024-05-07	2024	2	5	May	19	7	2	Tuesday	f	f	\N	\N
20240508	2024-05-08	2024	2	5	May	19	8	3	Wednesday	f	f	\N	\N
20240509	2024-05-09	2024	2	5	May	19	9	4	Thursday	f	f	\N	\N
20240510	2024-05-10	2024	2	5	May	19	10	5	Friday	f	f	\N	\N
20240511	2024-05-11	2024	2	5	May	19	11	6	Saturday	t	f	\N	\N
20240512	2024-05-12	2024	2	5	May	19	12	7	Sunday	t	f	\N	\N
20240513	2024-05-13	2024	2	5	May	20	13	1	Monday	f	f	\N	\N
20240514	2024-05-14	2024	2	5	May	20	14	2	Tuesday	f	f	\N	\N
20240515	2024-05-15	2024	2	5	May	20	15	3	Wednesday	f	f	\N	\N
20240516	2024-05-16	2024	2	5	May	20	16	4	Thursday	f	f	\N	\N
20240517	2024-05-17	2024	2	5	May	20	17	5	Friday	f	f	\N	\N
20240518	2024-05-18	2024	2	5	May	20	18	6	Saturday	t	f	\N	\N
20240519	2024-05-19	2024	2	5	May	20	19	7	Sunday	t	f	\N	\N
20240520	2024-05-20	2024	2	5	May	21	20	1	Monday	f	f	\N	\N
20240521	2024-05-21	2024	2	5	May	21	21	2	Tuesday	f	f	\N	\N
20240522	2024-05-22	2024	2	5	May	21	22	3	Wednesday	f	f	\N	\N
20240523	2024-05-23	2024	2	5	May	21	23	4	Thursday	f	f	\N	\N
20240524	2024-05-24	2024	2	5	May	21	24	5	Friday	f	f	\N	\N
20240525	2024-05-25	2024	2	5	May	21	25	6	Saturday	t	f	\N	\N
20240526	2024-05-26	2024	2	5	May	21	26	7	Sunday	t	f	\N	\N
20240527	2024-05-27	2024	2	5	May	22	27	1	Monday	f	f	\N	\N
20240528	2024-05-28	2024	2	5	May	22	28	2	Tuesday	f	f	\N	\N
20240529	2024-05-29	2024	2	5	May	22	29	3	Wednesday	f	f	\N	\N
20240530	2024-05-30	2024	2	5	May	22	30	4	Thursday	f	f	\N	\N
20240531	2024-05-31	2024	2	5	May	22	31	5	Friday	f	t	\N	\N
20240601	2024-06-01	2024	2	6	June	22	1	6	Saturday	t	f	\N	\N
20240602	2024-06-02	2024	2	6	June	22	2	7	Sunday	t	f	\N	\N
20240603	2024-06-03	2024	2	6	June	23	3	1	Monday	f	f	\N	\N
20240604	2024-06-04	2024	2	6	June	23	4	2	Tuesday	f	f	\N	\N
20240605	2024-06-05	2024	2	6	June	23	5	3	Wednesday	f	f	\N	\N
20240606	2024-06-06	2024	2	6	June	23	6	4	Thursday	f	f	\N	\N
20240607	2024-06-07	2024	2	6	June	23	7	5	Friday	f	f	\N	\N
20240608	2024-06-08	2024	2	6	June	23	8	6	Saturday	t	f	\N	\N
20240609	2024-06-09	2024	2	6	June	23	9	7	Sunday	t	f	\N	\N
20240610	2024-06-10	2024	2	6	June	24	10	1	Monday	f	f	\N	\N
20240611	2024-06-11	2024	2	6	June	24	11	2	Tuesday	f	f	\N	\N
20240612	2024-06-12	2024	2	6	June	24	12	3	Wednesday	f	f	\N	\N
20240613	2024-06-13	2024	2	6	June	24	13	4	Thursday	f	f	\N	\N
20240614	2024-06-14	2024	2	6	June	24	14	5	Friday	f	f	\N	\N
20240615	2024-06-15	2024	2	6	June	24	15	6	Saturday	t	f	\N	\N
20240616	2024-06-16	2024	2	6	June	24	16	7	Sunday	t	f	\N	\N
20240617	2024-06-17	2024	2	6	June	25	17	1	Monday	f	f	\N	\N
20240618	2024-06-18	2024	2	6	June	25	18	2	Tuesday	f	f	\N	\N
20240619	2024-06-19	2024	2	6	June	25	19	3	Wednesday	f	f	\N	\N
20240620	2024-06-20	2024	2	6	June	25	20	4	Thursday	f	f	\N	\N
20240621	2024-06-21	2024	2	6	June	25	21	5	Friday	f	f	\N	\N
20240622	2024-06-22	2024	2	6	June	25	22	6	Saturday	t	f	\N	\N
20240623	2024-06-23	2024	2	6	June	25	23	7	Sunday	t	f	\N	\N
20240624	2024-06-24	2024	2	6	June	26	24	1	Monday	f	f	\N	\N
20240625	2024-06-25	2024	2	6	June	26	25	2	Tuesday	f	f	\N	\N
20240626	2024-06-26	2024	2	6	June	26	26	3	Wednesday	f	f	\N	\N
20240627	2024-06-27	2024	2	6	June	26	27	4	Thursday	f	f	\N	\N
20240628	2024-06-28	2024	2	6	June	26	28	5	Friday	f	f	\N	\N
20240629	2024-06-29	2024	2	6	June	26	29	6	Saturday	t	f	\N	\N
20240630	2024-06-30	2024	2	6	June	26	30	7	Sunday	t	t	\N	\N
20240701	2024-07-01	2024	3	7	July	27	1	1	Monday	f	f	\N	\N
20240702	2024-07-02	2024	3	7	July	27	2	2	Tuesday	f	f	\N	\N
20240703	2024-07-03	2024	3	7	July	27	3	3	Wednesday	f	f	\N	\N
20240704	2024-07-04	2024	3	7	July	27	4	4	Thursday	f	f	\N	\N
20240705	2024-07-05	2024	3	7	July	27	5	5	Friday	f	f	\N	\N
20240706	2024-07-06	2024	3	7	July	27	6	6	Saturday	t	f	\N	\N
20240707	2024-07-07	2024	3	7	July	27	7	7	Sunday	t	f	\N	\N
20240708	2024-07-08	2024	3	7	July	28	8	1	Monday	f	f	\N	\N
20240709	2024-07-09	2024	3	7	July	28	9	2	Tuesday	f	f	\N	\N
20240710	2024-07-10	2024	3	7	July	28	10	3	Wednesday	f	f	\N	\N
20240711	2024-07-11	2024	3	7	July	28	11	4	Thursday	f	f	\N	\N
20240712	2024-07-12	2024	3	7	July	28	12	5	Friday	f	f	\N	\N
20240713	2024-07-13	2024	3	7	July	28	13	6	Saturday	t	f	\N	\N
20240714	2024-07-14	2024	3	7	July	28	14	7	Sunday	t	f	\N	\N
20240715	2024-07-15	2024	3	7	July	29	15	1	Monday	f	f	\N	\N
20240716	2024-07-16	2024	3	7	July	29	16	2	Tuesday	f	f	\N	\N
20240717	2024-07-17	2024	3	7	July	29	17	3	Wednesday	f	f	\N	\N
20240718	2024-07-18	2024	3	7	July	29	18	4	Thursday	f	f	\N	\N
20240719	2024-07-19	2024	3	7	July	29	19	5	Friday	f	f	\N	\N
20240720	2024-07-20	2024	3	7	July	29	20	6	Saturday	t	f	\N	\N
20240721	2024-07-21	2024	3	7	July	29	21	7	Sunday	t	f	\N	\N
20240722	2024-07-22	2024	3	7	July	30	22	1	Monday	f	f	\N	\N
20240723	2024-07-23	2024	3	7	July	30	23	2	Tuesday	f	f	\N	\N
20240724	2024-07-24	2024	3	7	July	30	24	3	Wednesday	f	f	\N	\N
20240725	2024-07-25	2024	3	7	July	30	25	4	Thursday	f	f	\N	\N
20240726	2024-07-26	2024	3	7	July	30	26	5	Friday	f	f	\N	\N
20240727	2024-07-27	2024	3	7	July	30	27	6	Saturday	t	f	\N	\N
20240728	2024-07-28	2024	3	7	July	30	28	7	Sunday	t	f	\N	\N
20240729	2024-07-29	2024	3	7	July	31	29	1	Monday	f	f	\N	\N
20240730	2024-07-30	2024	3	7	July	31	30	2	Tuesday	f	f	\N	\N
20240731	2024-07-31	2024	3	7	July	31	31	3	Wednesday	f	t	\N	\N
20240801	2024-08-01	2024	3	8	August	31	1	4	Thursday	f	f	\N	\N
20240802	2024-08-02	2024	3	8	August	31	2	5	Friday	f	f	\N	\N
20240803	2024-08-03	2024	3	8	August	31	3	6	Saturday	t	f	\N	\N
20240804	2024-08-04	2024	3	8	August	31	4	7	Sunday	t	f	\N	\N
20240805	2024-08-05	2024	3	8	August	32	5	1	Monday	f	f	\N	\N
20240806	2024-08-06	2024	3	8	August	32	6	2	Tuesday	f	f	\N	\N
20240807	2024-08-07	2024	3	8	August	32	7	3	Wednesday	f	f	\N	\N
20240808	2024-08-08	2024	3	8	August	32	8	4	Thursday	f	f	\N	\N
20240809	2024-08-09	2024	3	8	August	32	9	5	Friday	f	f	\N	\N
20240810	2024-08-10	2024	3	8	August	32	10	6	Saturday	t	f	\N	\N
20240811	2024-08-11	2024	3	8	August	32	11	7	Sunday	t	f	\N	\N
20240812	2024-08-12	2024	3	8	August	33	12	1	Monday	f	f	\N	\N
20240813	2024-08-13	2024	3	8	August	33	13	2	Tuesday	f	f	\N	\N
20240814	2024-08-14	2024	3	8	August	33	14	3	Wednesday	f	f	\N	\N
20240815	2024-08-15	2024	3	8	August	33	15	4	Thursday	f	f	\N	\N
20240816	2024-08-16	2024	3	8	August	33	16	5	Friday	f	f	\N	\N
20240817	2024-08-17	2024	3	8	August	33	17	6	Saturday	t	f	\N	\N
20240818	2024-08-18	2024	3	8	August	33	18	7	Sunday	t	f	\N	\N
20240819	2024-08-19	2024	3	8	August	34	19	1	Monday	f	f	\N	\N
20240820	2024-08-20	2024	3	8	August	34	20	2	Tuesday	f	f	\N	\N
20240821	2024-08-21	2024	3	8	August	34	21	3	Wednesday	f	f	\N	\N
20240822	2024-08-22	2024	3	8	August	34	22	4	Thursday	f	f	\N	\N
20240823	2024-08-23	2024	3	8	August	34	23	5	Friday	f	f	\N	\N
20240824	2024-08-24	2024	3	8	August	34	24	6	Saturday	t	f	\N	\N
20240825	2024-08-25	2024	3	8	August	34	25	7	Sunday	t	f	\N	\N
20240826	2024-08-26	2024	3	8	August	35	26	1	Monday	f	f	\N	\N
20240827	2024-08-27	2024	3	8	August	35	27	2	Tuesday	f	f	\N	\N
20240828	2024-08-28	2024	3	8	August	35	28	3	Wednesday	f	f	\N	\N
20240829	2024-08-29	2024	3	8	August	35	29	4	Thursday	f	f	\N	\N
20240830	2024-08-30	2024	3	8	August	35	30	5	Friday	f	f	\N	\N
20240831	2024-08-31	2024	3	8	August	35	31	6	Saturday	t	t	\N	\N
20240901	2024-09-01	2024	3	9	September	35	1	7	Sunday	t	f	\N	\N
20240902	2024-09-02	2024	3	9	September	36	2	1	Monday	f	f	\N	\N
20240903	2024-09-03	2024	3	9	September	36	3	2	Tuesday	f	f	\N	\N
20240904	2024-09-04	2024	3	9	September	36	4	3	Wednesday	f	f	\N	\N
20240905	2024-09-05	2024	3	9	September	36	5	4	Thursday	f	f	\N	\N
20240906	2024-09-06	2024	3	9	September	36	6	5	Friday	f	f	\N	\N
20240907	2024-09-07	2024	3	9	September	36	7	6	Saturday	t	f	\N	\N
20240908	2024-09-08	2024	3	9	September	36	8	7	Sunday	t	f	\N	\N
20240909	2024-09-09	2024	3	9	September	37	9	1	Monday	f	f	\N	\N
20240910	2024-09-10	2024	3	9	September	37	10	2	Tuesday	f	f	\N	\N
20240911	2024-09-11	2024	3	9	September	37	11	3	Wednesday	f	f	\N	\N
20240912	2024-09-12	2024	3	9	September	37	12	4	Thursday	f	f	\N	\N
20240913	2024-09-13	2024	3	9	September	37	13	5	Friday	f	f	\N	\N
20240914	2024-09-14	2024	3	9	September	37	14	6	Saturday	t	f	\N	\N
20240915	2024-09-15	2024	3	9	September	37	15	7	Sunday	t	f	\N	\N
20240916	2024-09-16	2024	3	9	September	38	16	1	Monday	f	f	\N	\N
20240917	2024-09-17	2024	3	9	September	38	17	2	Tuesday	f	f	\N	\N
20240918	2024-09-18	2024	3	9	September	38	18	3	Wednesday	f	f	\N	\N
20240919	2024-09-19	2024	3	9	September	38	19	4	Thursday	f	f	\N	\N
20240920	2024-09-20	2024	3	9	September	38	20	5	Friday	f	f	\N	\N
20240921	2024-09-21	2024	3	9	September	38	21	6	Saturday	t	f	\N	\N
20240922	2024-09-22	2024	3	9	September	38	22	7	Sunday	t	f	\N	\N
20240923	2024-09-23	2024	3	9	September	39	23	1	Monday	f	f	\N	\N
20240924	2024-09-24	2024	3	9	September	39	24	2	Tuesday	f	f	\N	\N
20240925	2024-09-25	2024	3	9	September	39	25	3	Wednesday	f	f	\N	\N
20240926	2024-09-26	2024	3	9	September	39	26	4	Thursday	f	f	\N	\N
20240927	2024-09-27	2024	3	9	September	39	27	5	Friday	f	f	\N	\N
20240928	2024-09-28	2024	3	9	September	39	28	6	Saturday	t	f	\N	\N
20240929	2024-09-29	2024	3	9	September	39	29	7	Sunday	t	f	\N	\N
20240930	2024-09-30	2024	3	9	September	40	30	1	Monday	f	t	\N	\N
20241001	2024-10-01	2024	4	10	October	40	1	2	Tuesday	f	f	\N	\N
20241002	2024-10-02	2024	4	10	October	40	2	3	Wednesday	f	f	\N	\N
20241003	2024-10-03	2024	4	10	October	40	3	4	Thursday	f	f	\N	\N
20241004	2024-10-04	2024	4	10	October	40	4	5	Friday	f	f	\N	\N
20241005	2024-10-05	2024	4	10	October	40	5	6	Saturday	t	f	\N	\N
20241006	2024-10-06	2024	4	10	October	40	6	7	Sunday	t	f	\N	\N
20241007	2024-10-07	2024	4	10	October	41	7	1	Monday	f	f	\N	\N
20241008	2024-10-08	2024	4	10	October	41	8	2	Tuesday	f	f	\N	\N
20241009	2024-10-09	2024	4	10	October	41	9	3	Wednesday	f	f	\N	\N
20241010	2024-10-10	2024	4	10	October	41	10	4	Thursday	f	f	\N	\N
20241011	2024-10-11	2024	4	10	October	41	11	5	Friday	f	f	\N	\N
20241012	2024-10-12	2024	4	10	October	41	12	6	Saturday	t	f	\N	\N
20241013	2024-10-13	2024	4	10	October	41	13	7	Sunday	t	f	\N	\N
20241014	2024-10-14	2024	4	10	October	42	14	1	Monday	f	f	\N	\N
20241015	2024-10-15	2024	4	10	October	42	15	2	Tuesday	f	f	\N	\N
20241016	2024-10-16	2024	4	10	October	42	16	3	Wednesday	f	f	\N	\N
20241017	2024-10-17	2024	4	10	October	42	17	4	Thursday	f	f	\N	\N
20241018	2024-10-18	2024	4	10	October	42	18	5	Friday	f	f	\N	\N
20241019	2024-10-19	2024	4	10	October	42	19	6	Saturday	t	f	\N	\N
20241020	2024-10-20	2024	4	10	October	42	20	7	Sunday	t	f	\N	\N
20241021	2024-10-21	2024	4	10	October	43	21	1	Monday	f	f	\N	\N
20241022	2024-10-22	2024	4	10	October	43	22	2	Tuesday	f	f	\N	\N
20241023	2024-10-23	2024	4	10	October	43	23	3	Wednesday	f	f	\N	\N
20241024	2024-10-24	2024	4	10	October	43	24	4	Thursday	f	f	\N	\N
20241025	2024-10-25	2024	4	10	October	43	25	5	Friday	f	f	\N	\N
20241026	2024-10-26	2024	4	10	October	43	26	6	Saturday	t	f	\N	\N
20241027	2024-10-27	2024	4	10	October	43	27	7	Sunday	t	f	\N	\N
20241028	2024-10-28	2024	4	10	October	44	28	1	Monday	f	f	\N	\N
20241029	2024-10-29	2024	4	10	October	44	29	2	Tuesday	f	f	\N	\N
20241030	2024-10-30	2024	4	10	October	44	30	3	Wednesday	f	f	\N	\N
20241031	2024-10-31	2024	4	10	October	44	31	4	Thursday	f	t	\N	\N
20241101	2024-11-01	2024	4	11	November	44	1	5	Friday	f	f	\N	\N
20241102	2024-11-02	2024	4	11	November	44	2	6	Saturday	t	f	\N	\N
20241103	2024-11-03	2024	4	11	November	44	3	7	Sunday	t	f	\N	\N
20241104	2024-11-04	2024	4	11	November	45	4	1	Monday	f	f	\N	\N
20241105	2024-11-05	2024	4	11	November	45	5	2	Tuesday	f	f	\N	\N
20241106	2024-11-06	2024	4	11	November	45	6	3	Wednesday	f	f	\N	\N
20241107	2024-11-07	2024	4	11	November	45	7	4	Thursday	f	f	\N	\N
20241108	2024-11-08	2024	4	11	November	45	8	5	Friday	f	f	\N	\N
20241109	2024-11-09	2024	4	11	November	45	9	6	Saturday	t	f	\N	\N
20241110	2024-11-10	2024	4	11	November	45	10	7	Sunday	t	f	\N	\N
20241111	2024-11-11	2024	4	11	November	46	11	1	Monday	f	f	\N	\N
20241112	2024-11-12	2024	4	11	November	46	12	2	Tuesday	f	f	\N	\N
20241113	2024-11-13	2024	4	11	November	46	13	3	Wednesday	f	f	\N	\N
20241114	2024-11-14	2024	4	11	November	46	14	4	Thursday	f	f	\N	\N
20241115	2024-11-15	2024	4	11	November	46	15	5	Friday	f	f	\N	\N
20241116	2024-11-16	2024	4	11	November	46	16	6	Saturday	t	f	\N	\N
20241117	2024-11-17	2024	4	11	November	46	17	7	Sunday	t	f	\N	\N
20241118	2024-11-18	2024	4	11	November	47	18	1	Monday	f	f	\N	\N
20241119	2024-11-19	2024	4	11	November	47	19	2	Tuesday	f	f	\N	\N
20241120	2024-11-20	2024	4	11	November	47	20	3	Wednesday	f	f	\N	\N
20241121	2024-11-21	2024	4	11	November	47	21	4	Thursday	f	f	\N	\N
20241122	2024-11-22	2024	4	11	November	47	22	5	Friday	f	f	\N	\N
20241123	2024-11-23	2024	4	11	November	47	23	6	Saturday	t	f	\N	\N
20241124	2024-11-24	2024	4	11	November	47	24	7	Sunday	t	f	\N	\N
20241125	2024-11-25	2024	4	11	November	48	25	1	Monday	f	f	\N	\N
20241126	2024-11-26	2024	4	11	November	48	26	2	Tuesday	f	f	\N	\N
20241127	2024-11-27	2024	4	11	November	48	27	3	Wednesday	f	f	\N	\N
20241128	2024-11-28	2024	4	11	November	48	28	4	Thursday	f	f	\N	\N
20241129	2024-11-29	2024	4	11	November	48	29	5	Friday	f	f	\N	\N
20241130	2024-11-30	2024	4	11	November	48	30	6	Saturday	t	t	\N	\N
20241201	2024-12-01	2024	4	12	December	48	1	7	Sunday	t	f	\N	\N
20241202	2024-12-02	2024	4	12	December	49	2	1	Monday	f	f	\N	\N
20241203	2024-12-03	2024	4	12	December	49	3	2	Tuesday	f	f	\N	\N
20241204	2024-12-04	2024	4	12	December	49	4	3	Wednesday	f	f	\N	\N
20241205	2024-12-05	2024	4	12	December	49	5	4	Thursday	f	f	\N	\N
20241206	2024-12-06	2024	4	12	December	49	6	5	Friday	f	f	\N	\N
20241207	2024-12-07	2024	4	12	December	49	7	6	Saturday	t	f	\N	\N
20241208	2024-12-08	2024	4	12	December	49	8	7	Sunday	t	f	\N	\N
20241209	2024-12-09	2024	4	12	December	50	9	1	Monday	f	f	\N	\N
20241210	2024-12-10	2024	4	12	December	50	10	2	Tuesday	f	f	\N	\N
20241211	2024-12-11	2024	4	12	December	50	11	3	Wednesday	f	f	\N	\N
20241212	2024-12-12	2024	4	12	December	50	12	4	Thursday	f	f	\N	\N
20241213	2024-12-13	2024	4	12	December	50	13	5	Friday	f	f	\N	\N
20241214	2024-12-14	2024	4	12	December	50	14	6	Saturday	t	f	\N	\N
20241215	2024-12-15	2024	4	12	December	50	15	7	Sunday	t	f	\N	\N
20241216	2024-12-16	2024	4	12	December	51	16	1	Monday	f	f	\N	\N
20241217	2024-12-17	2024	4	12	December	51	17	2	Tuesday	f	f	\N	\N
20241218	2024-12-18	2024	4	12	December	51	18	3	Wednesday	f	f	\N	\N
20241219	2024-12-19	2024	4	12	December	51	19	4	Thursday	f	f	\N	\N
20241220	2024-12-20	2024	4	12	December	51	20	5	Friday	f	f	\N	\N
20241221	2024-12-21	2024	4	12	December	51	21	6	Saturday	t	f	\N	\N
20241222	2024-12-22	2024	4	12	December	51	22	7	Sunday	t	f	\N	\N
20241223	2024-12-23	2024	4	12	December	52	23	1	Monday	f	f	\N	\N
20241224	2024-12-24	2024	4	12	December	52	24	2	Tuesday	f	f	\N	\N
20241225	2024-12-25	2024	4	12	December	52	25	3	Wednesday	f	f	\N	\N
20241226	2024-12-26	2024	4	12	December	52	26	4	Thursday	f	f	\N	\N
20241227	2024-12-27	2024	4	12	December	52	27	5	Friday	f	f	\N	\N
20241228	2024-12-28	2024	4	12	December	52	28	6	Saturday	t	f	\N	\N
20241229	2024-12-29	2024	4	12	December	52	29	7	Sunday	t	f	\N	\N
20241230	2024-12-30	2024	4	12	December	1	30	1	Monday	f	f	\N	\N
20241231	2024-12-31	2024	4	12	December	1	31	2	Tuesday	f	t	\N	\N
20250101	2025-01-01	2025	1	1	January	1	1	3	Wednesday	f	f	\N	\N
20250102	2025-01-02	2025	1	1	January	1	2	4	Thursday	f	f	\N	\N
20250103	2025-01-03	2025	1	1	January	1	3	5	Friday	f	f	\N	\N
20250104	2025-01-04	2025	1	1	January	1	4	6	Saturday	t	f	\N	\N
20250105	2025-01-05	2025	1	1	January	1	5	7	Sunday	t	f	\N	\N
20250106	2025-01-06	2025	1	1	January	2	6	1	Monday	f	f	\N	\N
20250107	2025-01-07	2025	1	1	January	2	7	2	Tuesday	f	f	\N	\N
20250108	2025-01-08	2025	1	1	January	2	8	3	Wednesday	f	f	\N	\N
20250109	2025-01-09	2025	1	1	January	2	9	4	Thursday	f	f	\N	\N
20250110	2025-01-10	2025	1	1	January	2	10	5	Friday	f	f	\N	\N
20250111	2025-01-11	2025	1	1	January	2	11	6	Saturday	t	f	\N	\N
20250112	2025-01-12	2025	1	1	January	2	12	7	Sunday	t	f	\N	\N
20250113	2025-01-13	2025	1	1	January	3	13	1	Monday	f	f	\N	\N
20250114	2025-01-14	2025	1	1	January	3	14	2	Tuesday	f	f	\N	\N
20250115	2025-01-15	2025	1	1	January	3	15	3	Wednesday	f	f	\N	\N
20250116	2025-01-16	2025	1	1	January	3	16	4	Thursday	f	f	\N	\N
20250117	2025-01-17	2025	1	1	January	3	17	5	Friday	f	f	\N	\N
20250118	2025-01-18	2025	1	1	January	3	18	6	Saturday	t	f	\N	\N
20250119	2025-01-19	2025	1	1	January	3	19	7	Sunday	t	f	\N	\N
20250120	2025-01-20	2025	1	1	January	4	20	1	Monday	f	f	\N	\N
20250121	2025-01-21	2025	1	1	January	4	21	2	Tuesday	f	f	\N	\N
20250122	2025-01-22	2025	1	1	January	4	22	3	Wednesday	f	f	\N	\N
20250123	2025-01-23	2025	1	1	January	4	23	4	Thursday	f	f	\N	\N
20250124	2025-01-24	2025	1	1	January	4	24	5	Friday	f	f	\N	\N
20250125	2025-01-25	2025	1	1	January	4	25	6	Saturday	t	f	\N	\N
20250126	2025-01-26	2025	1	1	January	4	26	7	Sunday	t	f	\N	\N
20250127	2025-01-27	2025	1	1	January	5	27	1	Monday	f	f	\N	\N
20250128	2025-01-28	2025	1	1	January	5	28	2	Tuesday	f	f	\N	\N
20250129	2025-01-29	2025	1	1	January	5	29	3	Wednesday	f	f	\N	\N
20250130	2025-01-30	2025	1	1	January	5	30	4	Thursday	f	f	\N	\N
20250131	2025-01-31	2025	1	1	January	5	31	5	Friday	f	t	\N	\N
20250201	2025-02-01	2025	1	2	February	5	1	6	Saturday	t	f	\N	\N
20250202	2025-02-02	2025	1	2	February	5	2	7	Sunday	t	f	\N	\N
20250203	2025-02-03	2025	1	2	February	6	3	1	Monday	f	f	\N	\N
20250204	2025-02-04	2025	1	2	February	6	4	2	Tuesday	f	f	\N	\N
20250205	2025-02-05	2025	1	2	February	6	5	3	Wednesday	f	f	\N	\N
20250206	2025-02-06	2025	1	2	February	6	6	4	Thursday	f	f	\N	\N
20250207	2025-02-07	2025	1	2	February	6	7	5	Friday	f	f	\N	\N
20250208	2025-02-08	2025	1	2	February	6	8	6	Saturday	t	f	\N	\N
20250209	2025-02-09	2025	1	2	February	6	9	7	Sunday	t	f	\N	\N
20250210	2025-02-10	2025	1	2	February	7	10	1	Monday	f	f	\N	\N
20250211	2025-02-11	2025	1	2	February	7	11	2	Tuesday	f	f	\N	\N
20250212	2025-02-12	2025	1	2	February	7	12	3	Wednesday	f	f	\N	\N
20250213	2025-02-13	2025	1	2	February	7	13	4	Thursday	f	f	\N	\N
20250214	2025-02-14	2025	1	2	February	7	14	5	Friday	f	f	\N	\N
20250215	2025-02-15	2025	1	2	February	7	15	6	Saturday	t	f	\N	\N
20250216	2025-02-16	2025	1	2	February	7	16	7	Sunday	t	f	\N	\N
20250217	2025-02-17	2025	1	2	February	8	17	1	Monday	f	f	\N	\N
20250218	2025-02-18	2025	1	2	February	8	18	2	Tuesday	f	f	\N	\N
20250219	2025-02-19	2025	1	2	February	8	19	3	Wednesday	f	f	\N	\N
20250220	2025-02-20	2025	1	2	February	8	20	4	Thursday	f	f	\N	\N
20250221	2025-02-21	2025	1	2	February	8	21	5	Friday	f	f	\N	\N
20250222	2025-02-22	2025	1	2	February	8	22	6	Saturday	t	f	\N	\N
20250223	2025-02-23	2025	1	2	February	8	23	7	Sunday	t	f	\N	\N
20250224	2025-02-24	2025	1	2	February	9	24	1	Monday	f	f	\N	\N
20250225	2025-02-25	2025	1	2	February	9	25	2	Tuesday	f	f	\N	\N
20250226	2025-02-26	2025	1	2	February	9	26	3	Wednesday	f	f	\N	\N
20250227	2025-02-27	2025	1	2	February	9	27	4	Thursday	f	f	\N	\N
20250228	2025-02-28	2025	1	2	February	9	28	5	Friday	f	t	\N	\N
20250301	2025-03-01	2025	1	3	March	9	1	6	Saturday	t	f	\N	\N
20250302	2025-03-02	2025	1	3	March	9	2	7	Sunday	t	f	\N	\N
20250303	2025-03-03	2025	1	3	March	10	3	1	Monday	f	f	\N	\N
20250304	2025-03-04	2025	1	3	March	10	4	2	Tuesday	f	f	\N	\N
20250305	2025-03-05	2025	1	3	March	10	5	3	Wednesday	f	f	\N	\N
20250306	2025-03-06	2025	1	3	March	10	6	4	Thursday	f	f	\N	\N
20250307	2025-03-07	2025	1	3	March	10	7	5	Friday	f	f	\N	\N
20250308	2025-03-08	2025	1	3	March	10	8	6	Saturday	t	f	\N	\N
20250309	2025-03-09	2025	1	3	March	10	9	7	Sunday	t	f	\N	\N
20250310	2025-03-10	2025	1	3	March	11	10	1	Monday	f	f	\N	\N
20250311	2025-03-11	2025	1	3	March	11	11	2	Tuesday	f	f	\N	\N
20250312	2025-03-12	2025	1	3	March	11	12	3	Wednesday	f	f	\N	\N
20250313	2025-03-13	2025	1	3	March	11	13	4	Thursday	f	f	\N	\N
20250314	2025-03-14	2025	1	3	March	11	14	5	Friday	f	f	\N	\N
20250315	2025-03-15	2025	1	3	March	11	15	6	Saturday	t	f	\N	\N
20250316	2025-03-16	2025	1	3	March	11	16	7	Sunday	t	f	\N	\N
20250317	2025-03-17	2025	1	3	March	12	17	1	Monday	f	f	\N	\N
20250318	2025-03-18	2025	1	3	March	12	18	2	Tuesday	f	f	\N	\N
20250319	2025-03-19	2025	1	3	March	12	19	3	Wednesday	f	f	\N	\N
20250320	2025-03-20	2025	1	3	March	12	20	4	Thursday	f	f	\N	\N
20250321	2025-03-21	2025	1	3	March	12	21	5	Friday	f	f	\N	\N
20250322	2025-03-22	2025	1	3	March	12	22	6	Saturday	t	f	\N	\N
20250323	2025-03-23	2025	1	3	March	12	23	7	Sunday	t	f	\N	\N
20250324	2025-03-24	2025	1	3	March	13	24	1	Monday	f	f	\N	\N
20250325	2025-03-25	2025	1	3	March	13	25	2	Tuesday	f	f	\N	\N
20250326	2025-03-26	2025	1	3	March	13	26	3	Wednesday	f	f	\N	\N
20250327	2025-03-27	2025	1	3	March	13	27	4	Thursday	f	f	\N	\N
20250328	2025-03-28	2025	1	3	March	13	28	5	Friday	f	f	\N	\N
20250329	2025-03-29	2025	1	3	March	13	29	6	Saturday	t	f	\N	\N
20250330	2025-03-30	2025	1	3	March	13	30	7	Sunday	t	f	\N	\N
20250331	2025-03-31	2025	1	3	March	14	31	1	Monday	f	t	\N	\N
20250401	2025-04-01	2025	2	4	April	14	1	2	Tuesday	f	f	\N	\N
20250402	2025-04-02	2025	2	4	April	14	2	3	Wednesday	f	f	\N	\N
20250403	2025-04-03	2025	2	4	April	14	3	4	Thursday	f	f	\N	\N
20250404	2025-04-04	2025	2	4	April	14	4	5	Friday	f	f	\N	\N
20250405	2025-04-05	2025	2	4	April	14	5	6	Saturday	t	f	\N	\N
20250406	2025-04-06	2025	2	4	April	14	6	7	Sunday	t	f	\N	\N
20250407	2025-04-07	2025	2	4	April	15	7	1	Monday	f	f	\N	\N
20250408	2025-04-08	2025	2	4	April	15	8	2	Tuesday	f	f	\N	\N
20250409	2025-04-09	2025	2	4	April	15	9	3	Wednesday	f	f	\N	\N
20250410	2025-04-10	2025	2	4	April	15	10	4	Thursday	f	f	\N	\N
20250411	2025-04-11	2025	2	4	April	15	11	5	Friday	f	f	\N	\N
20250412	2025-04-12	2025	2	4	April	15	12	6	Saturday	t	f	\N	\N
20250413	2025-04-13	2025	2	4	April	15	13	7	Sunday	t	f	\N	\N
20250414	2025-04-14	2025	2	4	April	16	14	1	Monday	f	f	\N	\N
20250415	2025-04-15	2025	2	4	April	16	15	2	Tuesday	f	f	\N	\N
20250416	2025-04-16	2025	2	4	April	16	16	3	Wednesday	f	f	\N	\N
20250417	2025-04-17	2025	2	4	April	16	17	4	Thursday	f	f	\N	\N
20250418	2025-04-18	2025	2	4	April	16	18	5	Friday	f	f	\N	\N
20250419	2025-04-19	2025	2	4	April	16	19	6	Saturday	t	f	\N	\N
20250420	2025-04-20	2025	2	4	April	16	20	7	Sunday	t	f	\N	\N
20250421	2025-04-21	2025	2	4	April	17	21	1	Monday	f	f	\N	\N
20250422	2025-04-22	2025	2	4	April	17	22	2	Tuesday	f	f	\N	\N
20250423	2025-04-23	2025	2	4	April	17	23	3	Wednesday	f	f	\N	\N
20250424	2025-04-24	2025	2	4	April	17	24	4	Thursday	f	f	\N	\N
20250425	2025-04-25	2025	2	4	April	17	25	5	Friday	f	f	\N	\N
20250426	2025-04-26	2025	2	4	April	17	26	6	Saturday	t	f	\N	\N
20250427	2025-04-27	2025	2	4	April	17	27	7	Sunday	t	f	\N	\N
20250428	2025-04-28	2025	2	4	April	18	28	1	Monday	f	f	\N	\N
20250429	2025-04-29	2025	2	4	April	18	29	2	Tuesday	f	f	\N	\N
20250430	2025-04-30	2025	2	4	April	18	30	3	Wednesday	f	t	\N	\N
20250501	2025-05-01	2025	2	5	May	18	1	4	Thursday	f	f	\N	\N
20250502	2025-05-02	2025	2	5	May	18	2	5	Friday	f	f	\N	\N
20250503	2025-05-03	2025	2	5	May	18	3	6	Saturday	t	f	\N	\N
20250504	2025-05-04	2025	2	5	May	18	4	7	Sunday	t	f	\N	\N
20250505	2025-05-05	2025	2	5	May	19	5	1	Monday	f	f	\N	\N
20250506	2025-05-06	2025	2	5	May	19	6	2	Tuesday	f	f	\N	\N
20250507	2025-05-07	2025	2	5	May	19	7	3	Wednesday	f	f	\N	\N
20250508	2025-05-08	2025	2	5	May	19	8	4	Thursday	f	f	\N	\N
20250509	2025-05-09	2025	2	5	May	19	9	5	Friday	f	f	\N	\N
20250510	2025-05-10	2025	2	5	May	19	10	6	Saturday	t	f	\N	\N
20250511	2025-05-11	2025	2	5	May	19	11	7	Sunday	t	f	\N	\N
20250512	2025-05-12	2025	2	5	May	20	12	1	Monday	f	f	\N	\N
20250513	2025-05-13	2025	2	5	May	20	13	2	Tuesday	f	f	\N	\N
20250514	2025-05-14	2025	2	5	May	20	14	3	Wednesday	f	f	\N	\N
20250515	2025-05-15	2025	2	5	May	20	15	4	Thursday	f	f	\N	\N
20250516	2025-05-16	2025	2	5	May	20	16	5	Friday	f	f	\N	\N
20250517	2025-05-17	2025	2	5	May	20	17	6	Saturday	t	f	\N	\N
20250518	2025-05-18	2025	2	5	May	20	18	7	Sunday	t	f	\N	\N
20250519	2025-05-19	2025	2	5	May	21	19	1	Monday	f	f	\N	\N
20250520	2025-05-20	2025	2	5	May	21	20	2	Tuesday	f	f	\N	\N
20250521	2025-05-21	2025	2	5	May	21	21	3	Wednesday	f	f	\N	\N
20250522	2025-05-22	2025	2	5	May	21	22	4	Thursday	f	f	\N	\N
20250523	2025-05-23	2025	2	5	May	21	23	5	Friday	f	f	\N	\N
20250524	2025-05-24	2025	2	5	May	21	24	6	Saturday	t	f	\N	\N
20250525	2025-05-25	2025	2	5	May	21	25	7	Sunday	t	f	\N	\N
20250526	2025-05-26	2025	2	5	May	22	26	1	Monday	f	f	\N	\N
20250527	2025-05-27	2025	2	5	May	22	27	2	Tuesday	f	f	\N	\N
20250528	2025-05-28	2025	2	5	May	22	28	3	Wednesday	f	f	\N	\N
20250529	2025-05-29	2025	2	5	May	22	29	4	Thursday	f	f	\N	\N
20250530	2025-05-30	2025	2	5	May	22	30	5	Friday	f	f	\N	\N
20250531	2025-05-31	2025	2	5	May	22	31	6	Saturday	t	t	\N	\N
20250601	2025-06-01	2025	2	6	June	22	1	7	Sunday	t	f	\N	\N
20250602	2025-06-02	2025	2	6	June	23	2	1	Monday	f	f	\N	\N
20250603	2025-06-03	2025	2	6	June	23	3	2	Tuesday	f	f	\N	\N
20250604	2025-06-04	2025	2	6	June	23	4	3	Wednesday	f	f	\N	\N
20250605	2025-06-05	2025	2	6	June	23	5	4	Thursday	f	f	\N	\N
20250606	2025-06-06	2025	2	6	June	23	6	5	Friday	f	f	\N	\N
20250607	2025-06-07	2025	2	6	June	23	7	6	Saturday	t	f	\N	\N
20250608	2025-06-08	2025	2	6	June	23	8	7	Sunday	t	f	\N	\N
20250609	2025-06-09	2025	2	6	June	24	9	1	Monday	f	f	\N	\N
20250610	2025-06-10	2025	2	6	June	24	10	2	Tuesday	f	f	\N	\N
20250611	2025-06-11	2025	2	6	June	24	11	3	Wednesday	f	f	\N	\N
20250612	2025-06-12	2025	2	6	June	24	12	4	Thursday	f	f	\N	\N
20250613	2025-06-13	2025	2	6	June	24	13	5	Friday	f	f	\N	\N
20250614	2025-06-14	2025	2	6	June	24	14	6	Saturday	t	f	\N	\N
20250615	2025-06-15	2025	2	6	June	24	15	7	Sunday	t	f	\N	\N
20250616	2025-06-16	2025	2	6	June	25	16	1	Monday	f	f	\N	\N
20250617	2025-06-17	2025	2	6	June	25	17	2	Tuesday	f	f	\N	\N
20250618	2025-06-18	2025	2	6	June	25	18	3	Wednesday	f	f	\N	\N
20250619	2025-06-19	2025	2	6	June	25	19	4	Thursday	f	f	\N	\N
20250620	2025-06-20	2025	2	6	June	25	20	5	Friday	f	f	\N	\N
20250621	2025-06-21	2025	2	6	June	25	21	6	Saturday	t	f	\N	\N
20250622	2025-06-22	2025	2	6	June	25	22	7	Sunday	t	f	\N	\N
20250623	2025-06-23	2025	2	6	June	26	23	1	Monday	f	f	\N	\N
20250624	2025-06-24	2025	2	6	June	26	24	2	Tuesday	f	f	\N	\N
20250625	2025-06-25	2025	2	6	June	26	25	3	Wednesday	f	f	\N	\N
20250626	2025-06-26	2025	2	6	June	26	26	4	Thursday	f	f	\N	\N
20250627	2025-06-27	2025	2	6	June	26	27	5	Friday	f	f	\N	\N
20250628	2025-06-28	2025	2	6	June	26	28	6	Saturday	t	f	\N	\N
20250629	2025-06-29	2025	2	6	June	26	29	7	Sunday	t	f	\N	\N
20250630	2025-06-30	2025	2	6	June	27	30	1	Monday	f	t	\N	\N
20250701	2025-07-01	2025	3	7	July	27	1	2	Tuesday	f	f	\N	\N
20250702	2025-07-02	2025	3	7	July	27	2	3	Wednesday	f	f	\N	\N
20250703	2025-07-03	2025	3	7	July	27	3	4	Thursday	f	f	\N	\N
20250704	2025-07-04	2025	3	7	July	27	4	5	Friday	f	f	\N	\N
20250705	2025-07-05	2025	3	7	July	27	5	6	Saturday	t	f	\N	\N
20250706	2025-07-06	2025	3	7	July	27	6	7	Sunday	t	f	\N	\N
20250707	2025-07-07	2025	3	7	July	28	7	1	Monday	f	f	\N	\N
20250708	2025-07-08	2025	3	7	July	28	8	2	Tuesday	f	f	\N	\N
20250709	2025-07-09	2025	3	7	July	28	9	3	Wednesday	f	f	\N	\N
20250710	2025-07-10	2025	3	7	July	28	10	4	Thursday	f	f	\N	\N
20250711	2025-07-11	2025	3	7	July	28	11	5	Friday	f	f	\N	\N
20250712	2025-07-12	2025	3	7	July	28	12	6	Saturday	t	f	\N	\N
20250713	2025-07-13	2025	3	7	July	28	13	7	Sunday	t	f	\N	\N
20250714	2025-07-14	2025	3	7	July	29	14	1	Monday	f	f	\N	\N
20250715	2025-07-15	2025	3	7	July	29	15	2	Tuesday	f	f	\N	\N
20250716	2025-07-16	2025	3	7	July	29	16	3	Wednesday	f	f	\N	\N
20250717	2025-07-17	2025	3	7	July	29	17	4	Thursday	f	f	\N	\N
20250718	2025-07-18	2025	3	7	July	29	18	5	Friday	f	f	\N	\N
20250719	2025-07-19	2025	3	7	July	29	19	6	Saturday	t	f	\N	\N
20250720	2025-07-20	2025	3	7	July	29	20	7	Sunday	t	f	\N	\N
20250721	2025-07-21	2025	3	7	July	30	21	1	Monday	f	f	\N	\N
20250722	2025-07-22	2025	3	7	July	30	22	2	Tuesday	f	f	\N	\N
20250723	2025-07-23	2025	3	7	July	30	23	3	Wednesday	f	f	\N	\N
20250724	2025-07-24	2025	3	7	July	30	24	4	Thursday	f	f	\N	\N
20250725	2025-07-25	2025	3	7	July	30	25	5	Friday	f	f	\N	\N
20250726	2025-07-26	2025	3	7	July	30	26	6	Saturday	t	f	\N	\N
20250727	2025-07-27	2025	3	7	July	30	27	7	Sunday	t	f	\N	\N
20250728	2025-07-28	2025	3	7	July	31	28	1	Monday	f	f	\N	\N
20250729	2025-07-29	2025	3	7	July	31	29	2	Tuesday	f	f	\N	\N
20250730	2025-07-30	2025	3	7	July	31	30	3	Wednesday	f	f	\N	\N
20250731	2025-07-31	2025	3	7	July	31	31	4	Thursday	f	t	\N	\N
20250801	2025-08-01	2025	3	8	August	31	1	5	Friday	f	f	\N	\N
20250802	2025-08-02	2025	3	8	August	31	2	6	Saturday	t	f	\N	\N
20250803	2025-08-03	2025	3	8	August	31	3	7	Sunday	t	f	\N	\N
20250804	2025-08-04	2025	3	8	August	32	4	1	Monday	f	f	\N	\N
20250805	2025-08-05	2025	3	8	August	32	5	2	Tuesday	f	f	\N	\N
20250806	2025-08-06	2025	3	8	August	32	6	3	Wednesday	f	f	\N	\N
20250807	2025-08-07	2025	3	8	August	32	7	4	Thursday	f	f	\N	\N
20250808	2025-08-08	2025	3	8	August	32	8	5	Friday	f	f	\N	\N
20250809	2025-08-09	2025	3	8	August	32	9	6	Saturday	t	f	\N	\N
20250810	2025-08-10	2025	3	8	August	32	10	7	Sunday	t	f	\N	\N
20250811	2025-08-11	2025	3	8	August	33	11	1	Monday	f	f	\N	\N
20250812	2025-08-12	2025	3	8	August	33	12	2	Tuesday	f	f	\N	\N
20250813	2025-08-13	2025	3	8	August	33	13	3	Wednesday	f	f	\N	\N
20250814	2025-08-14	2025	3	8	August	33	14	4	Thursday	f	f	\N	\N
20250815	2025-08-15	2025	3	8	August	33	15	5	Friday	f	f	\N	\N
20250816	2025-08-16	2025	3	8	August	33	16	6	Saturday	t	f	\N	\N
20250817	2025-08-17	2025	3	8	August	33	17	7	Sunday	t	f	\N	\N
20250818	2025-08-18	2025	3	8	August	34	18	1	Monday	f	f	\N	\N
20250819	2025-08-19	2025	3	8	August	34	19	2	Tuesday	f	f	\N	\N
20250820	2025-08-20	2025	3	8	August	34	20	3	Wednesday	f	f	\N	\N
20250821	2025-08-21	2025	3	8	August	34	21	4	Thursday	f	f	\N	\N
20250822	2025-08-22	2025	3	8	August	34	22	5	Friday	f	f	\N	\N
20250823	2025-08-23	2025	3	8	August	34	23	6	Saturday	t	f	\N	\N
20250824	2025-08-24	2025	3	8	August	34	24	7	Sunday	t	f	\N	\N
20250825	2025-08-25	2025	3	8	August	35	25	1	Monday	f	f	\N	\N
20250826	2025-08-26	2025	3	8	August	35	26	2	Tuesday	f	f	\N	\N
20250827	2025-08-27	2025	3	8	August	35	27	3	Wednesday	f	f	\N	\N
20250828	2025-08-28	2025	3	8	August	35	28	4	Thursday	f	f	\N	\N
20250829	2025-08-29	2025	3	8	August	35	29	5	Friday	f	f	\N	\N
20250830	2025-08-30	2025	3	8	August	35	30	6	Saturday	t	f	\N	\N
20250831	2025-08-31	2025	3	8	August	35	31	7	Sunday	t	t	\N	\N
20250901	2025-09-01	2025	3	9	September	36	1	1	Monday	f	f	\N	\N
20250902	2025-09-02	2025	3	9	September	36	2	2	Tuesday	f	f	\N	\N
20250903	2025-09-03	2025	3	9	September	36	3	3	Wednesday	f	f	\N	\N
20250904	2025-09-04	2025	3	9	September	36	4	4	Thursday	f	f	\N	\N
20250905	2025-09-05	2025	3	9	September	36	5	5	Friday	f	f	\N	\N
20250906	2025-09-06	2025	3	9	September	36	6	6	Saturday	t	f	\N	\N
20250907	2025-09-07	2025	3	9	September	36	7	7	Sunday	t	f	\N	\N
20250908	2025-09-08	2025	3	9	September	37	8	1	Monday	f	f	\N	\N
20250909	2025-09-09	2025	3	9	September	37	9	2	Tuesday	f	f	\N	\N
20250910	2025-09-10	2025	3	9	September	37	10	3	Wednesday	f	f	\N	\N
20250911	2025-09-11	2025	3	9	September	37	11	4	Thursday	f	f	\N	\N
20250912	2025-09-12	2025	3	9	September	37	12	5	Friday	f	f	\N	\N
20250913	2025-09-13	2025	3	9	September	37	13	6	Saturday	t	f	\N	\N
20250914	2025-09-14	2025	3	9	September	37	14	7	Sunday	t	f	\N	\N
20250915	2025-09-15	2025	3	9	September	38	15	1	Monday	f	f	\N	\N
20250916	2025-09-16	2025	3	9	September	38	16	2	Tuesday	f	f	\N	\N
20250917	2025-09-17	2025	3	9	September	38	17	3	Wednesday	f	f	\N	\N
20250918	2025-09-18	2025	3	9	September	38	18	4	Thursday	f	f	\N	\N
20250919	2025-09-19	2025	3	9	September	38	19	5	Friday	f	f	\N	\N
20250920	2025-09-20	2025	3	9	September	38	20	6	Saturday	t	f	\N	\N
20250921	2025-09-21	2025	3	9	September	38	21	7	Sunday	t	f	\N	\N
20250922	2025-09-22	2025	3	9	September	39	22	1	Monday	f	f	\N	\N
20250923	2025-09-23	2025	3	9	September	39	23	2	Tuesday	f	f	\N	\N
20250924	2025-09-24	2025	3	9	September	39	24	3	Wednesday	f	f	\N	\N
20250925	2025-09-25	2025	3	9	September	39	25	4	Thursday	f	f	\N	\N
20250926	2025-09-26	2025	3	9	September	39	26	5	Friday	f	f	\N	\N
20250927	2025-09-27	2025	3	9	September	39	27	6	Saturday	t	f	\N	\N
20250928	2025-09-28	2025	3	9	September	39	28	7	Sunday	t	f	\N	\N
20250929	2025-09-29	2025	3	9	September	40	29	1	Monday	f	f	\N	\N
20250930	2025-09-30	2025	3	9	September	40	30	2	Tuesday	f	t	\N	\N
20251001	2025-10-01	2025	4	10	October	40	1	3	Wednesday	f	f	\N	\N
20251002	2025-10-02	2025	4	10	October	40	2	4	Thursday	f	f	\N	\N
20251003	2025-10-03	2025	4	10	October	40	3	5	Friday	f	f	\N	\N
20251004	2025-10-04	2025	4	10	October	40	4	6	Saturday	t	f	\N	\N
20251005	2025-10-05	2025	4	10	October	40	5	7	Sunday	t	f	\N	\N
20251006	2025-10-06	2025	4	10	October	41	6	1	Monday	f	f	\N	\N
20251007	2025-10-07	2025	4	10	October	41	7	2	Tuesday	f	f	\N	\N
20251008	2025-10-08	2025	4	10	October	41	8	3	Wednesday	f	f	\N	\N
20251009	2025-10-09	2025	4	10	October	41	9	4	Thursday	f	f	\N	\N
20251010	2025-10-10	2025	4	10	October	41	10	5	Friday	f	f	\N	\N
20251011	2025-10-11	2025	4	10	October	41	11	6	Saturday	t	f	\N	\N
20251012	2025-10-12	2025	4	10	October	41	12	7	Sunday	t	f	\N	\N
20251013	2025-10-13	2025	4	10	October	42	13	1	Monday	f	f	\N	\N
20251014	2025-10-14	2025	4	10	October	42	14	2	Tuesday	f	f	\N	\N
20251015	2025-10-15	2025	4	10	October	42	15	3	Wednesday	f	f	\N	\N
20251016	2025-10-16	2025	4	10	October	42	16	4	Thursday	f	f	\N	\N
20251017	2025-10-17	2025	4	10	October	42	17	5	Friday	f	f	\N	\N
20251018	2025-10-18	2025	4	10	October	42	18	6	Saturday	t	f	\N	\N
20251019	2025-10-19	2025	4	10	October	42	19	7	Sunday	t	f	\N	\N
20251020	2025-10-20	2025	4	10	October	43	20	1	Monday	f	f	\N	\N
20251021	2025-10-21	2025	4	10	October	43	21	2	Tuesday	f	f	\N	\N
20251022	2025-10-22	2025	4	10	October	43	22	3	Wednesday	f	f	\N	\N
20251023	2025-10-23	2025	4	10	October	43	23	4	Thursday	f	f	\N	\N
20251024	2025-10-24	2025	4	10	October	43	24	5	Friday	f	f	\N	\N
20251025	2025-10-25	2025	4	10	October	43	25	6	Saturday	t	f	\N	\N
20251026	2025-10-26	2025	4	10	October	43	26	7	Sunday	t	f	\N	\N
20251027	2025-10-27	2025	4	10	October	44	27	1	Monday	f	f	\N	\N
20251028	2025-10-28	2025	4	10	October	44	28	2	Tuesday	f	f	\N	\N
20251029	2025-10-29	2025	4	10	October	44	29	3	Wednesday	f	f	\N	\N
20251030	2025-10-30	2025	4	10	October	44	30	4	Thursday	f	f	\N	\N
20251031	2025-10-31	2025	4	10	October	44	31	5	Friday	f	t	\N	\N
20251101	2025-11-01	2025	4	11	November	44	1	6	Saturday	t	f	\N	\N
20251102	2025-11-02	2025	4	11	November	44	2	7	Sunday	t	f	\N	\N
20251103	2025-11-03	2025	4	11	November	45	3	1	Monday	f	f	\N	\N
20251104	2025-11-04	2025	4	11	November	45	4	2	Tuesday	f	f	\N	\N
20251105	2025-11-05	2025	4	11	November	45	5	3	Wednesday	f	f	\N	\N
20251106	2025-11-06	2025	4	11	November	45	6	4	Thursday	f	f	\N	\N
20251107	2025-11-07	2025	4	11	November	45	7	5	Friday	f	f	\N	\N
20251108	2025-11-08	2025	4	11	November	45	8	6	Saturday	t	f	\N	\N
20251109	2025-11-09	2025	4	11	November	45	9	7	Sunday	t	f	\N	\N
20251110	2025-11-10	2025	4	11	November	46	10	1	Monday	f	f	\N	\N
20251111	2025-11-11	2025	4	11	November	46	11	2	Tuesday	f	f	\N	\N
20251112	2025-11-12	2025	4	11	November	46	12	3	Wednesday	f	f	\N	\N
20251113	2025-11-13	2025	4	11	November	46	13	4	Thursday	f	f	\N	\N
20251114	2025-11-14	2025	4	11	November	46	14	5	Friday	f	f	\N	\N
20251115	2025-11-15	2025	4	11	November	46	15	6	Saturday	t	f	\N	\N
20251116	2025-11-16	2025	4	11	November	46	16	7	Sunday	t	f	\N	\N
20251117	2025-11-17	2025	4	11	November	47	17	1	Monday	f	f	\N	\N
20251118	2025-11-18	2025	4	11	November	47	18	2	Tuesday	f	f	\N	\N
20251119	2025-11-19	2025	4	11	November	47	19	3	Wednesday	f	f	\N	\N
20251120	2025-11-20	2025	4	11	November	47	20	4	Thursday	f	f	\N	\N
20251121	2025-11-21	2025	4	11	November	47	21	5	Friday	f	f	\N	\N
20251122	2025-11-22	2025	4	11	November	47	22	6	Saturday	t	f	\N	\N
20251123	2025-11-23	2025	4	11	November	47	23	7	Sunday	t	f	\N	\N
20251124	2025-11-24	2025	4	11	November	48	24	1	Monday	f	f	\N	\N
20251125	2025-11-25	2025	4	11	November	48	25	2	Tuesday	f	f	\N	\N
20251126	2025-11-26	2025	4	11	November	48	26	3	Wednesday	f	f	\N	\N
20251127	2025-11-27	2025	4	11	November	48	27	4	Thursday	f	f	\N	\N
20251128	2025-11-28	2025	4	11	November	48	28	5	Friday	f	f	\N	\N
20251129	2025-11-29	2025	4	11	November	48	29	6	Saturday	t	f	\N	\N
20251130	2025-11-30	2025	4	11	November	48	30	7	Sunday	t	t	\N	\N
20251201	2025-12-01	2025	4	12	December	49	1	1	Monday	f	f	\N	\N
20251202	2025-12-02	2025	4	12	December	49	2	2	Tuesday	f	f	\N	\N
20251203	2025-12-03	2025	4	12	December	49	3	3	Wednesday	f	f	\N	\N
20251204	2025-12-04	2025	4	12	December	49	4	4	Thursday	f	f	\N	\N
20251205	2025-12-05	2025	4	12	December	49	5	5	Friday	f	f	\N	\N
20251206	2025-12-06	2025	4	12	December	49	6	6	Saturday	t	f	\N	\N
20251207	2025-12-07	2025	4	12	December	49	7	7	Sunday	t	f	\N	\N
20251208	2025-12-08	2025	4	12	December	50	8	1	Monday	f	f	\N	\N
20251209	2025-12-09	2025	4	12	December	50	9	2	Tuesday	f	f	\N	\N
20251210	2025-12-10	2025	4	12	December	50	10	3	Wednesday	f	f	\N	\N
20251211	2025-12-11	2025	4	12	December	50	11	4	Thursday	f	f	\N	\N
20251212	2025-12-12	2025	4	12	December	50	12	5	Friday	f	f	\N	\N
20251213	2025-12-13	2025	4	12	December	50	13	6	Saturday	t	f	\N	\N
20251214	2025-12-14	2025	4	12	December	50	14	7	Sunday	t	f	\N	\N
20251215	2025-12-15	2025	4	12	December	51	15	1	Monday	f	f	\N	\N
20251216	2025-12-16	2025	4	12	December	51	16	2	Tuesday	f	f	\N	\N
20251217	2025-12-17	2025	4	12	December	51	17	3	Wednesday	f	f	\N	\N
20251218	2025-12-18	2025	4	12	December	51	18	4	Thursday	f	f	\N	\N
20251219	2025-12-19	2025	4	12	December	51	19	5	Friday	f	f	\N	\N
20251220	2025-12-20	2025	4	12	December	51	20	6	Saturday	t	f	\N	\N
20251221	2025-12-21	2025	4	12	December	51	21	7	Sunday	t	f	\N	\N
20251222	2025-12-22	2025	4	12	December	52	22	1	Monday	f	f	\N	\N
20251223	2025-12-23	2025	4	12	December	52	23	2	Tuesday	f	f	\N	\N
20251224	2025-12-24	2025	4	12	December	52	24	3	Wednesday	f	f	\N	\N
20251225	2025-12-25	2025	4	12	December	52	25	4	Thursday	f	f	\N	\N
20251226	2025-12-26	2025	4	12	December	52	26	5	Friday	f	f	\N	\N
20251227	2025-12-27	2025	4	12	December	52	27	6	Saturday	t	f	\N	\N
20251228	2025-12-28	2025	4	12	December	52	28	7	Sunday	t	f	\N	\N
20251229	2025-12-29	2025	4	12	December	1	29	1	Monday	f	f	\N	\N
20251230	2025-12-30	2025	4	12	December	1	30	2	Tuesday	f	f	\N	\N
20251231	2025-12-31	2025	4	12	December	1	31	3	Wednesday	f	t	\N	\N
20260101	2026-01-01	2026	1	1	January	1	1	4	Thursday	f	f	\N	\N
20260102	2026-01-02	2026	1	1	January	1	2	5	Friday	f	f	\N	\N
20260103	2026-01-03	2026	1	1	January	1	3	6	Saturday	t	f	\N	\N
20260104	2026-01-04	2026	1	1	January	1	4	7	Sunday	t	f	\N	\N
20260105	2026-01-05	2026	1	1	January	2	5	1	Monday	f	f	\N	\N
20260106	2026-01-06	2026	1	1	January	2	6	2	Tuesday	f	f	\N	\N
20260107	2026-01-07	2026	1	1	January	2	7	3	Wednesday	f	f	\N	\N
20260108	2026-01-08	2026	1	1	January	2	8	4	Thursday	f	f	\N	\N
20260109	2026-01-09	2026	1	1	January	2	9	5	Friday	f	f	\N	\N
20260110	2026-01-10	2026	1	1	January	2	10	6	Saturday	t	f	\N	\N
20260111	2026-01-11	2026	1	1	January	2	11	7	Sunday	t	f	\N	\N
20260112	2026-01-12	2026	1	1	January	3	12	1	Monday	f	f	\N	\N
20260113	2026-01-13	2026	1	1	January	3	13	2	Tuesday	f	f	\N	\N
20260114	2026-01-14	2026	1	1	January	3	14	3	Wednesday	f	f	\N	\N
20260115	2026-01-15	2026	1	1	January	3	15	4	Thursday	f	f	\N	\N
20260116	2026-01-16	2026	1	1	January	3	16	5	Friday	f	f	\N	\N
20260117	2026-01-17	2026	1	1	January	3	17	6	Saturday	t	f	\N	\N
20260118	2026-01-18	2026	1	1	January	3	18	7	Sunday	t	f	\N	\N
20260119	2026-01-19	2026	1	1	January	4	19	1	Monday	f	f	\N	\N
20260120	2026-01-20	2026	1	1	January	4	20	2	Tuesday	f	f	\N	\N
20260121	2026-01-21	2026	1	1	January	4	21	3	Wednesday	f	f	\N	\N
20260122	2026-01-22	2026	1	1	January	4	22	4	Thursday	f	f	\N	\N
20260123	2026-01-23	2026	1	1	January	4	23	5	Friday	f	f	\N	\N
20260124	2026-01-24	2026	1	1	January	4	24	6	Saturday	t	f	\N	\N
20260125	2026-01-25	2026	1	1	January	4	25	7	Sunday	t	f	\N	\N
20260126	2026-01-26	2026	1	1	January	5	26	1	Monday	f	f	\N	\N
20260127	2026-01-27	2026	1	1	January	5	27	2	Tuesday	f	f	\N	\N
20260128	2026-01-28	2026	1	1	January	5	28	3	Wednesday	f	f	\N	\N
20260129	2026-01-29	2026	1	1	January	5	29	4	Thursday	f	f	\N	\N
20260130	2026-01-30	2026	1	1	January	5	30	5	Friday	f	f	\N	\N
20260131	2026-01-31	2026	1	1	January	5	31	6	Saturday	t	t	\N	\N
20260201	2026-02-01	2026	1	2	February	5	1	7	Sunday	t	f	\N	\N
20260202	2026-02-02	2026	1	2	February	6	2	1	Monday	f	f	\N	\N
20260203	2026-02-03	2026	1	2	February	6	3	2	Tuesday	f	f	\N	\N
20260204	2026-02-04	2026	1	2	February	6	4	3	Wednesday	f	f	\N	\N
20260205	2026-02-05	2026	1	2	February	6	5	4	Thursday	f	f	\N	\N
20260206	2026-02-06	2026	1	2	February	6	6	5	Friday	f	f	\N	\N
20260207	2026-02-07	2026	1	2	February	6	7	6	Saturday	t	f	\N	\N
20260208	2026-02-08	2026	1	2	February	6	8	7	Sunday	t	f	\N	\N
20260209	2026-02-09	2026	1	2	February	7	9	1	Monday	f	f	\N	\N
20260210	2026-02-10	2026	1	2	February	7	10	2	Tuesday	f	f	\N	\N
20260211	2026-02-11	2026	1	2	February	7	11	3	Wednesday	f	f	\N	\N
20260212	2026-02-12	2026	1	2	February	7	12	4	Thursday	f	f	\N	\N
20260213	2026-02-13	2026	1	2	February	7	13	5	Friday	f	f	\N	\N
20260214	2026-02-14	2026	1	2	February	7	14	6	Saturday	t	f	\N	\N
20260215	2026-02-15	2026	1	2	February	7	15	7	Sunday	t	f	\N	\N
20260216	2026-02-16	2026	1	2	February	8	16	1	Monday	f	f	\N	\N
20260217	2026-02-17	2026	1	2	February	8	17	2	Tuesday	f	f	\N	\N
20260218	2026-02-18	2026	1	2	February	8	18	3	Wednesday	f	f	\N	\N
20260219	2026-02-19	2026	1	2	February	8	19	4	Thursday	f	f	\N	\N
20260220	2026-02-20	2026	1	2	February	8	20	5	Friday	f	f	\N	\N
20260221	2026-02-21	2026	1	2	February	8	21	6	Saturday	t	f	\N	\N
20260222	2026-02-22	2026	1	2	February	8	22	7	Sunday	t	f	\N	\N
20260223	2026-02-23	2026	1	2	February	9	23	1	Monday	f	f	\N	\N
20260224	2026-02-24	2026	1	2	February	9	24	2	Tuesday	f	f	\N	\N
20260225	2026-02-25	2026	1	2	February	9	25	3	Wednesday	f	f	\N	\N
20260226	2026-02-26	2026	1	2	February	9	26	4	Thursday	f	f	\N	\N
20260227	2026-02-27	2026	1	2	February	9	27	5	Friday	f	f	\N	\N
20260228	2026-02-28	2026	1	2	February	9	28	6	Saturday	t	t	\N	\N
20260301	2026-03-01	2026	1	3	March	9	1	7	Sunday	t	f	\N	\N
20260302	2026-03-02	2026	1	3	March	10	2	1	Monday	f	f	\N	\N
20260303	2026-03-03	2026	1	3	March	10	3	2	Tuesday	f	f	\N	\N
20260304	2026-03-04	2026	1	3	March	10	4	3	Wednesday	f	f	\N	\N
20260305	2026-03-05	2026	1	3	March	10	5	4	Thursday	f	f	\N	\N
20260306	2026-03-06	2026	1	3	March	10	6	5	Friday	f	f	\N	\N
20260307	2026-03-07	2026	1	3	March	10	7	6	Saturday	t	f	\N	\N
20260308	2026-03-08	2026	1	3	March	10	8	7	Sunday	t	f	\N	\N
20260309	2026-03-09	2026	1	3	March	11	9	1	Monday	f	f	\N	\N
20260310	2026-03-10	2026	1	3	March	11	10	2	Tuesday	f	f	\N	\N
20260311	2026-03-11	2026	1	3	March	11	11	3	Wednesday	f	f	\N	\N
20260312	2026-03-12	2026	1	3	March	11	12	4	Thursday	f	f	\N	\N
20260313	2026-03-13	2026	1	3	March	11	13	5	Friday	f	f	\N	\N
20260314	2026-03-14	2026	1	3	March	11	14	6	Saturday	t	f	\N	\N
20260315	2026-03-15	2026	1	3	March	11	15	7	Sunday	t	f	\N	\N
20260316	2026-03-16	2026	1	3	March	12	16	1	Monday	f	f	\N	\N
20260317	2026-03-17	2026	1	3	March	12	17	2	Tuesday	f	f	\N	\N
20260318	2026-03-18	2026	1	3	March	12	18	3	Wednesday	f	f	\N	\N
20260319	2026-03-19	2026	1	3	March	12	19	4	Thursday	f	f	\N	\N
20260320	2026-03-20	2026	1	3	March	12	20	5	Friday	f	f	\N	\N
20260321	2026-03-21	2026	1	3	March	12	21	6	Saturday	t	f	\N	\N
20260322	2026-03-22	2026	1	3	March	12	22	7	Sunday	t	f	\N	\N
20260323	2026-03-23	2026	1	3	March	13	23	1	Monday	f	f	\N	\N
20260324	2026-03-24	2026	1	3	March	13	24	2	Tuesday	f	f	\N	\N
20260325	2026-03-25	2026	1	3	March	13	25	3	Wednesday	f	f	\N	\N
20260326	2026-03-26	2026	1	3	March	13	26	4	Thursday	f	f	\N	\N
20260327	2026-03-27	2026	1	3	March	13	27	5	Friday	f	f	\N	\N
20260328	2026-03-28	2026	1	3	March	13	28	6	Saturday	t	f	\N	\N
20260329	2026-03-29	2026	1	3	March	13	29	7	Sunday	t	f	\N	\N
20260330	2026-03-30	2026	1	3	March	14	30	1	Monday	f	f	\N	\N
20260331	2026-03-31	2026	1	3	March	14	31	2	Tuesday	f	t	\N	\N
20260401	2026-04-01	2026	2	4	April	14	1	3	Wednesday	f	f	\N	\N
20260402	2026-04-02	2026	2	4	April	14	2	4	Thursday	f	f	\N	\N
20260403	2026-04-03	2026	2	4	April	14	3	5	Friday	f	f	\N	\N
20260404	2026-04-04	2026	2	4	April	14	4	6	Saturday	t	f	\N	\N
20260405	2026-04-05	2026	2	4	April	14	5	7	Sunday	t	f	\N	\N
20260406	2026-04-06	2026	2	4	April	15	6	1	Monday	f	f	\N	\N
20260407	2026-04-07	2026	2	4	April	15	7	2	Tuesday	f	f	\N	\N
20260408	2026-04-08	2026	2	4	April	15	8	3	Wednesday	f	f	\N	\N
20260409	2026-04-09	2026	2	4	April	15	9	4	Thursday	f	f	\N	\N
20260410	2026-04-10	2026	2	4	April	15	10	5	Friday	f	f	\N	\N
20260411	2026-04-11	2026	2	4	April	15	11	6	Saturday	t	f	\N	\N
20260412	2026-04-12	2026	2	4	April	15	12	7	Sunday	t	f	\N	\N
20260413	2026-04-13	2026	2	4	April	16	13	1	Monday	f	f	\N	\N
20260414	2026-04-14	2026	2	4	April	16	14	2	Tuesday	f	f	\N	\N
20260415	2026-04-15	2026	2	4	April	16	15	3	Wednesday	f	f	\N	\N
20260416	2026-04-16	2026	2	4	April	16	16	4	Thursday	f	f	\N	\N
20260417	2026-04-17	2026	2	4	April	16	17	5	Friday	f	f	\N	\N
20260418	2026-04-18	2026	2	4	April	16	18	6	Saturday	t	f	\N	\N
20260419	2026-04-19	2026	2	4	April	16	19	7	Sunday	t	f	\N	\N
20260420	2026-04-20	2026	2	4	April	17	20	1	Monday	f	f	\N	\N
20260421	2026-04-21	2026	2	4	April	17	21	2	Tuesday	f	f	\N	\N
20260422	2026-04-22	2026	2	4	April	17	22	3	Wednesday	f	f	\N	\N
20260423	2026-04-23	2026	2	4	April	17	23	4	Thursday	f	f	\N	\N
20260424	2026-04-24	2026	2	4	April	17	24	5	Friday	f	f	\N	\N
20260425	2026-04-25	2026	2	4	April	17	25	6	Saturday	t	f	\N	\N
20260426	2026-04-26	2026	2	4	April	17	26	7	Sunday	t	f	\N	\N
20260427	2026-04-27	2026	2	4	April	18	27	1	Monday	f	f	\N	\N
20260428	2026-04-28	2026	2	4	April	18	28	2	Tuesday	f	f	\N	\N
20260429	2026-04-29	2026	2	4	April	18	29	3	Wednesday	f	f	\N	\N
20260430	2026-04-30	2026	2	4	April	18	30	4	Thursday	f	t	\N	\N
20260501	2026-05-01	2026	2	5	May	18	1	5	Friday	f	f	\N	\N
20260502	2026-05-02	2026	2	5	May	18	2	6	Saturday	t	f	\N	\N
20260503	2026-05-03	2026	2	5	May	18	3	7	Sunday	t	f	\N	\N
20260504	2026-05-04	2026	2	5	May	19	4	1	Monday	f	f	\N	\N
20260505	2026-05-05	2026	2	5	May	19	5	2	Tuesday	f	f	\N	\N
20260506	2026-05-06	2026	2	5	May	19	6	3	Wednesday	f	f	\N	\N
20260507	2026-05-07	2026	2	5	May	19	7	4	Thursday	f	f	\N	\N
20260508	2026-05-08	2026	2	5	May	19	8	5	Friday	f	f	\N	\N
20260509	2026-05-09	2026	2	5	May	19	9	6	Saturday	t	f	\N	\N
20260510	2026-05-10	2026	2	5	May	19	10	7	Sunday	t	f	\N	\N
20260511	2026-05-11	2026	2	5	May	20	11	1	Monday	f	f	\N	\N
20260512	2026-05-12	2026	2	5	May	20	12	2	Tuesday	f	f	\N	\N
20260513	2026-05-13	2026	2	5	May	20	13	3	Wednesday	f	f	\N	\N
20260514	2026-05-14	2026	2	5	May	20	14	4	Thursday	f	f	\N	\N
20260515	2026-05-15	2026	2	5	May	20	15	5	Friday	f	f	\N	\N
20260516	2026-05-16	2026	2	5	May	20	16	6	Saturday	t	f	\N	\N
20260517	2026-05-17	2026	2	5	May	20	17	7	Sunday	t	f	\N	\N
20260518	2026-05-18	2026	2	5	May	21	18	1	Monday	f	f	\N	\N
20260519	2026-05-19	2026	2	5	May	21	19	2	Tuesday	f	f	\N	\N
20260520	2026-05-20	2026	2	5	May	21	20	3	Wednesday	f	f	\N	\N
20260521	2026-05-21	2026	2	5	May	21	21	4	Thursday	f	f	\N	\N
20260522	2026-05-22	2026	2	5	May	21	22	5	Friday	f	f	\N	\N
20260523	2026-05-23	2026	2	5	May	21	23	6	Saturday	t	f	\N	\N
20260524	2026-05-24	2026	2	5	May	21	24	7	Sunday	t	f	\N	\N
20260525	2026-05-25	2026	2	5	May	22	25	1	Monday	f	f	\N	\N
20260526	2026-05-26	2026	2	5	May	22	26	2	Tuesday	f	f	\N	\N
20260527	2026-05-27	2026	2	5	May	22	27	3	Wednesday	f	f	\N	\N
20260528	2026-05-28	2026	2	5	May	22	28	4	Thursday	f	f	\N	\N
20260529	2026-05-29	2026	2	5	May	22	29	5	Friday	f	f	\N	\N
20260530	2026-05-30	2026	2	5	May	22	30	6	Saturday	t	f	\N	\N
20260531	2026-05-31	2026	2	5	May	22	31	7	Sunday	t	t	\N	\N
20260601	2026-06-01	2026	2	6	June	23	1	1	Monday	f	f	\N	\N
20260602	2026-06-02	2026	2	6	June	23	2	2	Tuesday	f	f	\N	\N
20260603	2026-06-03	2026	2	6	June	23	3	3	Wednesday	f	f	\N	\N
20260604	2026-06-04	2026	2	6	June	23	4	4	Thursday	f	f	\N	\N
20260605	2026-06-05	2026	2	6	June	23	5	5	Friday	f	f	\N	\N
20260606	2026-06-06	2026	2	6	June	23	6	6	Saturday	t	f	\N	\N
20260607	2026-06-07	2026	2	6	June	23	7	7	Sunday	t	f	\N	\N
20260608	2026-06-08	2026	2	6	June	24	8	1	Monday	f	f	\N	\N
20260609	2026-06-09	2026	2	6	June	24	9	2	Tuesday	f	f	\N	\N
20260610	2026-06-10	2026	2	6	June	24	10	3	Wednesday	f	f	\N	\N
20260611	2026-06-11	2026	2	6	June	24	11	4	Thursday	f	f	\N	\N
20260612	2026-06-12	2026	2	6	June	24	12	5	Friday	f	f	\N	\N
20260613	2026-06-13	2026	2	6	June	24	13	6	Saturday	t	f	\N	\N
20260614	2026-06-14	2026	2	6	June	24	14	7	Sunday	t	f	\N	\N
20260615	2026-06-15	2026	2	6	June	25	15	1	Monday	f	f	\N	\N
20260616	2026-06-16	2026	2	6	June	25	16	2	Tuesday	f	f	\N	\N
20260617	2026-06-17	2026	2	6	June	25	17	3	Wednesday	f	f	\N	\N
20260618	2026-06-18	2026	2	6	June	25	18	4	Thursday	f	f	\N	\N
20260619	2026-06-19	2026	2	6	June	25	19	5	Friday	f	f	\N	\N
20260620	2026-06-20	2026	2	6	June	25	20	6	Saturday	t	f	\N	\N
20260621	2026-06-21	2026	2	6	June	25	21	7	Sunday	t	f	\N	\N
20260622	2026-06-22	2026	2	6	June	26	22	1	Monday	f	f	\N	\N
20260623	2026-06-23	2026	2	6	June	26	23	2	Tuesday	f	f	\N	\N
20260624	2026-06-24	2026	2	6	June	26	24	3	Wednesday	f	f	\N	\N
20260625	2026-06-25	2026	2	6	June	26	25	4	Thursday	f	f	\N	\N
20260626	2026-06-26	2026	2	6	June	26	26	5	Friday	f	f	\N	\N
20260627	2026-06-27	2026	2	6	June	26	27	6	Saturday	t	f	\N	\N
20260628	2026-06-28	2026	2	6	June	26	28	7	Sunday	t	f	\N	\N
20260629	2026-06-29	2026	2	6	June	27	29	1	Monday	f	f	\N	\N
20260630	2026-06-30	2026	2	6	June	27	30	2	Tuesday	f	t	\N	\N
20260701	2026-07-01	2026	3	7	July	27	1	3	Wednesday	f	f	\N	\N
20260702	2026-07-02	2026	3	7	July	27	2	4	Thursday	f	f	\N	\N
20260703	2026-07-03	2026	3	7	July	27	3	5	Friday	f	f	\N	\N
20260704	2026-07-04	2026	3	7	July	27	4	6	Saturday	t	f	\N	\N
20260705	2026-07-05	2026	3	7	July	27	5	7	Sunday	t	f	\N	\N
20260706	2026-07-06	2026	3	7	July	28	6	1	Monday	f	f	\N	\N
20260707	2026-07-07	2026	3	7	July	28	7	2	Tuesday	f	f	\N	\N
20260708	2026-07-08	2026	3	7	July	28	8	3	Wednesday	f	f	\N	\N
20260709	2026-07-09	2026	3	7	July	28	9	4	Thursday	f	f	\N	\N
20260710	2026-07-10	2026	3	7	July	28	10	5	Friday	f	f	\N	\N
20260711	2026-07-11	2026	3	7	July	28	11	6	Saturday	t	f	\N	\N
20260712	2026-07-12	2026	3	7	July	28	12	7	Sunday	t	f	\N	\N
20260713	2026-07-13	2026	3	7	July	29	13	1	Monday	f	f	\N	\N
20260714	2026-07-14	2026	3	7	July	29	14	2	Tuesday	f	f	\N	\N
20260715	2026-07-15	2026	3	7	July	29	15	3	Wednesday	f	f	\N	\N
20260716	2026-07-16	2026	3	7	July	29	16	4	Thursday	f	f	\N	\N
20260717	2026-07-17	2026	3	7	July	29	17	5	Friday	f	f	\N	\N
20260718	2026-07-18	2026	3	7	July	29	18	6	Saturday	t	f	\N	\N
20260719	2026-07-19	2026	3	7	July	29	19	7	Sunday	t	f	\N	\N
20260720	2026-07-20	2026	3	7	July	30	20	1	Monday	f	f	\N	\N
20260721	2026-07-21	2026	3	7	July	30	21	2	Tuesday	f	f	\N	\N
20260722	2026-07-22	2026	3	7	July	30	22	3	Wednesday	f	f	\N	\N
20260723	2026-07-23	2026	3	7	July	30	23	4	Thursday	f	f	\N	\N
20260724	2026-07-24	2026	3	7	July	30	24	5	Friday	f	f	\N	\N
20260725	2026-07-25	2026	3	7	July	30	25	6	Saturday	t	f	\N	\N
20260726	2026-07-26	2026	3	7	July	30	26	7	Sunday	t	f	\N	\N
20260727	2026-07-27	2026	3	7	July	31	27	1	Monday	f	f	\N	\N
20260728	2026-07-28	2026	3	7	July	31	28	2	Tuesday	f	f	\N	\N
20260729	2026-07-29	2026	3	7	July	31	29	3	Wednesday	f	f	\N	\N
20260730	2026-07-30	2026	3	7	July	31	30	4	Thursday	f	f	\N	\N
20260731	2026-07-31	2026	3	7	July	31	31	5	Friday	f	t	\N	\N
20260801	2026-08-01	2026	3	8	August	31	1	6	Saturday	t	f	\N	\N
20260802	2026-08-02	2026	3	8	August	31	2	7	Sunday	t	f	\N	\N
20260803	2026-08-03	2026	3	8	August	32	3	1	Monday	f	f	\N	\N
20260804	2026-08-04	2026	3	8	August	32	4	2	Tuesday	f	f	\N	\N
20260805	2026-08-05	2026	3	8	August	32	5	3	Wednesday	f	f	\N	\N
20260806	2026-08-06	2026	3	8	August	32	6	4	Thursday	f	f	\N	\N
20260807	2026-08-07	2026	3	8	August	32	7	5	Friday	f	f	\N	\N
20260808	2026-08-08	2026	3	8	August	32	8	6	Saturday	t	f	\N	\N
20260809	2026-08-09	2026	3	8	August	32	9	7	Sunday	t	f	\N	\N
20260810	2026-08-10	2026	3	8	August	33	10	1	Monday	f	f	\N	\N
20260811	2026-08-11	2026	3	8	August	33	11	2	Tuesday	f	f	\N	\N
20260812	2026-08-12	2026	3	8	August	33	12	3	Wednesday	f	f	\N	\N
20260813	2026-08-13	2026	3	8	August	33	13	4	Thursday	f	f	\N	\N
20260814	2026-08-14	2026	3	8	August	33	14	5	Friday	f	f	\N	\N
20260815	2026-08-15	2026	3	8	August	33	15	6	Saturday	t	f	\N	\N
20260816	2026-08-16	2026	3	8	August	33	16	7	Sunday	t	f	\N	\N
20260817	2026-08-17	2026	3	8	August	34	17	1	Monday	f	f	\N	\N
20260818	2026-08-18	2026	3	8	August	34	18	2	Tuesday	f	f	\N	\N
20260819	2026-08-19	2026	3	8	August	34	19	3	Wednesday	f	f	\N	\N
20260820	2026-08-20	2026	3	8	August	34	20	4	Thursday	f	f	\N	\N
20260821	2026-08-21	2026	3	8	August	34	21	5	Friday	f	f	\N	\N
20260822	2026-08-22	2026	3	8	August	34	22	6	Saturday	t	f	\N	\N
20260823	2026-08-23	2026	3	8	August	34	23	7	Sunday	t	f	\N	\N
20260824	2026-08-24	2026	3	8	August	35	24	1	Monday	f	f	\N	\N
20260825	2026-08-25	2026	3	8	August	35	25	2	Tuesday	f	f	\N	\N
20260826	2026-08-26	2026	3	8	August	35	26	3	Wednesday	f	f	\N	\N
20260827	2026-08-27	2026	3	8	August	35	27	4	Thursday	f	f	\N	\N
20260828	2026-08-28	2026	3	8	August	35	28	5	Friday	f	f	\N	\N
20260829	2026-08-29	2026	3	8	August	35	29	6	Saturday	t	f	\N	\N
20260830	2026-08-30	2026	3	8	August	35	30	7	Sunday	t	f	\N	\N
20260831	2026-08-31	2026	3	8	August	36	31	1	Monday	f	t	\N	\N
20260901	2026-09-01	2026	3	9	September	36	1	2	Tuesday	f	f	\N	\N
20260902	2026-09-02	2026	3	9	September	36	2	3	Wednesday	f	f	\N	\N
20260903	2026-09-03	2026	3	9	September	36	3	4	Thursday	f	f	\N	\N
20260904	2026-09-04	2026	3	9	September	36	4	5	Friday	f	f	\N	\N
20260905	2026-09-05	2026	3	9	September	36	5	6	Saturday	t	f	\N	\N
20260906	2026-09-06	2026	3	9	September	36	6	7	Sunday	t	f	\N	\N
20260907	2026-09-07	2026	3	9	September	37	7	1	Monday	f	f	\N	\N
20260908	2026-09-08	2026	3	9	September	37	8	2	Tuesday	f	f	\N	\N
20260909	2026-09-09	2026	3	9	September	37	9	3	Wednesday	f	f	\N	\N
20260910	2026-09-10	2026	3	9	September	37	10	4	Thursday	f	f	\N	\N
20260911	2026-09-11	2026	3	9	September	37	11	5	Friday	f	f	\N	\N
20260912	2026-09-12	2026	3	9	September	37	12	6	Saturday	t	f	\N	\N
20260913	2026-09-13	2026	3	9	September	37	13	7	Sunday	t	f	\N	\N
20260914	2026-09-14	2026	3	9	September	38	14	1	Monday	f	f	\N	\N
20260915	2026-09-15	2026	3	9	September	38	15	2	Tuesday	f	f	\N	\N
20260916	2026-09-16	2026	3	9	September	38	16	3	Wednesday	f	f	\N	\N
20260917	2026-09-17	2026	3	9	September	38	17	4	Thursday	f	f	\N	\N
20260918	2026-09-18	2026	3	9	September	38	18	5	Friday	f	f	\N	\N
20260919	2026-09-19	2026	3	9	September	38	19	6	Saturday	t	f	\N	\N
20260920	2026-09-20	2026	3	9	September	38	20	7	Sunday	t	f	\N	\N
20260921	2026-09-21	2026	3	9	September	39	21	1	Monday	f	f	\N	\N
20260922	2026-09-22	2026	3	9	September	39	22	2	Tuesday	f	f	\N	\N
20260923	2026-09-23	2026	3	9	September	39	23	3	Wednesday	f	f	\N	\N
20260924	2026-09-24	2026	3	9	September	39	24	4	Thursday	f	f	\N	\N
20260925	2026-09-25	2026	3	9	September	39	25	5	Friday	f	f	\N	\N
20260926	2026-09-26	2026	3	9	September	39	26	6	Saturday	t	f	\N	\N
20260927	2026-09-27	2026	3	9	September	39	27	7	Sunday	t	f	\N	\N
20260928	2026-09-28	2026	3	9	September	40	28	1	Monday	f	f	\N	\N
20260929	2026-09-29	2026	3	9	September	40	29	2	Tuesday	f	f	\N	\N
20260930	2026-09-30	2026	3	9	September	40	30	3	Wednesday	f	t	\N	\N
20261001	2026-10-01	2026	4	10	October	40	1	4	Thursday	f	f	\N	\N
20261002	2026-10-02	2026	4	10	October	40	2	5	Friday	f	f	\N	\N
20261003	2026-10-03	2026	4	10	October	40	3	6	Saturday	t	f	\N	\N
20261004	2026-10-04	2026	4	10	October	40	4	7	Sunday	t	f	\N	\N
20261005	2026-10-05	2026	4	10	October	41	5	1	Monday	f	f	\N	\N
20261006	2026-10-06	2026	4	10	October	41	6	2	Tuesday	f	f	\N	\N
20261007	2026-10-07	2026	4	10	October	41	7	3	Wednesday	f	f	\N	\N
20261008	2026-10-08	2026	4	10	October	41	8	4	Thursday	f	f	\N	\N
20261009	2026-10-09	2026	4	10	October	41	9	5	Friday	f	f	\N	\N
20261010	2026-10-10	2026	4	10	October	41	10	6	Saturday	t	f	\N	\N
20261011	2026-10-11	2026	4	10	October	41	11	7	Sunday	t	f	\N	\N
20261012	2026-10-12	2026	4	10	October	42	12	1	Monday	f	f	\N	\N
20261013	2026-10-13	2026	4	10	October	42	13	2	Tuesday	f	f	\N	\N
20261014	2026-10-14	2026	4	10	October	42	14	3	Wednesday	f	f	\N	\N
20261015	2026-10-15	2026	4	10	October	42	15	4	Thursday	f	f	\N	\N
20261016	2026-10-16	2026	4	10	October	42	16	5	Friday	f	f	\N	\N
20261017	2026-10-17	2026	4	10	October	42	17	6	Saturday	t	f	\N	\N
20261018	2026-10-18	2026	4	10	October	42	18	7	Sunday	t	f	\N	\N
20261019	2026-10-19	2026	4	10	October	43	19	1	Monday	f	f	\N	\N
20261020	2026-10-20	2026	4	10	October	43	20	2	Tuesday	f	f	\N	\N
20261021	2026-10-21	2026	4	10	October	43	21	3	Wednesday	f	f	\N	\N
20261022	2026-10-22	2026	4	10	October	43	22	4	Thursday	f	f	\N	\N
20261023	2026-10-23	2026	4	10	October	43	23	5	Friday	f	f	\N	\N
20261024	2026-10-24	2026	4	10	October	43	24	6	Saturday	t	f	\N	\N
20261025	2026-10-25	2026	4	10	October	43	25	7	Sunday	t	f	\N	\N
20261026	2026-10-26	2026	4	10	October	44	26	1	Monday	f	f	\N	\N
20261027	2026-10-27	2026	4	10	October	44	27	2	Tuesday	f	f	\N	\N
20261028	2026-10-28	2026	4	10	October	44	28	3	Wednesday	f	f	\N	\N
20261029	2026-10-29	2026	4	10	October	44	29	4	Thursday	f	f	\N	\N
20261030	2026-10-30	2026	4	10	October	44	30	5	Friday	f	f	\N	\N
20261031	2026-10-31	2026	4	10	October	44	31	6	Saturday	t	t	\N	\N
20261101	2026-11-01	2026	4	11	November	44	1	7	Sunday	t	f	\N	\N
20261102	2026-11-02	2026	4	11	November	45	2	1	Monday	f	f	\N	\N
20261103	2026-11-03	2026	4	11	November	45	3	2	Tuesday	f	f	\N	\N
20261104	2026-11-04	2026	4	11	November	45	4	3	Wednesday	f	f	\N	\N
20261105	2026-11-05	2026	4	11	November	45	5	4	Thursday	f	f	\N	\N
20261106	2026-11-06	2026	4	11	November	45	6	5	Friday	f	f	\N	\N
20261107	2026-11-07	2026	4	11	November	45	7	6	Saturday	t	f	\N	\N
20261108	2026-11-08	2026	4	11	November	45	8	7	Sunday	t	f	\N	\N
20261109	2026-11-09	2026	4	11	November	46	9	1	Monday	f	f	\N	\N
20261110	2026-11-10	2026	4	11	November	46	10	2	Tuesday	f	f	\N	\N
20261111	2026-11-11	2026	4	11	November	46	11	3	Wednesday	f	f	\N	\N
20261112	2026-11-12	2026	4	11	November	46	12	4	Thursday	f	f	\N	\N
20261113	2026-11-13	2026	4	11	November	46	13	5	Friday	f	f	\N	\N
20261114	2026-11-14	2026	4	11	November	46	14	6	Saturday	t	f	\N	\N
20261115	2026-11-15	2026	4	11	November	46	15	7	Sunday	t	f	\N	\N
20261116	2026-11-16	2026	4	11	November	47	16	1	Monday	f	f	\N	\N
20261117	2026-11-17	2026	4	11	November	47	17	2	Tuesday	f	f	\N	\N
20261118	2026-11-18	2026	4	11	November	47	18	3	Wednesday	f	f	\N	\N
20261119	2026-11-19	2026	4	11	November	47	19	4	Thursday	f	f	\N	\N
20261120	2026-11-20	2026	4	11	November	47	20	5	Friday	f	f	\N	\N
20261121	2026-11-21	2026	4	11	November	47	21	6	Saturday	t	f	\N	\N
20261122	2026-11-22	2026	4	11	November	47	22	7	Sunday	t	f	\N	\N
20261123	2026-11-23	2026	4	11	November	48	23	1	Monday	f	f	\N	\N
20261124	2026-11-24	2026	4	11	November	48	24	2	Tuesday	f	f	\N	\N
20261125	2026-11-25	2026	4	11	November	48	25	3	Wednesday	f	f	\N	\N
20261126	2026-11-26	2026	4	11	November	48	26	4	Thursday	f	f	\N	\N
20261127	2026-11-27	2026	4	11	November	48	27	5	Friday	f	f	\N	\N
20261128	2026-11-28	2026	4	11	November	48	28	6	Saturday	t	f	\N	\N
20261129	2026-11-29	2026	4	11	November	48	29	7	Sunday	t	f	\N	\N
20261130	2026-11-30	2026	4	11	November	49	30	1	Monday	f	t	\N	\N
20261201	2026-12-01	2026	4	12	December	49	1	2	Tuesday	f	f	\N	\N
20261202	2026-12-02	2026	4	12	December	49	2	3	Wednesday	f	f	\N	\N
20261203	2026-12-03	2026	4	12	December	49	3	4	Thursday	f	f	\N	\N
20261204	2026-12-04	2026	4	12	December	49	4	5	Friday	f	f	\N	\N
20261205	2026-12-05	2026	4	12	December	49	5	6	Saturday	t	f	\N	\N
20261206	2026-12-06	2026	4	12	December	49	6	7	Sunday	t	f	\N	\N
20261207	2026-12-07	2026	4	12	December	50	7	1	Monday	f	f	\N	\N
20261208	2026-12-08	2026	4	12	December	50	8	2	Tuesday	f	f	\N	\N
20261209	2026-12-09	2026	4	12	December	50	9	3	Wednesday	f	f	\N	\N
20261210	2026-12-10	2026	4	12	December	50	10	4	Thursday	f	f	\N	\N
20261211	2026-12-11	2026	4	12	December	50	11	5	Friday	f	f	\N	\N
20261212	2026-12-12	2026	4	12	December	50	12	6	Saturday	t	f	\N	\N
20261213	2026-12-13	2026	4	12	December	50	13	7	Sunday	t	f	\N	\N
20261214	2026-12-14	2026	4	12	December	51	14	1	Monday	f	f	\N	\N
20261215	2026-12-15	2026	4	12	December	51	15	2	Tuesday	f	f	\N	\N
20261216	2026-12-16	2026	4	12	December	51	16	3	Wednesday	f	f	\N	\N
20261217	2026-12-17	2026	4	12	December	51	17	4	Thursday	f	f	\N	\N
20261218	2026-12-18	2026	4	12	December	51	18	5	Friday	f	f	\N	\N
20261219	2026-12-19	2026	4	12	December	51	19	6	Saturday	t	f	\N	\N
20261220	2026-12-20	2026	4	12	December	51	20	7	Sunday	t	f	\N	\N
20261221	2026-12-21	2026	4	12	December	52	21	1	Monday	f	f	\N	\N
20261222	2026-12-22	2026	4	12	December	52	22	2	Tuesday	f	f	\N	\N
20261223	2026-12-23	2026	4	12	December	52	23	3	Wednesday	f	f	\N	\N
20261224	2026-12-24	2026	4	12	December	52	24	4	Thursday	f	f	\N	\N
20261225	2026-12-25	2026	4	12	December	52	25	5	Friday	f	f	\N	\N
20261226	2026-12-26	2026	4	12	December	52	26	6	Saturday	t	f	\N	\N
20261227	2026-12-27	2026	4	12	December	52	27	7	Sunday	t	f	\N	\N
20261228	2026-12-28	2026	4	12	December	53	28	1	Monday	f	f	\N	\N
20261229	2026-12-29	2026	4	12	December	53	29	2	Tuesday	f	f	\N	\N
20261230	2026-12-30	2026	4	12	December	53	30	3	Wednesday	f	f	\N	\N
20261231	2026-12-31	2026	4	12	December	53	31	4	Thursday	f	t	\N	\N
20270101	2027-01-01	2027	1	1	January	53	1	5	Friday	f	f	\N	\N
20270102	2027-01-02	2027	1	1	January	53	2	6	Saturday	t	f	\N	\N
20270103	2027-01-03	2027	1	1	January	53	3	7	Sunday	t	f	\N	\N
20270104	2027-01-04	2027	1	1	January	1	4	1	Monday	f	f	\N	\N
20270105	2027-01-05	2027	1	1	January	1	5	2	Tuesday	f	f	\N	\N
20270106	2027-01-06	2027	1	1	January	1	6	3	Wednesday	f	f	\N	\N
20270107	2027-01-07	2027	1	1	January	1	7	4	Thursday	f	f	\N	\N
20270108	2027-01-08	2027	1	1	January	1	8	5	Friday	f	f	\N	\N
20270109	2027-01-09	2027	1	1	January	1	9	6	Saturday	t	f	\N	\N
20270110	2027-01-10	2027	1	1	January	1	10	7	Sunday	t	f	\N	\N
20270111	2027-01-11	2027	1	1	January	2	11	1	Monday	f	f	\N	\N
20270112	2027-01-12	2027	1	1	January	2	12	2	Tuesday	f	f	\N	\N
20270113	2027-01-13	2027	1	1	January	2	13	3	Wednesday	f	f	\N	\N
20270114	2027-01-14	2027	1	1	January	2	14	4	Thursday	f	f	\N	\N
20270115	2027-01-15	2027	1	1	January	2	15	5	Friday	f	f	\N	\N
20270116	2027-01-16	2027	1	1	January	2	16	6	Saturday	t	f	\N	\N
20270117	2027-01-17	2027	1	1	January	2	17	7	Sunday	t	f	\N	\N
20270118	2027-01-18	2027	1	1	January	3	18	1	Monday	f	f	\N	\N
20270119	2027-01-19	2027	1	1	January	3	19	2	Tuesday	f	f	\N	\N
20270120	2027-01-20	2027	1	1	January	3	20	3	Wednesday	f	f	\N	\N
20270121	2027-01-21	2027	1	1	January	3	21	4	Thursday	f	f	\N	\N
20270122	2027-01-22	2027	1	1	January	3	22	5	Friday	f	f	\N	\N
20270123	2027-01-23	2027	1	1	January	3	23	6	Saturday	t	f	\N	\N
20270124	2027-01-24	2027	1	1	January	3	24	7	Sunday	t	f	\N	\N
20270125	2027-01-25	2027	1	1	January	4	25	1	Monday	f	f	\N	\N
20270126	2027-01-26	2027	1	1	January	4	26	2	Tuesday	f	f	\N	\N
20270127	2027-01-27	2027	1	1	January	4	27	3	Wednesday	f	f	\N	\N
20270128	2027-01-28	2027	1	1	January	4	28	4	Thursday	f	f	\N	\N
20270129	2027-01-29	2027	1	1	January	4	29	5	Friday	f	f	\N	\N
20270130	2027-01-30	2027	1	1	January	4	30	6	Saturday	t	f	\N	\N
20270131	2027-01-31	2027	1	1	January	4	31	7	Sunday	t	t	\N	\N
20270201	2027-02-01	2027	1	2	February	5	1	1	Monday	f	f	\N	\N
20270202	2027-02-02	2027	1	2	February	5	2	2	Tuesday	f	f	\N	\N
20270203	2027-02-03	2027	1	2	February	5	3	3	Wednesday	f	f	\N	\N
20270204	2027-02-04	2027	1	2	February	5	4	4	Thursday	f	f	\N	\N
20270205	2027-02-05	2027	1	2	February	5	5	5	Friday	f	f	\N	\N
20270206	2027-02-06	2027	1	2	February	5	6	6	Saturday	t	f	\N	\N
20270207	2027-02-07	2027	1	2	February	5	7	7	Sunday	t	f	\N	\N
20270208	2027-02-08	2027	1	2	February	6	8	1	Monday	f	f	\N	\N
20270209	2027-02-09	2027	1	2	February	6	9	2	Tuesday	f	f	\N	\N
20270210	2027-02-10	2027	1	2	February	6	10	3	Wednesday	f	f	\N	\N
20270211	2027-02-11	2027	1	2	February	6	11	4	Thursday	f	f	\N	\N
20270212	2027-02-12	2027	1	2	February	6	12	5	Friday	f	f	\N	\N
20270213	2027-02-13	2027	1	2	February	6	13	6	Saturday	t	f	\N	\N
20270214	2027-02-14	2027	1	2	February	6	14	7	Sunday	t	f	\N	\N
20270215	2027-02-15	2027	1	2	February	7	15	1	Monday	f	f	\N	\N
20270216	2027-02-16	2027	1	2	February	7	16	2	Tuesday	f	f	\N	\N
20270217	2027-02-17	2027	1	2	February	7	17	3	Wednesday	f	f	\N	\N
20270218	2027-02-18	2027	1	2	February	7	18	4	Thursday	f	f	\N	\N
20270219	2027-02-19	2027	1	2	February	7	19	5	Friday	f	f	\N	\N
20270220	2027-02-20	2027	1	2	February	7	20	6	Saturday	t	f	\N	\N
20270221	2027-02-21	2027	1	2	February	7	21	7	Sunday	t	f	\N	\N
20270222	2027-02-22	2027	1	2	February	8	22	1	Monday	f	f	\N	\N
20270223	2027-02-23	2027	1	2	February	8	23	2	Tuesday	f	f	\N	\N
20270224	2027-02-24	2027	1	2	February	8	24	3	Wednesday	f	f	\N	\N
20270225	2027-02-25	2027	1	2	February	8	25	4	Thursday	f	f	\N	\N
20270226	2027-02-26	2027	1	2	February	8	26	5	Friday	f	f	\N	\N
20270227	2027-02-27	2027	1	2	February	8	27	6	Saturday	t	f	\N	\N
20270228	2027-02-28	2027	1	2	February	8	28	7	Sunday	t	t	\N	\N
20270301	2027-03-01	2027	1	3	March	9	1	1	Monday	f	f	\N	\N
20270302	2027-03-02	2027	1	3	March	9	2	2	Tuesday	f	f	\N	\N
20270303	2027-03-03	2027	1	3	March	9	3	3	Wednesday	f	f	\N	\N
20270304	2027-03-04	2027	1	3	March	9	4	4	Thursday	f	f	\N	\N
20270305	2027-03-05	2027	1	3	March	9	5	5	Friday	f	f	\N	\N
20270306	2027-03-06	2027	1	3	March	9	6	6	Saturday	t	f	\N	\N
20270307	2027-03-07	2027	1	3	March	9	7	7	Sunday	t	f	\N	\N
20270308	2027-03-08	2027	1	3	March	10	8	1	Monday	f	f	\N	\N
20270309	2027-03-09	2027	1	3	March	10	9	2	Tuesday	f	f	\N	\N
20270310	2027-03-10	2027	1	3	March	10	10	3	Wednesday	f	f	\N	\N
20270311	2027-03-11	2027	1	3	March	10	11	4	Thursday	f	f	\N	\N
20270312	2027-03-12	2027	1	3	March	10	12	5	Friday	f	f	\N	\N
20270313	2027-03-13	2027	1	3	March	10	13	6	Saturday	t	f	\N	\N
20270314	2027-03-14	2027	1	3	March	10	14	7	Sunday	t	f	\N	\N
20270315	2027-03-15	2027	1	3	March	11	15	1	Monday	f	f	\N	\N
20270316	2027-03-16	2027	1	3	March	11	16	2	Tuesday	f	f	\N	\N
20270317	2027-03-17	2027	1	3	March	11	17	3	Wednesday	f	f	\N	\N
20270318	2027-03-18	2027	1	3	March	11	18	4	Thursday	f	f	\N	\N
20270319	2027-03-19	2027	1	3	March	11	19	5	Friday	f	f	\N	\N
20270320	2027-03-20	2027	1	3	March	11	20	6	Saturday	t	f	\N	\N
20270321	2027-03-21	2027	1	3	March	11	21	7	Sunday	t	f	\N	\N
20270322	2027-03-22	2027	1	3	March	12	22	1	Monday	f	f	\N	\N
20270323	2027-03-23	2027	1	3	March	12	23	2	Tuesday	f	f	\N	\N
20270324	2027-03-24	2027	1	3	March	12	24	3	Wednesday	f	f	\N	\N
20270325	2027-03-25	2027	1	3	March	12	25	4	Thursday	f	f	\N	\N
20270326	2027-03-26	2027	1	3	March	12	26	5	Friday	f	f	\N	\N
20270327	2027-03-27	2027	1	3	March	12	27	6	Saturday	t	f	\N	\N
20270328	2027-03-28	2027	1	3	March	12	28	7	Sunday	t	f	\N	\N
20270329	2027-03-29	2027	1	3	March	13	29	1	Monday	f	f	\N	\N
20270330	2027-03-30	2027	1	3	March	13	30	2	Tuesday	f	f	\N	\N
20270331	2027-03-31	2027	1	3	March	13	31	3	Wednesday	f	t	\N	\N
20270401	2027-04-01	2027	2	4	April	13	1	4	Thursday	f	f	\N	\N
20270402	2027-04-02	2027	2	4	April	13	2	5	Friday	f	f	\N	\N
20270403	2027-04-03	2027	2	4	April	13	3	6	Saturday	t	f	\N	\N
20270404	2027-04-04	2027	2	4	April	13	4	7	Sunday	t	f	\N	\N
20270405	2027-04-05	2027	2	4	April	14	5	1	Monday	f	f	\N	\N
20270406	2027-04-06	2027	2	4	April	14	6	2	Tuesday	f	f	\N	\N
20270407	2027-04-07	2027	2	4	April	14	7	3	Wednesday	f	f	\N	\N
20270408	2027-04-08	2027	2	4	April	14	8	4	Thursday	f	f	\N	\N
20270409	2027-04-09	2027	2	4	April	14	9	5	Friday	f	f	\N	\N
20270410	2027-04-10	2027	2	4	April	14	10	6	Saturday	t	f	\N	\N
20270411	2027-04-11	2027	2	4	April	14	11	7	Sunday	t	f	\N	\N
20270412	2027-04-12	2027	2	4	April	15	12	1	Monday	f	f	\N	\N
20270413	2027-04-13	2027	2	4	April	15	13	2	Tuesday	f	f	\N	\N
20270414	2027-04-14	2027	2	4	April	15	14	3	Wednesday	f	f	\N	\N
20270415	2027-04-15	2027	2	4	April	15	15	4	Thursday	f	f	\N	\N
20270416	2027-04-16	2027	2	4	April	15	16	5	Friday	f	f	\N	\N
20270417	2027-04-17	2027	2	4	April	15	17	6	Saturday	t	f	\N	\N
20270418	2027-04-18	2027	2	4	April	15	18	7	Sunday	t	f	\N	\N
20270419	2027-04-19	2027	2	4	April	16	19	1	Monday	f	f	\N	\N
20270420	2027-04-20	2027	2	4	April	16	20	2	Tuesday	f	f	\N	\N
20270421	2027-04-21	2027	2	4	April	16	21	3	Wednesday	f	f	\N	\N
20270422	2027-04-22	2027	2	4	April	16	22	4	Thursday	f	f	\N	\N
20270423	2027-04-23	2027	2	4	April	16	23	5	Friday	f	f	\N	\N
20270424	2027-04-24	2027	2	4	April	16	24	6	Saturday	t	f	\N	\N
20270425	2027-04-25	2027	2	4	April	16	25	7	Sunday	t	f	\N	\N
20270426	2027-04-26	2027	2	4	April	17	26	1	Monday	f	f	\N	\N
20270427	2027-04-27	2027	2	4	April	17	27	2	Tuesday	f	f	\N	\N
20270428	2027-04-28	2027	2	4	April	17	28	3	Wednesday	f	f	\N	\N
20270429	2027-04-29	2027	2	4	April	17	29	4	Thursday	f	f	\N	\N
20270430	2027-04-30	2027	2	4	April	17	30	5	Friday	f	t	\N	\N
20270501	2027-05-01	2027	2	5	May	17	1	6	Saturday	t	f	\N	\N
20270502	2027-05-02	2027	2	5	May	17	2	7	Sunday	t	f	\N	\N
20270503	2027-05-03	2027	2	5	May	18	3	1	Monday	f	f	\N	\N
20270504	2027-05-04	2027	2	5	May	18	4	2	Tuesday	f	f	\N	\N
20270505	2027-05-05	2027	2	5	May	18	5	3	Wednesday	f	f	\N	\N
20270506	2027-05-06	2027	2	5	May	18	6	4	Thursday	f	f	\N	\N
20270507	2027-05-07	2027	2	5	May	18	7	5	Friday	f	f	\N	\N
20270508	2027-05-08	2027	2	5	May	18	8	6	Saturday	t	f	\N	\N
20270509	2027-05-09	2027	2	5	May	18	9	7	Sunday	t	f	\N	\N
20270510	2027-05-10	2027	2	5	May	19	10	1	Monday	f	f	\N	\N
20270511	2027-05-11	2027	2	5	May	19	11	2	Tuesday	f	f	\N	\N
20270512	2027-05-12	2027	2	5	May	19	12	3	Wednesday	f	f	\N	\N
20270513	2027-05-13	2027	2	5	May	19	13	4	Thursday	f	f	\N	\N
20270514	2027-05-14	2027	2	5	May	19	14	5	Friday	f	f	\N	\N
20270515	2027-05-15	2027	2	5	May	19	15	6	Saturday	t	f	\N	\N
20270516	2027-05-16	2027	2	5	May	19	16	7	Sunday	t	f	\N	\N
20270517	2027-05-17	2027	2	5	May	20	17	1	Monday	f	f	\N	\N
20270518	2027-05-18	2027	2	5	May	20	18	2	Tuesday	f	f	\N	\N
20270519	2027-05-19	2027	2	5	May	20	19	3	Wednesday	f	f	\N	\N
20270520	2027-05-20	2027	2	5	May	20	20	4	Thursday	f	f	\N	\N
20270521	2027-05-21	2027	2	5	May	20	21	5	Friday	f	f	\N	\N
20270522	2027-05-22	2027	2	5	May	20	22	6	Saturday	t	f	\N	\N
20270523	2027-05-23	2027	2	5	May	20	23	7	Sunday	t	f	\N	\N
20270524	2027-05-24	2027	2	5	May	21	24	1	Monday	f	f	\N	\N
20270525	2027-05-25	2027	2	5	May	21	25	2	Tuesday	f	f	\N	\N
20270526	2027-05-26	2027	2	5	May	21	26	3	Wednesday	f	f	\N	\N
20270527	2027-05-27	2027	2	5	May	21	27	4	Thursday	f	f	\N	\N
20270528	2027-05-28	2027	2	5	May	21	28	5	Friday	f	f	\N	\N
20270529	2027-05-29	2027	2	5	May	21	29	6	Saturday	t	f	\N	\N
20270530	2027-05-30	2027	2	5	May	21	30	7	Sunday	t	f	\N	\N
20270531	2027-05-31	2027	2	5	May	22	31	1	Monday	f	t	\N	\N
20270601	2027-06-01	2027	2	6	June	22	1	2	Tuesday	f	f	\N	\N
20270602	2027-06-02	2027	2	6	June	22	2	3	Wednesday	f	f	\N	\N
20270603	2027-06-03	2027	2	6	June	22	3	4	Thursday	f	f	\N	\N
20270604	2027-06-04	2027	2	6	June	22	4	5	Friday	f	f	\N	\N
20270605	2027-06-05	2027	2	6	June	22	5	6	Saturday	t	f	\N	\N
20270606	2027-06-06	2027	2	6	June	22	6	7	Sunday	t	f	\N	\N
20270607	2027-06-07	2027	2	6	June	23	7	1	Monday	f	f	\N	\N
20270608	2027-06-08	2027	2	6	June	23	8	2	Tuesday	f	f	\N	\N
20270609	2027-06-09	2027	2	6	June	23	9	3	Wednesday	f	f	\N	\N
20270610	2027-06-10	2027	2	6	June	23	10	4	Thursday	f	f	\N	\N
20270611	2027-06-11	2027	2	6	June	23	11	5	Friday	f	f	\N	\N
20270612	2027-06-12	2027	2	6	June	23	12	6	Saturday	t	f	\N	\N
20270613	2027-06-13	2027	2	6	June	23	13	7	Sunday	t	f	\N	\N
20270614	2027-06-14	2027	2	6	June	24	14	1	Monday	f	f	\N	\N
20270615	2027-06-15	2027	2	6	June	24	15	2	Tuesday	f	f	\N	\N
20270616	2027-06-16	2027	2	6	June	24	16	3	Wednesday	f	f	\N	\N
20270617	2027-06-17	2027	2	6	June	24	17	4	Thursday	f	f	\N	\N
20270618	2027-06-18	2027	2	6	June	24	18	5	Friday	f	f	\N	\N
20270619	2027-06-19	2027	2	6	June	24	19	6	Saturday	t	f	\N	\N
20270620	2027-06-20	2027	2	6	June	24	20	7	Sunday	t	f	\N	\N
20270621	2027-06-21	2027	2	6	June	25	21	1	Monday	f	f	\N	\N
20270622	2027-06-22	2027	2	6	June	25	22	2	Tuesday	f	f	\N	\N
20270623	2027-06-23	2027	2	6	June	25	23	3	Wednesday	f	f	\N	\N
20270624	2027-06-24	2027	2	6	June	25	24	4	Thursday	f	f	\N	\N
20270625	2027-06-25	2027	2	6	June	25	25	5	Friday	f	f	\N	\N
20270626	2027-06-26	2027	2	6	June	25	26	6	Saturday	t	f	\N	\N
20270627	2027-06-27	2027	2	6	June	25	27	7	Sunday	t	f	\N	\N
20270628	2027-06-28	2027	2	6	June	26	28	1	Monday	f	f	\N	\N
20270629	2027-06-29	2027	2	6	June	26	29	2	Tuesday	f	f	\N	\N
20270630	2027-06-30	2027	2	6	June	26	30	3	Wednesday	f	t	\N	\N
20270701	2027-07-01	2027	3	7	July	26	1	4	Thursday	f	f	\N	\N
20270702	2027-07-02	2027	3	7	July	26	2	5	Friday	f	f	\N	\N
20270703	2027-07-03	2027	3	7	July	26	3	6	Saturday	t	f	\N	\N
20270704	2027-07-04	2027	3	7	July	26	4	7	Sunday	t	f	\N	\N
20270705	2027-07-05	2027	3	7	July	27	5	1	Monday	f	f	\N	\N
20270706	2027-07-06	2027	3	7	July	27	6	2	Tuesday	f	f	\N	\N
20270707	2027-07-07	2027	3	7	July	27	7	3	Wednesday	f	f	\N	\N
20270708	2027-07-08	2027	3	7	July	27	8	4	Thursday	f	f	\N	\N
20270709	2027-07-09	2027	3	7	July	27	9	5	Friday	f	f	\N	\N
20270710	2027-07-10	2027	3	7	July	27	10	6	Saturday	t	f	\N	\N
20270711	2027-07-11	2027	3	7	July	27	11	7	Sunday	t	f	\N	\N
20270712	2027-07-12	2027	3	7	July	28	12	1	Monday	f	f	\N	\N
20270713	2027-07-13	2027	3	7	July	28	13	2	Tuesday	f	f	\N	\N
20270714	2027-07-14	2027	3	7	July	28	14	3	Wednesday	f	f	\N	\N
20270715	2027-07-15	2027	3	7	July	28	15	4	Thursday	f	f	\N	\N
20270716	2027-07-16	2027	3	7	July	28	16	5	Friday	f	f	\N	\N
20270717	2027-07-17	2027	3	7	July	28	17	6	Saturday	t	f	\N	\N
20270718	2027-07-18	2027	3	7	July	28	18	7	Sunday	t	f	\N	\N
20270719	2027-07-19	2027	3	7	July	29	19	1	Monday	f	f	\N	\N
20270720	2027-07-20	2027	3	7	July	29	20	2	Tuesday	f	f	\N	\N
20270721	2027-07-21	2027	3	7	July	29	21	3	Wednesday	f	f	\N	\N
20270722	2027-07-22	2027	3	7	July	29	22	4	Thursday	f	f	\N	\N
20270723	2027-07-23	2027	3	7	July	29	23	5	Friday	f	f	\N	\N
20270724	2027-07-24	2027	3	7	July	29	24	6	Saturday	t	f	\N	\N
20270725	2027-07-25	2027	3	7	July	29	25	7	Sunday	t	f	\N	\N
20270726	2027-07-26	2027	3	7	July	30	26	1	Monday	f	f	\N	\N
20270727	2027-07-27	2027	3	7	July	30	27	2	Tuesday	f	f	\N	\N
20270728	2027-07-28	2027	3	7	July	30	28	3	Wednesday	f	f	\N	\N
20270729	2027-07-29	2027	3	7	July	30	29	4	Thursday	f	f	\N	\N
20270730	2027-07-30	2027	3	7	July	30	30	5	Friday	f	f	\N	\N
20270731	2027-07-31	2027	3	7	July	30	31	6	Saturday	t	t	\N	\N
20270801	2027-08-01	2027	3	8	August	30	1	7	Sunday	t	f	\N	\N
20270802	2027-08-02	2027	3	8	August	31	2	1	Monday	f	f	\N	\N
20270803	2027-08-03	2027	3	8	August	31	3	2	Tuesday	f	f	\N	\N
20270804	2027-08-04	2027	3	8	August	31	4	3	Wednesday	f	f	\N	\N
20270805	2027-08-05	2027	3	8	August	31	5	4	Thursday	f	f	\N	\N
20270806	2027-08-06	2027	3	8	August	31	6	5	Friday	f	f	\N	\N
20270807	2027-08-07	2027	3	8	August	31	7	6	Saturday	t	f	\N	\N
20270808	2027-08-08	2027	3	8	August	31	8	7	Sunday	t	f	\N	\N
20270809	2027-08-09	2027	3	8	August	32	9	1	Monday	f	f	\N	\N
20270810	2027-08-10	2027	3	8	August	32	10	2	Tuesday	f	f	\N	\N
20270811	2027-08-11	2027	3	8	August	32	11	3	Wednesday	f	f	\N	\N
20270812	2027-08-12	2027	3	8	August	32	12	4	Thursday	f	f	\N	\N
20270813	2027-08-13	2027	3	8	August	32	13	5	Friday	f	f	\N	\N
20270814	2027-08-14	2027	3	8	August	32	14	6	Saturday	t	f	\N	\N
20270815	2027-08-15	2027	3	8	August	32	15	7	Sunday	t	f	\N	\N
20270816	2027-08-16	2027	3	8	August	33	16	1	Monday	f	f	\N	\N
20270817	2027-08-17	2027	3	8	August	33	17	2	Tuesday	f	f	\N	\N
20270818	2027-08-18	2027	3	8	August	33	18	3	Wednesday	f	f	\N	\N
20270819	2027-08-19	2027	3	8	August	33	19	4	Thursday	f	f	\N	\N
20270820	2027-08-20	2027	3	8	August	33	20	5	Friday	f	f	\N	\N
20270821	2027-08-21	2027	3	8	August	33	21	6	Saturday	t	f	\N	\N
20270822	2027-08-22	2027	3	8	August	33	22	7	Sunday	t	f	\N	\N
20270823	2027-08-23	2027	3	8	August	34	23	1	Monday	f	f	\N	\N
20270824	2027-08-24	2027	3	8	August	34	24	2	Tuesday	f	f	\N	\N
20270825	2027-08-25	2027	3	8	August	34	25	3	Wednesday	f	f	\N	\N
20270826	2027-08-26	2027	3	8	August	34	26	4	Thursday	f	f	\N	\N
20270827	2027-08-27	2027	3	8	August	34	27	5	Friday	f	f	\N	\N
20270828	2027-08-28	2027	3	8	August	34	28	6	Saturday	t	f	\N	\N
20270829	2027-08-29	2027	3	8	August	34	29	7	Sunday	t	f	\N	\N
20270830	2027-08-30	2027	3	8	August	35	30	1	Monday	f	f	\N	\N
20270831	2027-08-31	2027	3	8	August	35	31	2	Tuesday	f	t	\N	\N
20270901	2027-09-01	2027	3	9	September	35	1	3	Wednesday	f	f	\N	\N
20270902	2027-09-02	2027	3	9	September	35	2	4	Thursday	f	f	\N	\N
20270903	2027-09-03	2027	3	9	September	35	3	5	Friday	f	f	\N	\N
20270904	2027-09-04	2027	3	9	September	35	4	6	Saturday	t	f	\N	\N
20270905	2027-09-05	2027	3	9	September	35	5	7	Sunday	t	f	\N	\N
20270906	2027-09-06	2027	3	9	September	36	6	1	Monday	f	f	\N	\N
20270907	2027-09-07	2027	3	9	September	36	7	2	Tuesday	f	f	\N	\N
20270908	2027-09-08	2027	3	9	September	36	8	3	Wednesday	f	f	\N	\N
20270909	2027-09-09	2027	3	9	September	36	9	4	Thursday	f	f	\N	\N
20270910	2027-09-10	2027	3	9	September	36	10	5	Friday	f	f	\N	\N
20270911	2027-09-11	2027	3	9	September	36	11	6	Saturday	t	f	\N	\N
20270912	2027-09-12	2027	3	9	September	36	12	7	Sunday	t	f	\N	\N
20270913	2027-09-13	2027	3	9	September	37	13	1	Monday	f	f	\N	\N
20270914	2027-09-14	2027	3	9	September	37	14	2	Tuesday	f	f	\N	\N
20270915	2027-09-15	2027	3	9	September	37	15	3	Wednesday	f	f	\N	\N
20270916	2027-09-16	2027	3	9	September	37	16	4	Thursday	f	f	\N	\N
20270917	2027-09-17	2027	3	9	September	37	17	5	Friday	f	f	\N	\N
20270918	2027-09-18	2027	3	9	September	37	18	6	Saturday	t	f	\N	\N
20270919	2027-09-19	2027	3	9	September	37	19	7	Sunday	t	f	\N	\N
20270920	2027-09-20	2027	3	9	September	38	20	1	Monday	f	f	\N	\N
20270921	2027-09-21	2027	3	9	September	38	21	2	Tuesday	f	f	\N	\N
20270922	2027-09-22	2027	3	9	September	38	22	3	Wednesday	f	f	\N	\N
20270923	2027-09-23	2027	3	9	September	38	23	4	Thursday	f	f	\N	\N
20270924	2027-09-24	2027	3	9	September	38	24	5	Friday	f	f	\N	\N
20270925	2027-09-25	2027	3	9	September	38	25	6	Saturday	t	f	\N	\N
20270926	2027-09-26	2027	3	9	September	38	26	7	Sunday	t	f	\N	\N
20270927	2027-09-27	2027	3	9	September	39	27	1	Monday	f	f	\N	\N
20270928	2027-09-28	2027	3	9	September	39	28	2	Tuesday	f	f	\N	\N
20270929	2027-09-29	2027	3	9	September	39	29	3	Wednesday	f	f	\N	\N
20270930	2027-09-30	2027	3	9	September	39	30	4	Thursday	f	t	\N	\N
20271001	2027-10-01	2027	4	10	October	39	1	5	Friday	f	f	\N	\N
20271002	2027-10-02	2027	4	10	October	39	2	6	Saturday	t	f	\N	\N
20271003	2027-10-03	2027	4	10	October	39	3	7	Sunday	t	f	\N	\N
20271004	2027-10-04	2027	4	10	October	40	4	1	Monday	f	f	\N	\N
20271005	2027-10-05	2027	4	10	October	40	5	2	Tuesday	f	f	\N	\N
20271006	2027-10-06	2027	4	10	October	40	6	3	Wednesday	f	f	\N	\N
20271007	2027-10-07	2027	4	10	October	40	7	4	Thursday	f	f	\N	\N
20271008	2027-10-08	2027	4	10	October	40	8	5	Friday	f	f	\N	\N
20271009	2027-10-09	2027	4	10	October	40	9	6	Saturday	t	f	\N	\N
20271010	2027-10-10	2027	4	10	October	40	10	7	Sunday	t	f	\N	\N
20271011	2027-10-11	2027	4	10	October	41	11	1	Monday	f	f	\N	\N
20271012	2027-10-12	2027	4	10	October	41	12	2	Tuesday	f	f	\N	\N
20271013	2027-10-13	2027	4	10	October	41	13	3	Wednesday	f	f	\N	\N
20271014	2027-10-14	2027	4	10	October	41	14	4	Thursday	f	f	\N	\N
20271015	2027-10-15	2027	4	10	October	41	15	5	Friday	f	f	\N	\N
20271016	2027-10-16	2027	4	10	October	41	16	6	Saturday	t	f	\N	\N
20271017	2027-10-17	2027	4	10	October	41	17	7	Sunday	t	f	\N	\N
20271018	2027-10-18	2027	4	10	October	42	18	1	Monday	f	f	\N	\N
20271019	2027-10-19	2027	4	10	October	42	19	2	Tuesday	f	f	\N	\N
20271020	2027-10-20	2027	4	10	October	42	20	3	Wednesday	f	f	\N	\N
20271021	2027-10-21	2027	4	10	October	42	21	4	Thursday	f	f	\N	\N
20271022	2027-10-22	2027	4	10	October	42	22	5	Friday	f	f	\N	\N
20271023	2027-10-23	2027	4	10	October	42	23	6	Saturday	t	f	\N	\N
20271024	2027-10-24	2027	4	10	October	42	24	7	Sunday	t	f	\N	\N
20271025	2027-10-25	2027	4	10	October	43	25	1	Monday	f	f	\N	\N
20271026	2027-10-26	2027	4	10	October	43	26	2	Tuesday	f	f	\N	\N
20271027	2027-10-27	2027	4	10	October	43	27	3	Wednesday	f	f	\N	\N
20271028	2027-10-28	2027	4	10	October	43	28	4	Thursday	f	f	\N	\N
20271029	2027-10-29	2027	4	10	October	43	29	5	Friday	f	f	\N	\N
20271030	2027-10-30	2027	4	10	October	43	30	6	Saturday	t	f	\N	\N
20271031	2027-10-31	2027	4	10	October	43	31	7	Sunday	t	t	\N	\N
20271101	2027-11-01	2027	4	11	November	44	1	1	Monday	f	f	\N	\N
20271102	2027-11-02	2027	4	11	November	44	2	2	Tuesday	f	f	\N	\N
20271103	2027-11-03	2027	4	11	November	44	3	3	Wednesday	f	f	\N	\N
20271104	2027-11-04	2027	4	11	November	44	4	4	Thursday	f	f	\N	\N
20271105	2027-11-05	2027	4	11	November	44	5	5	Friday	f	f	\N	\N
20271106	2027-11-06	2027	4	11	November	44	6	6	Saturday	t	f	\N	\N
20271107	2027-11-07	2027	4	11	November	44	7	7	Sunday	t	f	\N	\N
20271108	2027-11-08	2027	4	11	November	45	8	1	Monday	f	f	\N	\N
20271109	2027-11-09	2027	4	11	November	45	9	2	Tuesday	f	f	\N	\N
20271110	2027-11-10	2027	4	11	November	45	10	3	Wednesday	f	f	\N	\N
20271111	2027-11-11	2027	4	11	November	45	11	4	Thursday	f	f	\N	\N
20271112	2027-11-12	2027	4	11	November	45	12	5	Friday	f	f	\N	\N
20271113	2027-11-13	2027	4	11	November	45	13	6	Saturday	t	f	\N	\N
20271114	2027-11-14	2027	4	11	November	45	14	7	Sunday	t	f	\N	\N
20271115	2027-11-15	2027	4	11	November	46	15	1	Monday	f	f	\N	\N
20271116	2027-11-16	2027	4	11	November	46	16	2	Tuesday	f	f	\N	\N
20271117	2027-11-17	2027	4	11	November	46	17	3	Wednesday	f	f	\N	\N
20271118	2027-11-18	2027	4	11	November	46	18	4	Thursday	f	f	\N	\N
20271119	2027-11-19	2027	4	11	November	46	19	5	Friday	f	f	\N	\N
20271120	2027-11-20	2027	4	11	November	46	20	6	Saturday	t	f	\N	\N
20271121	2027-11-21	2027	4	11	November	46	21	7	Sunday	t	f	\N	\N
20271122	2027-11-22	2027	4	11	November	47	22	1	Monday	f	f	\N	\N
20271123	2027-11-23	2027	4	11	November	47	23	2	Tuesday	f	f	\N	\N
20271124	2027-11-24	2027	4	11	November	47	24	3	Wednesday	f	f	\N	\N
20271125	2027-11-25	2027	4	11	November	47	25	4	Thursday	f	f	\N	\N
20271126	2027-11-26	2027	4	11	November	47	26	5	Friday	f	f	\N	\N
20271127	2027-11-27	2027	4	11	November	47	27	6	Saturday	t	f	\N	\N
20271128	2027-11-28	2027	4	11	November	47	28	7	Sunday	t	f	\N	\N
20271129	2027-11-29	2027	4	11	November	48	29	1	Monday	f	f	\N	\N
20271130	2027-11-30	2027	4	11	November	48	30	2	Tuesday	f	t	\N	\N
20271201	2027-12-01	2027	4	12	December	48	1	3	Wednesday	f	f	\N	\N
20271202	2027-12-02	2027	4	12	December	48	2	4	Thursday	f	f	\N	\N
20271203	2027-12-03	2027	4	12	December	48	3	5	Friday	f	f	\N	\N
20271204	2027-12-04	2027	4	12	December	48	4	6	Saturday	t	f	\N	\N
20271205	2027-12-05	2027	4	12	December	48	5	7	Sunday	t	f	\N	\N
20271206	2027-12-06	2027	4	12	December	49	6	1	Monday	f	f	\N	\N
20271207	2027-12-07	2027	4	12	December	49	7	2	Tuesday	f	f	\N	\N
20271208	2027-12-08	2027	4	12	December	49	8	3	Wednesday	f	f	\N	\N
20271209	2027-12-09	2027	4	12	December	49	9	4	Thursday	f	f	\N	\N
20271210	2027-12-10	2027	4	12	December	49	10	5	Friday	f	f	\N	\N
20271211	2027-12-11	2027	4	12	December	49	11	6	Saturday	t	f	\N	\N
20271212	2027-12-12	2027	4	12	December	49	12	7	Sunday	t	f	\N	\N
20271213	2027-12-13	2027	4	12	December	50	13	1	Monday	f	f	\N	\N
20271214	2027-12-14	2027	4	12	December	50	14	2	Tuesday	f	f	\N	\N
20271215	2027-12-15	2027	4	12	December	50	15	3	Wednesday	f	f	\N	\N
20271216	2027-12-16	2027	4	12	December	50	16	4	Thursday	f	f	\N	\N
20271217	2027-12-17	2027	4	12	December	50	17	5	Friday	f	f	\N	\N
20271218	2027-12-18	2027	4	12	December	50	18	6	Saturday	t	f	\N	\N
20271219	2027-12-19	2027	4	12	December	50	19	7	Sunday	t	f	\N	\N
20271220	2027-12-20	2027	4	12	December	51	20	1	Monday	f	f	\N	\N
20271221	2027-12-21	2027	4	12	December	51	21	2	Tuesday	f	f	\N	\N
20271222	2027-12-22	2027	4	12	December	51	22	3	Wednesday	f	f	\N	\N
20271223	2027-12-23	2027	4	12	December	51	23	4	Thursday	f	f	\N	\N
20271224	2027-12-24	2027	4	12	December	51	24	5	Friday	f	f	\N	\N
20271225	2027-12-25	2027	4	12	December	51	25	6	Saturday	t	f	\N	\N
20271226	2027-12-26	2027	4	12	December	51	26	7	Sunday	t	f	\N	\N
20271227	2027-12-27	2027	4	12	December	52	27	1	Monday	f	f	\N	\N
20271228	2027-12-28	2027	4	12	December	52	28	2	Tuesday	f	f	\N	\N
20271229	2027-12-29	2027	4	12	December	52	29	3	Wednesday	f	f	\N	\N
20271230	2027-12-30	2027	4	12	December	52	30	4	Thursday	f	f	\N	\N
20271231	2027-12-31	2027	4	12	December	52	31	5	Friday	f	t	\N	\N
20280101	2028-01-01	2028	1	1	January	52	1	6	Saturday	t	f	\N	\N
20280102	2028-01-02	2028	1	1	January	52	2	7	Sunday	t	f	\N	\N
20280103	2028-01-03	2028	1	1	January	1	3	1	Monday	f	f	\N	\N
20280104	2028-01-04	2028	1	1	January	1	4	2	Tuesday	f	f	\N	\N
20280105	2028-01-05	2028	1	1	January	1	5	3	Wednesday	f	f	\N	\N
20280106	2028-01-06	2028	1	1	January	1	6	4	Thursday	f	f	\N	\N
20280107	2028-01-07	2028	1	1	January	1	7	5	Friday	f	f	\N	\N
20280108	2028-01-08	2028	1	1	January	1	8	6	Saturday	t	f	\N	\N
20280109	2028-01-09	2028	1	1	January	1	9	7	Sunday	t	f	\N	\N
20280110	2028-01-10	2028	1	1	January	2	10	1	Monday	f	f	\N	\N
20280111	2028-01-11	2028	1	1	January	2	11	2	Tuesday	f	f	\N	\N
20280112	2028-01-12	2028	1	1	January	2	12	3	Wednesday	f	f	\N	\N
20280113	2028-01-13	2028	1	1	January	2	13	4	Thursday	f	f	\N	\N
20280114	2028-01-14	2028	1	1	January	2	14	5	Friday	f	f	\N	\N
20280115	2028-01-15	2028	1	1	January	2	15	6	Saturday	t	f	\N	\N
20280116	2028-01-16	2028	1	1	January	2	16	7	Sunday	t	f	\N	\N
20280117	2028-01-17	2028	1	1	January	3	17	1	Monday	f	f	\N	\N
20280118	2028-01-18	2028	1	1	January	3	18	2	Tuesday	f	f	\N	\N
20280119	2028-01-19	2028	1	1	January	3	19	3	Wednesday	f	f	\N	\N
20280120	2028-01-20	2028	1	1	January	3	20	4	Thursday	f	f	\N	\N
20280121	2028-01-21	2028	1	1	January	3	21	5	Friday	f	f	\N	\N
20280122	2028-01-22	2028	1	1	January	3	22	6	Saturday	t	f	\N	\N
20280123	2028-01-23	2028	1	1	January	3	23	7	Sunday	t	f	\N	\N
20280124	2028-01-24	2028	1	1	January	4	24	1	Monday	f	f	\N	\N
20280125	2028-01-25	2028	1	1	January	4	25	2	Tuesday	f	f	\N	\N
20280126	2028-01-26	2028	1	1	January	4	26	3	Wednesday	f	f	\N	\N
20280127	2028-01-27	2028	1	1	January	4	27	4	Thursday	f	f	\N	\N
20280128	2028-01-28	2028	1	1	January	4	28	5	Friday	f	f	\N	\N
20280129	2028-01-29	2028	1	1	January	4	29	6	Saturday	t	f	\N	\N
20280130	2028-01-30	2028	1	1	January	4	30	7	Sunday	t	f	\N	\N
20280131	2028-01-31	2028	1	1	January	5	31	1	Monday	f	t	\N	\N
20280201	2028-02-01	2028	1	2	February	5	1	2	Tuesday	f	f	\N	\N
20280202	2028-02-02	2028	1	2	February	5	2	3	Wednesday	f	f	\N	\N
20280203	2028-02-03	2028	1	2	February	5	3	4	Thursday	f	f	\N	\N
20280204	2028-02-04	2028	1	2	February	5	4	5	Friday	f	f	\N	\N
20280205	2028-02-05	2028	1	2	February	5	5	6	Saturday	t	f	\N	\N
20280206	2028-02-06	2028	1	2	February	5	6	7	Sunday	t	f	\N	\N
20280207	2028-02-07	2028	1	2	February	6	7	1	Monday	f	f	\N	\N
20280208	2028-02-08	2028	1	2	February	6	8	2	Tuesday	f	f	\N	\N
20280209	2028-02-09	2028	1	2	February	6	9	3	Wednesday	f	f	\N	\N
20280210	2028-02-10	2028	1	2	February	6	10	4	Thursday	f	f	\N	\N
20280211	2028-02-11	2028	1	2	February	6	11	5	Friday	f	f	\N	\N
20280212	2028-02-12	2028	1	2	February	6	12	6	Saturday	t	f	\N	\N
20280213	2028-02-13	2028	1	2	February	6	13	7	Sunday	t	f	\N	\N
20280214	2028-02-14	2028	1	2	February	7	14	1	Monday	f	f	\N	\N
20280215	2028-02-15	2028	1	2	February	7	15	2	Tuesday	f	f	\N	\N
20280216	2028-02-16	2028	1	2	February	7	16	3	Wednesday	f	f	\N	\N
20280217	2028-02-17	2028	1	2	February	7	17	4	Thursday	f	f	\N	\N
20280218	2028-02-18	2028	1	2	February	7	18	5	Friday	f	f	\N	\N
20280219	2028-02-19	2028	1	2	February	7	19	6	Saturday	t	f	\N	\N
20280220	2028-02-20	2028	1	2	February	7	20	7	Sunday	t	f	\N	\N
20280221	2028-02-21	2028	1	2	February	8	21	1	Monday	f	f	\N	\N
20280222	2028-02-22	2028	1	2	February	8	22	2	Tuesday	f	f	\N	\N
20280223	2028-02-23	2028	1	2	February	8	23	3	Wednesday	f	f	\N	\N
20280224	2028-02-24	2028	1	2	February	8	24	4	Thursday	f	f	\N	\N
20280225	2028-02-25	2028	1	2	February	8	25	5	Friday	f	f	\N	\N
20280226	2028-02-26	2028	1	2	February	8	26	6	Saturday	t	f	\N	\N
20280227	2028-02-27	2028	1	2	February	8	27	7	Sunday	t	f	\N	\N
20280228	2028-02-28	2028	1	2	February	9	28	1	Monday	f	f	\N	\N
20280229	2028-02-29	2028	1	2	February	9	29	2	Tuesday	f	t	\N	\N
20280301	2028-03-01	2028	1	3	March	9	1	3	Wednesday	f	f	\N	\N
20280302	2028-03-02	2028	1	3	March	9	2	4	Thursday	f	f	\N	\N
20280303	2028-03-03	2028	1	3	March	9	3	5	Friday	f	f	\N	\N
20280304	2028-03-04	2028	1	3	March	9	4	6	Saturday	t	f	\N	\N
20280305	2028-03-05	2028	1	3	March	9	5	7	Sunday	t	f	\N	\N
20280306	2028-03-06	2028	1	3	March	10	6	1	Monday	f	f	\N	\N
20280307	2028-03-07	2028	1	3	March	10	7	2	Tuesday	f	f	\N	\N
20280308	2028-03-08	2028	1	3	March	10	8	3	Wednesday	f	f	\N	\N
20280309	2028-03-09	2028	1	3	March	10	9	4	Thursday	f	f	\N	\N
20280310	2028-03-10	2028	1	3	March	10	10	5	Friday	f	f	\N	\N
20280311	2028-03-11	2028	1	3	March	10	11	6	Saturday	t	f	\N	\N
20280312	2028-03-12	2028	1	3	March	10	12	7	Sunday	t	f	\N	\N
20280313	2028-03-13	2028	1	3	March	11	13	1	Monday	f	f	\N	\N
20280314	2028-03-14	2028	1	3	March	11	14	2	Tuesday	f	f	\N	\N
20280315	2028-03-15	2028	1	3	March	11	15	3	Wednesday	f	f	\N	\N
20280316	2028-03-16	2028	1	3	March	11	16	4	Thursday	f	f	\N	\N
20280317	2028-03-17	2028	1	3	March	11	17	5	Friday	f	f	\N	\N
20280318	2028-03-18	2028	1	3	March	11	18	6	Saturday	t	f	\N	\N
20280319	2028-03-19	2028	1	3	March	11	19	7	Sunday	t	f	\N	\N
20280320	2028-03-20	2028	1	3	March	12	20	1	Monday	f	f	\N	\N
20280321	2028-03-21	2028	1	3	March	12	21	2	Tuesday	f	f	\N	\N
20280322	2028-03-22	2028	1	3	March	12	22	3	Wednesday	f	f	\N	\N
20280323	2028-03-23	2028	1	3	March	12	23	4	Thursday	f	f	\N	\N
20280324	2028-03-24	2028	1	3	March	12	24	5	Friday	f	f	\N	\N
20280325	2028-03-25	2028	1	3	March	12	25	6	Saturday	t	f	\N	\N
20280326	2028-03-26	2028	1	3	March	12	26	7	Sunday	t	f	\N	\N
20280327	2028-03-27	2028	1	3	March	13	27	1	Monday	f	f	\N	\N
20280328	2028-03-28	2028	1	3	March	13	28	2	Tuesday	f	f	\N	\N
20280329	2028-03-29	2028	1	3	March	13	29	3	Wednesday	f	f	\N	\N
20280330	2028-03-30	2028	1	3	March	13	30	4	Thursday	f	f	\N	\N
20280331	2028-03-31	2028	1	3	March	13	31	5	Friday	f	t	\N	\N
20280401	2028-04-01	2028	2	4	April	13	1	6	Saturday	t	f	\N	\N
20280402	2028-04-02	2028	2	4	April	13	2	7	Sunday	t	f	\N	\N
20280403	2028-04-03	2028	2	4	April	14	3	1	Monday	f	f	\N	\N
20280404	2028-04-04	2028	2	4	April	14	4	2	Tuesday	f	f	\N	\N
20280405	2028-04-05	2028	2	4	April	14	5	3	Wednesday	f	f	\N	\N
20280406	2028-04-06	2028	2	4	April	14	6	4	Thursday	f	f	\N	\N
20280407	2028-04-07	2028	2	4	April	14	7	5	Friday	f	f	\N	\N
20280408	2028-04-08	2028	2	4	April	14	8	6	Saturday	t	f	\N	\N
20280409	2028-04-09	2028	2	4	April	14	9	7	Sunday	t	f	\N	\N
20280410	2028-04-10	2028	2	4	April	15	10	1	Monday	f	f	\N	\N
20280411	2028-04-11	2028	2	4	April	15	11	2	Tuesday	f	f	\N	\N
20280412	2028-04-12	2028	2	4	April	15	12	3	Wednesday	f	f	\N	\N
20280413	2028-04-13	2028	2	4	April	15	13	4	Thursday	f	f	\N	\N
20280414	2028-04-14	2028	2	4	April	15	14	5	Friday	f	f	\N	\N
20280415	2028-04-15	2028	2	4	April	15	15	6	Saturday	t	f	\N	\N
20280416	2028-04-16	2028	2	4	April	15	16	7	Sunday	t	f	\N	\N
20280417	2028-04-17	2028	2	4	April	16	17	1	Monday	f	f	\N	\N
20280418	2028-04-18	2028	2	4	April	16	18	2	Tuesday	f	f	\N	\N
20280419	2028-04-19	2028	2	4	April	16	19	3	Wednesday	f	f	\N	\N
20280420	2028-04-20	2028	2	4	April	16	20	4	Thursday	f	f	\N	\N
20280421	2028-04-21	2028	2	4	April	16	21	5	Friday	f	f	\N	\N
20280422	2028-04-22	2028	2	4	April	16	22	6	Saturday	t	f	\N	\N
20280423	2028-04-23	2028	2	4	April	16	23	7	Sunday	t	f	\N	\N
20280424	2028-04-24	2028	2	4	April	17	24	1	Monday	f	f	\N	\N
20280425	2028-04-25	2028	2	4	April	17	25	2	Tuesday	f	f	\N	\N
20280426	2028-04-26	2028	2	4	April	17	26	3	Wednesday	f	f	\N	\N
20280427	2028-04-27	2028	2	4	April	17	27	4	Thursday	f	f	\N	\N
20280428	2028-04-28	2028	2	4	April	17	28	5	Friday	f	f	\N	\N
20280429	2028-04-29	2028	2	4	April	17	29	6	Saturday	t	f	\N	\N
20280430	2028-04-30	2028	2	4	April	17	30	7	Sunday	t	t	\N	\N
20280501	2028-05-01	2028	2	5	May	18	1	1	Monday	f	f	\N	\N
20280502	2028-05-02	2028	2	5	May	18	2	2	Tuesday	f	f	\N	\N
20280503	2028-05-03	2028	2	5	May	18	3	3	Wednesday	f	f	\N	\N
20280504	2028-05-04	2028	2	5	May	18	4	4	Thursday	f	f	\N	\N
20280505	2028-05-05	2028	2	5	May	18	5	5	Friday	f	f	\N	\N
20280506	2028-05-06	2028	2	5	May	18	6	6	Saturday	t	f	\N	\N
20280507	2028-05-07	2028	2	5	May	18	7	7	Sunday	t	f	\N	\N
20280508	2028-05-08	2028	2	5	May	19	8	1	Monday	f	f	\N	\N
20280509	2028-05-09	2028	2	5	May	19	9	2	Tuesday	f	f	\N	\N
20280510	2028-05-10	2028	2	5	May	19	10	3	Wednesday	f	f	\N	\N
20280511	2028-05-11	2028	2	5	May	19	11	4	Thursday	f	f	\N	\N
20280512	2028-05-12	2028	2	5	May	19	12	5	Friday	f	f	\N	\N
20280513	2028-05-13	2028	2	5	May	19	13	6	Saturday	t	f	\N	\N
20280514	2028-05-14	2028	2	5	May	19	14	7	Sunday	t	f	\N	\N
20280515	2028-05-15	2028	2	5	May	20	15	1	Monday	f	f	\N	\N
20280516	2028-05-16	2028	2	5	May	20	16	2	Tuesday	f	f	\N	\N
20280517	2028-05-17	2028	2	5	May	20	17	3	Wednesday	f	f	\N	\N
20280518	2028-05-18	2028	2	5	May	20	18	4	Thursday	f	f	\N	\N
20280519	2028-05-19	2028	2	5	May	20	19	5	Friday	f	f	\N	\N
20280520	2028-05-20	2028	2	5	May	20	20	6	Saturday	t	f	\N	\N
20280521	2028-05-21	2028	2	5	May	20	21	7	Sunday	t	f	\N	\N
20280522	2028-05-22	2028	2	5	May	21	22	1	Monday	f	f	\N	\N
20280523	2028-05-23	2028	2	5	May	21	23	2	Tuesday	f	f	\N	\N
20280524	2028-05-24	2028	2	5	May	21	24	3	Wednesday	f	f	\N	\N
20280525	2028-05-25	2028	2	5	May	21	25	4	Thursday	f	f	\N	\N
20280526	2028-05-26	2028	2	5	May	21	26	5	Friday	f	f	\N	\N
20280527	2028-05-27	2028	2	5	May	21	27	6	Saturday	t	f	\N	\N
20280528	2028-05-28	2028	2	5	May	21	28	7	Sunday	t	f	\N	\N
20280529	2028-05-29	2028	2	5	May	22	29	1	Monday	f	f	\N	\N
20280530	2028-05-30	2028	2	5	May	22	30	2	Tuesday	f	f	\N	\N
20280531	2028-05-31	2028	2	5	May	22	31	3	Wednesday	f	t	\N	\N
20280601	2028-06-01	2028	2	6	June	22	1	4	Thursday	f	f	\N	\N
20280602	2028-06-02	2028	2	6	June	22	2	5	Friday	f	f	\N	\N
20280603	2028-06-03	2028	2	6	June	22	3	6	Saturday	t	f	\N	\N
20280604	2028-06-04	2028	2	6	June	22	4	7	Sunday	t	f	\N	\N
20280605	2028-06-05	2028	2	6	June	23	5	1	Monday	f	f	\N	\N
20280606	2028-06-06	2028	2	6	June	23	6	2	Tuesday	f	f	\N	\N
20280607	2028-06-07	2028	2	6	June	23	7	3	Wednesday	f	f	\N	\N
20280608	2028-06-08	2028	2	6	June	23	8	4	Thursday	f	f	\N	\N
20280609	2028-06-09	2028	2	6	June	23	9	5	Friday	f	f	\N	\N
20280610	2028-06-10	2028	2	6	June	23	10	6	Saturday	t	f	\N	\N
20280611	2028-06-11	2028	2	6	June	23	11	7	Sunday	t	f	\N	\N
20280612	2028-06-12	2028	2	6	June	24	12	1	Monday	f	f	\N	\N
20280613	2028-06-13	2028	2	6	June	24	13	2	Tuesday	f	f	\N	\N
20280614	2028-06-14	2028	2	6	June	24	14	3	Wednesday	f	f	\N	\N
20280615	2028-06-15	2028	2	6	June	24	15	4	Thursday	f	f	\N	\N
20280616	2028-06-16	2028	2	6	June	24	16	5	Friday	f	f	\N	\N
20280617	2028-06-17	2028	2	6	June	24	17	6	Saturday	t	f	\N	\N
20280618	2028-06-18	2028	2	6	June	24	18	7	Sunday	t	f	\N	\N
20280619	2028-06-19	2028	2	6	June	25	19	1	Monday	f	f	\N	\N
20280620	2028-06-20	2028	2	6	June	25	20	2	Tuesday	f	f	\N	\N
20280621	2028-06-21	2028	2	6	June	25	21	3	Wednesday	f	f	\N	\N
20280622	2028-06-22	2028	2	6	June	25	22	4	Thursday	f	f	\N	\N
20280623	2028-06-23	2028	2	6	June	25	23	5	Friday	f	f	\N	\N
20280624	2028-06-24	2028	2	6	June	25	24	6	Saturday	t	f	\N	\N
20280625	2028-06-25	2028	2	6	June	25	25	7	Sunday	t	f	\N	\N
20280626	2028-06-26	2028	2	6	June	26	26	1	Monday	f	f	\N	\N
20280627	2028-06-27	2028	2	6	June	26	27	2	Tuesday	f	f	\N	\N
20280628	2028-06-28	2028	2	6	June	26	28	3	Wednesday	f	f	\N	\N
20280629	2028-06-29	2028	2	6	June	26	29	4	Thursday	f	f	\N	\N
20280630	2028-06-30	2028	2	6	June	26	30	5	Friday	f	t	\N	\N
20280701	2028-07-01	2028	3	7	July	26	1	6	Saturday	t	f	\N	\N
20280702	2028-07-02	2028	3	7	July	26	2	7	Sunday	t	f	\N	\N
20280703	2028-07-03	2028	3	7	July	27	3	1	Monday	f	f	\N	\N
20280704	2028-07-04	2028	3	7	July	27	4	2	Tuesday	f	f	\N	\N
20280705	2028-07-05	2028	3	7	July	27	5	3	Wednesday	f	f	\N	\N
20280706	2028-07-06	2028	3	7	July	27	6	4	Thursday	f	f	\N	\N
20280707	2028-07-07	2028	3	7	July	27	7	5	Friday	f	f	\N	\N
20280708	2028-07-08	2028	3	7	July	27	8	6	Saturday	t	f	\N	\N
20280709	2028-07-09	2028	3	7	July	27	9	7	Sunday	t	f	\N	\N
20280710	2028-07-10	2028	3	7	July	28	10	1	Monday	f	f	\N	\N
20280711	2028-07-11	2028	3	7	July	28	11	2	Tuesday	f	f	\N	\N
20280712	2028-07-12	2028	3	7	July	28	12	3	Wednesday	f	f	\N	\N
20280713	2028-07-13	2028	3	7	July	28	13	4	Thursday	f	f	\N	\N
20280714	2028-07-14	2028	3	7	July	28	14	5	Friday	f	f	\N	\N
20280715	2028-07-15	2028	3	7	July	28	15	6	Saturday	t	f	\N	\N
20280716	2028-07-16	2028	3	7	July	28	16	7	Sunday	t	f	\N	\N
20280717	2028-07-17	2028	3	7	July	29	17	1	Monday	f	f	\N	\N
20280718	2028-07-18	2028	3	7	July	29	18	2	Tuesday	f	f	\N	\N
20280719	2028-07-19	2028	3	7	July	29	19	3	Wednesday	f	f	\N	\N
20280720	2028-07-20	2028	3	7	July	29	20	4	Thursday	f	f	\N	\N
20280721	2028-07-21	2028	3	7	July	29	21	5	Friday	f	f	\N	\N
20280722	2028-07-22	2028	3	7	July	29	22	6	Saturday	t	f	\N	\N
20280723	2028-07-23	2028	3	7	July	29	23	7	Sunday	t	f	\N	\N
20280724	2028-07-24	2028	3	7	July	30	24	1	Monday	f	f	\N	\N
20280725	2028-07-25	2028	3	7	July	30	25	2	Tuesday	f	f	\N	\N
20280726	2028-07-26	2028	3	7	July	30	26	3	Wednesday	f	f	\N	\N
20280727	2028-07-27	2028	3	7	July	30	27	4	Thursday	f	f	\N	\N
20280728	2028-07-28	2028	3	7	July	30	28	5	Friday	f	f	\N	\N
20280729	2028-07-29	2028	3	7	July	30	29	6	Saturday	t	f	\N	\N
20280730	2028-07-30	2028	3	7	July	30	30	7	Sunday	t	f	\N	\N
20280731	2028-07-31	2028	3	7	July	31	31	1	Monday	f	t	\N	\N
20280801	2028-08-01	2028	3	8	August	31	1	2	Tuesday	f	f	\N	\N
20280802	2028-08-02	2028	3	8	August	31	2	3	Wednesday	f	f	\N	\N
20280803	2028-08-03	2028	3	8	August	31	3	4	Thursday	f	f	\N	\N
20280804	2028-08-04	2028	3	8	August	31	4	5	Friday	f	f	\N	\N
20280805	2028-08-05	2028	3	8	August	31	5	6	Saturday	t	f	\N	\N
20280806	2028-08-06	2028	3	8	August	31	6	7	Sunday	t	f	\N	\N
20280807	2028-08-07	2028	3	8	August	32	7	1	Monday	f	f	\N	\N
20280808	2028-08-08	2028	3	8	August	32	8	2	Tuesday	f	f	\N	\N
20280809	2028-08-09	2028	3	8	August	32	9	3	Wednesday	f	f	\N	\N
20280810	2028-08-10	2028	3	8	August	32	10	4	Thursday	f	f	\N	\N
20280811	2028-08-11	2028	3	8	August	32	11	5	Friday	f	f	\N	\N
20280812	2028-08-12	2028	3	8	August	32	12	6	Saturday	t	f	\N	\N
20280813	2028-08-13	2028	3	8	August	32	13	7	Sunday	t	f	\N	\N
20280814	2028-08-14	2028	3	8	August	33	14	1	Monday	f	f	\N	\N
20280815	2028-08-15	2028	3	8	August	33	15	2	Tuesday	f	f	\N	\N
20280816	2028-08-16	2028	3	8	August	33	16	3	Wednesday	f	f	\N	\N
20280817	2028-08-17	2028	3	8	August	33	17	4	Thursday	f	f	\N	\N
20280818	2028-08-18	2028	3	8	August	33	18	5	Friday	f	f	\N	\N
20280819	2028-08-19	2028	3	8	August	33	19	6	Saturday	t	f	\N	\N
20280820	2028-08-20	2028	3	8	August	33	20	7	Sunday	t	f	\N	\N
20280821	2028-08-21	2028	3	8	August	34	21	1	Monday	f	f	\N	\N
20280822	2028-08-22	2028	3	8	August	34	22	2	Tuesday	f	f	\N	\N
20280823	2028-08-23	2028	3	8	August	34	23	3	Wednesday	f	f	\N	\N
20280824	2028-08-24	2028	3	8	August	34	24	4	Thursday	f	f	\N	\N
20280825	2028-08-25	2028	3	8	August	34	25	5	Friday	f	f	\N	\N
20280826	2028-08-26	2028	3	8	August	34	26	6	Saturday	t	f	\N	\N
20280827	2028-08-27	2028	3	8	August	34	27	7	Sunday	t	f	\N	\N
20280828	2028-08-28	2028	3	8	August	35	28	1	Monday	f	f	\N	\N
20280829	2028-08-29	2028	3	8	August	35	29	2	Tuesday	f	f	\N	\N
20280830	2028-08-30	2028	3	8	August	35	30	3	Wednesday	f	f	\N	\N
20280831	2028-08-31	2028	3	8	August	35	31	4	Thursday	f	t	\N	\N
20280901	2028-09-01	2028	3	9	September	35	1	5	Friday	f	f	\N	\N
20280902	2028-09-02	2028	3	9	September	35	2	6	Saturday	t	f	\N	\N
20280903	2028-09-03	2028	3	9	September	35	3	7	Sunday	t	f	\N	\N
20280904	2028-09-04	2028	3	9	September	36	4	1	Monday	f	f	\N	\N
20280905	2028-09-05	2028	3	9	September	36	5	2	Tuesday	f	f	\N	\N
20280906	2028-09-06	2028	3	9	September	36	6	3	Wednesday	f	f	\N	\N
20280907	2028-09-07	2028	3	9	September	36	7	4	Thursday	f	f	\N	\N
20280908	2028-09-08	2028	3	9	September	36	8	5	Friday	f	f	\N	\N
20280909	2028-09-09	2028	3	9	September	36	9	6	Saturday	t	f	\N	\N
20280910	2028-09-10	2028	3	9	September	36	10	7	Sunday	t	f	\N	\N
20280911	2028-09-11	2028	3	9	September	37	11	1	Monday	f	f	\N	\N
20280912	2028-09-12	2028	3	9	September	37	12	2	Tuesday	f	f	\N	\N
20280913	2028-09-13	2028	3	9	September	37	13	3	Wednesday	f	f	\N	\N
20280914	2028-09-14	2028	3	9	September	37	14	4	Thursday	f	f	\N	\N
20280915	2028-09-15	2028	3	9	September	37	15	5	Friday	f	f	\N	\N
20280916	2028-09-16	2028	3	9	September	37	16	6	Saturday	t	f	\N	\N
20280917	2028-09-17	2028	3	9	September	37	17	7	Sunday	t	f	\N	\N
20280918	2028-09-18	2028	3	9	September	38	18	1	Monday	f	f	\N	\N
20280919	2028-09-19	2028	3	9	September	38	19	2	Tuesday	f	f	\N	\N
20280920	2028-09-20	2028	3	9	September	38	20	3	Wednesday	f	f	\N	\N
20280921	2028-09-21	2028	3	9	September	38	21	4	Thursday	f	f	\N	\N
20280922	2028-09-22	2028	3	9	September	38	22	5	Friday	f	f	\N	\N
20280923	2028-09-23	2028	3	9	September	38	23	6	Saturday	t	f	\N	\N
20280924	2028-09-24	2028	3	9	September	38	24	7	Sunday	t	f	\N	\N
20280925	2028-09-25	2028	3	9	September	39	25	1	Monday	f	f	\N	\N
20280926	2028-09-26	2028	3	9	September	39	26	2	Tuesday	f	f	\N	\N
20280927	2028-09-27	2028	3	9	September	39	27	3	Wednesday	f	f	\N	\N
20280928	2028-09-28	2028	3	9	September	39	28	4	Thursday	f	f	\N	\N
20280929	2028-09-29	2028	3	9	September	39	29	5	Friday	f	f	\N	\N
20280930	2028-09-30	2028	3	9	September	39	30	6	Saturday	t	t	\N	\N
20281001	2028-10-01	2028	4	10	October	39	1	7	Sunday	t	f	\N	\N
20281002	2028-10-02	2028	4	10	October	40	2	1	Monday	f	f	\N	\N
20281003	2028-10-03	2028	4	10	October	40	3	2	Tuesday	f	f	\N	\N
20281004	2028-10-04	2028	4	10	October	40	4	3	Wednesday	f	f	\N	\N
20281005	2028-10-05	2028	4	10	October	40	5	4	Thursday	f	f	\N	\N
20281006	2028-10-06	2028	4	10	October	40	6	5	Friday	f	f	\N	\N
20281007	2028-10-07	2028	4	10	October	40	7	6	Saturday	t	f	\N	\N
20281008	2028-10-08	2028	4	10	October	40	8	7	Sunday	t	f	\N	\N
20281009	2028-10-09	2028	4	10	October	41	9	1	Monday	f	f	\N	\N
20281010	2028-10-10	2028	4	10	October	41	10	2	Tuesday	f	f	\N	\N
20281011	2028-10-11	2028	4	10	October	41	11	3	Wednesday	f	f	\N	\N
20281012	2028-10-12	2028	4	10	October	41	12	4	Thursday	f	f	\N	\N
20281013	2028-10-13	2028	4	10	October	41	13	5	Friday	f	f	\N	\N
20281014	2028-10-14	2028	4	10	October	41	14	6	Saturday	t	f	\N	\N
20281015	2028-10-15	2028	4	10	October	41	15	7	Sunday	t	f	\N	\N
20281016	2028-10-16	2028	4	10	October	42	16	1	Monday	f	f	\N	\N
20281017	2028-10-17	2028	4	10	October	42	17	2	Tuesday	f	f	\N	\N
20281018	2028-10-18	2028	4	10	October	42	18	3	Wednesday	f	f	\N	\N
20281019	2028-10-19	2028	4	10	October	42	19	4	Thursday	f	f	\N	\N
20281020	2028-10-20	2028	4	10	October	42	20	5	Friday	f	f	\N	\N
20281021	2028-10-21	2028	4	10	October	42	21	6	Saturday	t	f	\N	\N
20281022	2028-10-22	2028	4	10	October	42	22	7	Sunday	t	f	\N	\N
20281023	2028-10-23	2028	4	10	October	43	23	1	Monday	f	f	\N	\N
20281024	2028-10-24	2028	4	10	October	43	24	2	Tuesday	f	f	\N	\N
20281025	2028-10-25	2028	4	10	October	43	25	3	Wednesday	f	f	\N	\N
20281026	2028-10-26	2028	4	10	October	43	26	4	Thursday	f	f	\N	\N
20281027	2028-10-27	2028	4	10	October	43	27	5	Friday	f	f	\N	\N
20281028	2028-10-28	2028	4	10	October	43	28	6	Saturday	t	f	\N	\N
20281029	2028-10-29	2028	4	10	October	43	29	7	Sunday	t	f	\N	\N
20281030	2028-10-30	2028	4	10	October	44	30	1	Monday	f	f	\N	\N
20281031	2028-10-31	2028	4	10	October	44	31	2	Tuesday	f	t	\N	\N
20281101	2028-11-01	2028	4	11	November	44	1	3	Wednesday	f	f	\N	\N
20281102	2028-11-02	2028	4	11	November	44	2	4	Thursday	f	f	\N	\N
20281103	2028-11-03	2028	4	11	November	44	3	5	Friday	f	f	\N	\N
20281104	2028-11-04	2028	4	11	November	44	4	6	Saturday	t	f	\N	\N
20281105	2028-11-05	2028	4	11	November	44	5	7	Sunday	t	f	\N	\N
20281106	2028-11-06	2028	4	11	November	45	6	1	Monday	f	f	\N	\N
20281107	2028-11-07	2028	4	11	November	45	7	2	Tuesday	f	f	\N	\N
20281108	2028-11-08	2028	4	11	November	45	8	3	Wednesday	f	f	\N	\N
20281109	2028-11-09	2028	4	11	November	45	9	4	Thursday	f	f	\N	\N
20281110	2028-11-10	2028	4	11	November	45	10	5	Friday	f	f	\N	\N
20281111	2028-11-11	2028	4	11	November	45	11	6	Saturday	t	f	\N	\N
20281112	2028-11-12	2028	4	11	November	45	12	7	Sunday	t	f	\N	\N
20281113	2028-11-13	2028	4	11	November	46	13	1	Monday	f	f	\N	\N
20281114	2028-11-14	2028	4	11	November	46	14	2	Tuesday	f	f	\N	\N
20281115	2028-11-15	2028	4	11	November	46	15	3	Wednesday	f	f	\N	\N
20281116	2028-11-16	2028	4	11	November	46	16	4	Thursday	f	f	\N	\N
20281117	2028-11-17	2028	4	11	November	46	17	5	Friday	f	f	\N	\N
20281118	2028-11-18	2028	4	11	November	46	18	6	Saturday	t	f	\N	\N
20281119	2028-11-19	2028	4	11	November	46	19	7	Sunday	t	f	\N	\N
20281120	2028-11-20	2028	4	11	November	47	20	1	Monday	f	f	\N	\N
20281121	2028-11-21	2028	4	11	November	47	21	2	Tuesday	f	f	\N	\N
20281122	2028-11-22	2028	4	11	November	47	22	3	Wednesday	f	f	\N	\N
20281123	2028-11-23	2028	4	11	November	47	23	4	Thursday	f	f	\N	\N
20281124	2028-11-24	2028	4	11	November	47	24	5	Friday	f	f	\N	\N
20281125	2028-11-25	2028	4	11	November	47	25	6	Saturday	t	f	\N	\N
20281126	2028-11-26	2028	4	11	November	47	26	7	Sunday	t	f	\N	\N
20281127	2028-11-27	2028	4	11	November	48	27	1	Monday	f	f	\N	\N
20281128	2028-11-28	2028	4	11	November	48	28	2	Tuesday	f	f	\N	\N
20281129	2028-11-29	2028	4	11	November	48	29	3	Wednesday	f	f	\N	\N
20281130	2028-11-30	2028	4	11	November	48	30	4	Thursday	f	t	\N	\N
20281201	2028-12-01	2028	4	12	December	48	1	5	Friday	f	f	\N	\N
20281202	2028-12-02	2028	4	12	December	48	2	6	Saturday	t	f	\N	\N
20281203	2028-12-03	2028	4	12	December	48	3	7	Sunday	t	f	\N	\N
20281204	2028-12-04	2028	4	12	December	49	4	1	Monday	f	f	\N	\N
20281205	2028-12-05	2028	4	12	December	49	5	2	Tuesday	f	f	\N	\N
20281206	2028-12-06	2028	4	12	December	49	6	3	Wednesday	f	f	\N	\N
20281207	2028-12-07	2028	4	12	December	49	7	4	Thursday	f	f	\N	\N
20281208	2028-12-08	2028	4	12	December	49	8	5	Friday	f	f	\N	\N
20281209	2028-12-09	2028	4	12	December	49	9	6	Saturday	t	f	\N	\N
20281210	2028-12-10	2028	4	12	December	49	10	7	Sunday	t	f	\N	\N
20281211	2028-12-11	2028	4	12	December	50	11	1	Monday	f	f	\N	\N
20281212	2028-12-12	2028	4	12	December	50	12	2	Tuesday	f	f	\N	\N
20281213	2028-12-13	2028	4	12	December	50	13	3	Wednesday	f	f	\N	\N
20281214	2028-12-14	2028	4	12	December	50	14	4	Thursday	f	f	\N	\N
20281215	2028-12-15	2028	4	12	December	50	15	5	Friday	f	f	\N	\N
20281216	2028-12-16	2028	4	12	December	50	16	6	Saturday	t	f	\N	\N
20281217	2028-12-17	2028	4	12	December	50	17	7	Sunday	t	f	\N	\N
20281218	2028-12-18	2028	4	12	December	51	18	1	Monday	f	f	\N	\N
20281219	2028-12-19	2028	4	12	December	51	19	2	Tuesday	f	f	\N	\N
20281220	2028-12-20	2028	4	12	December	51	20	3	Wednesday	f	f	\N	\N
20281221	2028-12-21	2028	4	12	December	51	21	4	Thursday	f	f	\N	\N
20281222	2028-12-22	2028	4	12	December	51	22	5	Friday	f	f	\N	\N
20281223	2028-12-23	2028	4	12	December	51	23	6	Saturday	t	f	\N	\N
20281224	2028-12-24	2028	4	12	December	51	24	7	Sunday	t	f	\N	\N
20281225	2028-12-25	2028	4	12	December	52	25	1	Monday	f	f	\N	\N
20281226	2028-12-26	2028	4	12	December	52	26	2	Tuesday	f	f	\N	\N
20281227	2028-12-27	2028	4	12	December	52	27	3	Wednesday	f	f	\N	\N
20281228	2028-12-28	2028	4	12	December	52	28	4	Thursday	f	f	\N	\N
20281229	2028-12-29	2028	4	12	December	52	29	5	Friday	f	f	\N	\N
20281230	2028-12-30	2028	4	12	December	52	30	6	Saturday	t	f	\N	\N
20281231	2028-12-31	2028	4	12	December	52	31	7	Sunday	t	t	\N	\N
20290101	2029-01-01	2029	1	1	January	1	1	1	Monday	f	f	\N	\N
20290102	2029-01-02	2029	1	1	January	1	2	2	Tuesday	f	f	\N	\N
20290103	2029-01-03	2029	1	1	January	1	3	3	Wednesday	f	f	\N	\N
20290104	2029-01-04	2029	1	1	January	1	4	4	Thursday	f	f	\N	\N
20290105	2029-01-05	2029	1	1	January	1	5	5	Friday	f	f	\N	\N
20290106	2029-01-06	2029	1	1	January	1	6	6	Saturday	t	f	\N	\N
20290107	2029-01-07	2029	1	1	January	1	7	7	Sunday	t	f	\N	\N
20290108	2029-01-08	2029	1	1	January	2	8	1	Monday	f	f	\N	\N
20290109	2029-01-09	2029	1	1	January	2	9	2	Tuesday	f	f	\N	\N
20290110	2029-01-10	2029	1	1	January	2	10	3	Wednesday	f	f	\N	\N
20290111	2029-01-11	2029	1	1	January	2	11	4	Thursday	f	f	\N	\N
20290112	2029-01-12	2029	1	1	January	2	12	5	Friday	f	f	\N	\N
20290113	2029-01-13	2029	1	1	January	2	13	6	Saturday	t	f	\N	\N
20290114	2029-01-14	2029	1	1	January	2	14	7	Sunday	t	f	\N	\N
20290115	2029-01-15	2029	1	1	January	3	15	1	Monday	f	f	\N	\N
20290116	2029-01-16	2029	1	1	January	3	16	2	Tuesday	f	f	\N	\N
20290117	2029-01-17	2029	1	1	January	3	17	3	Wednesday	f	f	\N	\N
20290118	2029-01-18	2029	1	1	January	3	18	4	Thursday	f	f	\N	\N
20290119	2029-01-19	2029	1	1	January	3	19	5	Friday	f	f	\N	\N
20290120	2029-01-20	2029	1	1	January	3	20	6	Saturday	t	f	\N	\N
20290121	2029-01-21	2029	1	1	January	3	21	7	Sunday	t	f	\N	\N
20290122	2029-01-22	2029	1	1	January	4	22	1	Monday	f	f	\N	\N
20290123	2029-01-23	2029	1	1	January	4	23	2	Tuesday	f	f	\N	\N
20290124	2029-01-24	2029	1	1	January	4	24	3	Wednesday	f	f	\N	\N
20290125	2029-01-25	2029	1	1	January	4	25	4	Thursday	f	f	\N	\N
20290126	2029-01-26	2029	1	1	January	4	26	5	Friday	f	f	\N	\N
20290127	2029-01-27	2029	1	1	January	4	27	6	Saturday	t	f	\N	\N
20290128	2029-01-28	2029	1	1	January	4	28	7	Sunday	t	f	\N	\N
20290129	2029-01-29	2029	1	1	January	5	29	1	Monday	f	f	\N	\N
20290130	2029-01-30	2029	1	1	January	5	30	2	Tuesday	f	f	\N	\N
20290131	2029-01-31	2029	1	1	January	5	31	3	Wednesday	f	t	\N	\N
20290201	2029-02-01	2029	1	2	February	5	1	4	Thursday	f	f	\N	\N
20290202	2029-02-02	2029	1	2	February	5	2	5	Friday	f	f	\N	\N
20290203	2029-02-03	2029	1	2	February	5	3	6	Saturday	t	f	\N	\N
20290204	2029-02-04	2029	1	2	February	5	4	7	Sunday	t	f	\N	\N
20290205	2029-02-05	2029	1	2	February	6	5	1	Monday	f	f	\N	\N
20290206	2029-02-06	2029	1	2	February	6	6	2	Tuesday	f	f	\N	\N
20290207	2029-02-07	2029	1	2	February	6	7	3	Wednesday	f	f	\N	\N
20290208	2029-02-08	2029	1	2	February	6	8	4	Thursday	f	f	\N	\N
20290209	2029-02-09	2029	1	2	February	6	9	5	Friday	f	f	\N	\N
20290210	2029-02-10	2029	1	2	February	6	10	6	Saturday	t	f	\N	\N
20290211	2029-02-11	2029	1	2	February	6	11	7	Sunday	t	f	\N	\N
20290212	2029-02-12	2029	1	2	February	7	12	1	Monday	f	f	\N	\N
20290213	2029-02-13	2029	1	2	February	7	13	2	Tuesday	f	f	\N	\N
20290214	2029-02-14	2029	1	2	February	7	14	3	Wednesday	f	f	\N	\N
20290215	2029-02-15	2029	1	2	February	7	15	4	Thursday	f	f	\N	\N
20290216	2029-02-16	2029	1	2	February	7	16	5	Friday	f	f	\N	\N
20290217	2029-02-17	2029	1	2	February	7	17	6	Saturday	t	f	\N	\N
20290218	2029-02-18	2029	1	2	February	7	18	7	Sunday	t	f	\N	\N
20290219	2029-02-19	2029	1	2	February	8	19	1	Monday	f	f	\N	\N
20290220	2029-02-20	2029	1	2	February	8	20	2	Tuesday	f	f	\N	\N
20290221	2029-02-21	2029	1	2	February	8	21	3	Wednesday	f	f	\N	\N
20290222	2029-02-22	2029	1	2	February	8	22	4	Thursday	f	f	\N	\N
20290223	2029-02-23	2029	1	2	February	8	23	5	Friday	f	f	\N	\N
20290224	2029-02-24	2029	1	2	February	8	24	6	Saturday	t	f	\N	\N
20290225	2029-02-25	2029	1	2	February	8	25	7	Sunday	t	f	\N	\N
20290226	2029-02-26	2029	1	2	February	9	26	1	Monday	f	f	\N	\N
20290227	2029-02-27	2029	1	2	February	9	27	2	Tuesday	f	f	\N	\N
20290228	2029-02-28	2029	1	2	February	9	28	3	Wednesday	f	t	\N	\N
20290301	2029-03-01	2029	1	3	March	9	1	4	Thursday	f	f	\N	\N
20290302	2029-03-02	2029	1	3	March	9	2	5	Friday	f	f	\N	\N
20290303	2029-03-03	2029	1	3	March	9	3	6	Saturday	t	f	\N	\N
20290304	2029-03-04	2029	1	3	March	9	4	7	Sunday	t	f	\N	\N
20290305	2029-03-05	2029	1	3	March	10	5	1	Monday	f	f	\N	\N
20290306	2029-03-06	2029	1	3	March	10	6	2	Tuesday	f	f	\N	\N
20290307	2029-03-07	2029	1	3	March	10	7	3	Wednesday	f	f	\N	\N
20290308	2029-03-08	2029	1	3	March	10	8	4	Thursday	f	f	\N	\N
20290309	2029-03-09	2029	1	3	March	10	9	5	Friday	f	f	\N	\N
20290310	2029-03-10	2029	1	3	March	10	10	6	Saturday	t	f	\N	\N
20290311	2029-03-11	2029	1	3	March	10	11	7	Sunday	t	f	\N	\N
20290312	2029-03-12	2029	1	3	March	11	12	1	Monday	f	f	\N	\N
20290313	2029-03-13	2029	1	3	March	11	13	2	Tuesday	f	f	\N	\N
20290314	2029-03-14	2029	1	3	March	11	14	3	Wednesday	f	f	\N	\N
20290315	2029-03-15	2029	1	3	March	11	15	4	Thursday	f	f	\N	\N
20290316	2029-03-16	2029	1	3	March	11	16	5	Friday	f	f	\N	\N
20290317	2029-03-17	2029	1	3	March	11	17	6	Saturday	t	f	\N	\N
20290318	2029-03-18	2029	1	3	March	11	18	7	Sunday	t	f	\N	\N
20290319	2029-03-19	2029	1	3	March	12	19	1	Monday	f	f	\N	\N
20290320	2029-03-20	2029	1	3	March	12	20	2	Tuesday	f	f	\N	\N
20290321	2029-03-21	2029	1	3	March	12	21	3	Wednesday	f	f	\N	\N
20290322	2029-03-22	2029	1	3	March	12	22	4	Thursday	f	f	\N	\N
20290323	2029-03-23	2029	1	3	March	12	23	5	Friday	f	f	\N	\N
20290324	2029-03-24	2029	1	3	March	12	24	6	Saturday	t	f	\N	\N
20290325	2029-03-25	2029	1	3	March	12	25	7	Sunday	t	f	\N	\N
20290326	2029-03-26	2029	1	3	March	13	26	1	Monday	f	f	\N	\N
20290327	2029-03-27	2029	1	3	March	13	27	2	Tuesday	f	f	\N	\N
20290328	2029-03-28	2029	1	3	March	13	28	3	Wednesday	f	f	\N	\N
20290329	2029-03-29	2029	1	3	March	13	29	4	Thursday	f	f	\N	\N
20290330	2029-03-30	2029	1	3	March	13	30	5	Friday	f	f	\N	\N
20290331	2029-03-31	2029	1	3	March	13	31	6	Saturday	t	t	\N	\N
20290401	2029-04-01	2029	2	4	April	13	1	7	Sunday	t	f	\N	\N
20290402	2029-04-02	2029	2	4	April	14	2	1	Monday	f	f	\N	\N
20290403	2029-04-03	2029	2	4	April	14	3	2	Tuesday	f	f	\N	\N
20290404	2029-04-04	2029	2	4	April	14	4	3	Wednesday	f	f	\N	\N
20290405	2029-04-05	2029	2	4	April	14	5	4	Thursday	f	f	\N	\N
20290406	2029-04-06	2029	2	4	April	14	6	5	Friday	f	f	\N	\N
20290407	2029-04-07	2029	2	4	April	14	7	6	Saturday	t	f	\N	\N
20290408	2029-04-08	2029	2	4	April	14	8	7	Sunday	t	f	\N	\N
20290409	2029-04-09	2029	2	4	April	15	9	1	Monday	f	f	\N	\N
20290410	2029-04-10	2029	2	4	April	15	10	2	Tuesday	f	f	\N	\N
20290411	2029-04-11	2029	2	4	April	15	11	3	Wednesday	f	f	\N	\N
20290412	2029-04-12	2029	2	4	April	15	12	4	Thursday	f	f	\N	\N
20290413	2029-04-13	2029	2	4	April	15	13	5	Friday	f	f	\N	\N
20290414	2029-04-14	2029	2	4	April	15	14	6	Saturday	t	f	\N	\N
20290415	2029-04-15	2029	2	4	April	15	15	7	Sunday	t	f	\N	\N
20290416	2029-04-16	2029	2	4	April	16	16	1	Monday	f	f	\N	\N
20290417	2029-04-17	2029	2	4	April	16	17	2	Tuesday	f	f	\N	\N
20290418	2029-04-18	2029	2	4	April	16	18	3	Wednesday	f	f	\N	\N
20290419	2029-04-19	2029	2	4	April	16	19	4	Thursday	f	f	\N	\N
20290420	2029-04-20	2029	2	4	April	16	20	5	Friday	f	f	\N	\N
20290421	2029-04-21	2029	2	4	April	16	21	6	Saturday	t	f	\N	\N
20290422	2029-04-22	2029	2	4	April	16	22	7	Sunday	t	f	\N	\N
20290423	2029-04-23	2029	2	4	April	17	23	1	Monday	f	f	\N	\N
20290424	2029-04-24	2029	2	4	April	17	24	2	Tuesday	f	f	\N	\N
20290425	2029-04-25	2029	2	4	April	17	25	3	Wednesday	f	f	\N	\N
20290426	2029-04-26	2029	2	4	April	17	26	4	Thursday	f	f	\N	\N
20290427	2029-04-27	2029	2	4	April	17	27	5	Friday	f	f	\N	\N
20290428	2029-04-28	2029	2	4	April	17	28	6	Saturday	t	f	\N	\N
20290429	2029-04-29	2029	2	4	April	17	29	7	Sunday	t	f	\N	\N
20290430	2029-04-30	2029	2	4	April	18	30	1	Monday	f	t	\N	\N
20290501	2029-05-01	2029	2	5	May	18	1	2	Tuesday	f	f	\N	\N
20290502	2029-05-02	2029	2	5	May	18	2	3	Wednesday	f	f	\N	\N
20290503	2029-05-03	2029	2	5	May	18	3	4	Thursday	f	f	\N	\N
20290504	2029-05-04	2029	2	5	May	18	4	5	Friday	f	f	\N	\N
20290505	2029-05-05	2029	2	5	May	18	5	6	Saturday	t	f	\N	\N
20290506	2029-05-06	2029	2	5	May	18	6	7	Sunday	t	f	\N	\N
20290507	2029-05-07	2029	2	5	May	19	7	1	Monday	f	f	\N	\N
20290508	2029-05-08	2029	2	5	May	19	8	2	Tuesday	f	f	\N	\N
20290509	2029-05-09	2029	2	5	May	19	9	3	Wednesday	f	f	\N	\N
20290510	2029-05-10	2029	2	5	May	19	10	4	Thursday	f	f	\N	\N
20290511	2029-05-11	2029	2	5	May	19	11	5	Friday	f	f	\N	\N
20290512	2029-05-12	2029	2	5	May	19	12	6	Saturday	t	f	\N	\N
20290513	2029-05-13	2029	2	5	May	19	13	7	Sunday	t	f	\N	\N
20290514	2029-05-14	2029	2	5	May	20	14	1	Monday	f	f	\N	\N
20290515	2029-05-15	2029	2	5	May	20	15	2	Tuesday	f	f	\N	\N
20290516	2029-05-16	2029	2	5	May	20	16	3	Wednesday	f	f	\N	\N
20290517	2029-05-17	2029	2	5	May	20	17	4	Thursday	f	f	\N	\N
20290518	2029-05-18	2029	2	5	May	20	18	5	Friday	f	f	\N	\N
20290519	2029-05-19	2029	2	5	May	20	19	6	Saturday	t	f	\N	\N
20290520	2029-05-20	2029	2	5	May	20	20	7	Sunday	t	f	\N	\N
20290521	2029-05-21	2029	2	5	May	21	21	1	Monday	f	f	\N	\N
20290522	2029-05-22	2029	2	5	May	21	22	2	Tuesday	f	f	\N	\N
20290523	2029-05-23	2029	2	5	May	21	23	3	Wednesday	f	f	\N	\N
20290524	2029-05-24	2029	2	5	May	21	24	4	Thursday	f	f	\N	\N
20290525	2029-05-25	2029	2	5	May	21	25	5	Friday	f	f	\N	\N
20290526	2029-05-26	2029	2	5	May	21	26	6	Saturday	t	f	\N	\N
20290527	2029-05-27	2029	2	5	May	21	27	7	Sunday	t	f	\N	\N
20290528	2029-05-28	2029	2	5	May	22	28	1	Monday	f	f	\N	\N
20290529	2029-05-29	2029	2	5	May	22	29	2	Tuesday	f	f	\N	\N
20290530	2029-05-30	2029	2	5	May	22	30	3	Wednesday	f	f	\N	\N
20290531	2029-05-31	2029	2	5	May	22	31	4	Thursday	f	t	\N	\N
20290601	2029-06-01	2029	2	6	June	22	1	5	Friday	f	f	\N	\N
20290602	2029-06-02	2029	2	6	June	22	2	6	Saturday	t	f	\N	\N
20290603	2029-06-03	2029	2	6	June	22	3	7	Sunday	t	f	\N	\N
20290604	2029-06-04	2029	2	6	June	23	4	1	Monday	f	f	\N	\N
20290605	2029-06-05	2029	2	6	June	23	5	2	Tuesday	f	f	\N	\N
20290606	2029-06-06	2029	2	6	June	23	6	3	Wednesday	f	f	\N	\N
20290607	2029-06-07	2029	2	6	June	23	7	4	Thursday	f	f	\N	\N
20290608	2029-06-08	2029	2	6	June	23	8	5	Friday	f	f	\N	\N
20290609	2029-06-09	2029	2	6	June	23	9	6	Saturday	t	f	\N	\N
20290610	2029-06-10	2029	2	6	June	23	10	7	Sunday	t	f	\N	\N
20290611	2029-06-11	2029	2	6	June	24	11	1	Monday	f	f	\N	\N
20290612	2029-06-12	2029	2	6	June	24	12	2	Tuesday	f	f	\N	\N
20290613	2029-06-13	2029	2	6	June	24	13	3	Wednesday	f	f	\N	\N
20290614	2029-06-14	2029	2	6	June	24	14	4	Thursday	f	f	\N	\N
20290615	2029-06-15	2029	2	6	June	24	15	5	Friday	f	f	\N	\N
20290616	2029-06-16	2029	2	6	June	24	16	6	Saturday	t	f	\N	\N
20290617	2029-06-17	2029	2	6	June	24	17	7	Sunday	t	f	\N	\N
20290618	2029-06-18	2029	2	6	June	25	18	1	Monday	f	f	\N	\N
20290619	2029-06-19	2029	2	6	June	25	19	2	Tuesday	f	f	\N	\N
20290620	2029-06-20	2029	2	6	June	25	20	3	Wednesday	f	f	\N	\N
20290621	2029-06-21	2029	2	6	June	25	21	4	Thursday	f	f	\N	\N
20290622	2029-06-22	2029	2	6	June	25	22	5	Friday	f	f	\N	\N
20290623	2029-06-23	2029	2	6	June	25	23	6	Saturday	t	f	\N	\N
20290624	2029-06-24	2029	2	6	June	25	24	7	Sunday	t	f	\N	\N
20290625	2029-06-25	2029	2	6	June	26	25	1	Monday	f	f	\N	\N
20290626	2029-06-26	2029	2	6	June	26	26	2	Tuesday	f	f	\N	\N
20290627	2029-06-27	2029	2	6	June	26	27	3	Wednesday	f	f	\N	\N
20290628	2029-06-28	2029	2	6	June	26	28	4	Thursday	f	f	\N	\N
20290629	2029-06-29	2029	2	6	June	26	29	5	Friday	f	f	\N	\N
20290630	2029-06-30	2029	2	6	June	26	30	6	Saturday	t	t	\N	\N
20290701	2029-07-01	2029	3	7	July	26	1	7	Sunday	t	f	\N	\N
20290702	2029-07-02	2029	3	7	July	27	2	1	Monday	f	f	\N	\N
20290703	2029-07-03	2029	3	7	July	27	3	2	Tuesday	f	f	\N	\N
20290704	2029-07-04	2029	3	7	July	27	4	3	Wednesday	f	f	\N	\N
20290705	2029-07-05	2029	3	7	July	27	5	4	Thursday	f	f	\N	\N
20290706	2029-07-06	2029	3	7	July	27	6	5	Friday	f	f	\N	\N
20290707	2029-07-07	2029	3	7	July	27	7	6	Saturday	t	f	\N	\N
20290708	2029-07-08	2029	3	7	July	27	8	7	Sunday	t	f	\N	\N
20290709	2029-07-09	2029	3	7	July	28	9	1	Monday	f	f	\N	\N
20290710	2029-07-10	2029	3	7	July	28	10	2	Tuesday	f	f	\N	\N
20290711	2029-07-11	2029	3	7	July	28	11	3	Wednesday	f	f	\N	\N
20290712	2029-07-12	2029	3	7	July	28	12	4	Thursday	f	f	\N	\N
20290713	2029-07-13	2029	3	7	July	28	13	5	Friday	f	f	\N	\N
20290714	2029-07-14	2029	3	7	July	28	14	6	Saturday	t	f	\N	\N
20290715	2029-07-15	2029	3	7	July	28	15	7	Sunday	t	f	\N	\N
20290716	2029-07-16	2029	3	7	July	29	16	1	Monday	f	f	\N	\N
20290717	2029-07-17	2029	3	7	July	29	17	2	Tuesday	f	f	\N	\N
20290718	2029-07-18	2029	3	7	July	29	18	3	Wednesday	f	f	\N	\N
20290719	2029-07-19	2029	3	7	July	29	19	4	Thursday	f	f	\N	\N
20290720	2029-07-20	2029	3	7	July	29	20	5	Friday	f	f	\N	\N
20290721	2029-07-21	2029	3	7	July	29	21	6	Saturday	t	f	\N	\N
20290722	2029-07-22	2029	3	7	July	29	22	7	Sunday	t	f	\N	\N
20290723	2029-07-23	2029	3	7	July	30	23	1	Monday	f	f	\N	\N
20290724	2029-07-24	2029	3	7	July	30	24	2	Tuesday	f	f	\N	\N
20290725	2029-07-25	2029	3	7	July	30	25	3	Wednesday	f	f	\N	\N
20290726	2029-07-26	2029	3	7	July	30	26	4	Thursday	f	f	\N	\N
20290727	2029-07-27	2029	3	7	July	30	27	5	Friday	f	f	\N	\N
20290728	2029-07-28	2029	3	7	July	30	28	6	Saturday	t	f	\N	\N
20290729	2029-07-29	2029	3	7	July	30	29	7	Sunday	t	f	\N	\N
20290730	2029-07-30	2029	3	7	July	31	30	1	Monday	f	f	\N	\N
20290731	2029-07-31	2029	3	7	July	31	31	2	Tuesday	f	t	\N	\N
20290801	2029-08-01	2029	3	8	August	31	1	3	Wednesday	f	f	\N	\N
20290802	2029-08-02	2029	3	8	August	31	2	4	Thursday	f	f	\N	\N
20290803	2029-08-03	2029	3	8	August	31	3	5	Friday	f	f	\N	\N
20290804	2029-08-04	2029	3	8	August	31	4	6	Saturday	t	f	\N	\N
20290805	2029-08-05	2029	3	8	August	31	5	7	Sunday	t	f	\N	\N
20290806	2029-08-06	2029	3	8	August	32	6	1	Monday	f	f	\N	\N
20290807	2029-08-07	2029	3	8	August	32	7	2	Tuesday	f	f	\N	\N
20290808	2029-08-08	2029	3	8	August	32	8	3	Wednesday	f	f	\N	\N
20290809	2029-08-09	2029	3	8	August	32	9	4	Thursday	f	f	\N	\N
20290810	2029-08-10	2029	3	8	August	32	10	5	Friday	f	f	\N	\N
20290811	2029-08-11	2029	3	8	August	32	11	6	Saturday	t	f	\N	\N
20290812	2029-08-12	2029	3	8	August	32	12	7	Sunday	t	f	\N	\N
20290813	2029-08-13	2029	3	8	August	33	13	1	Monday	f	f	\N	\N
20290814	2029-08-14	2029	3	8	August	33	14	2	Tuesday	f	f	\N	\N
20290815	2029-08-15	2029	3	8	August	33	15	3	Wednesday	f	f	\N	\N
20290816	2029-08-16	2029	3	8	August	33	16	4	Thursday	f	f	\N	\N
20290817	2029-08-17	2029	3	8	August	33	17	5	Friday	f	f	\N	\N
20290818	2029-08-18	2029	3	8	August	33	18	6	Saturday	t	f	\N	\N
20290819	2029-08-19	2029	3	8	August	33	19	7	Sunday	t	f	\N	\N
20290820	2029-08-20	2029	3	8	August	34	20	1	Monday	f	f	\N	\N
20290821	2029-08-21	2029	3	8	August	34	21	2	Tuesday	f	f	\N	\N
20290822	2029-08-22	2029	3	8	August	34	22	3	Wednesday	f	f	\N	\N
20290823	2029-08-23	2029	3	8	August	34	23	4	Thursday	f	f	\N	\N
20290824	2029-08-24	2029	3	8	August	34	24	5	Friday	f	f	\N	\N
20290825	2029-08-25	2029	3	8	August	34	25	6	Saturday	t	f	\N	\N
20290826	2029-08-26	2029	3	8	August	34	26	7	Sunday	t	f	\N	\N
20290827	2029-08-27	2029	3	8	August	35	27	1	Monday	f	f	\N	\N
20290828	2029-08-28	2029	3	8	August	35	28	2	Tuesday	f	f	\N	\N
20290829	2029-08-29	2029	3	8	August	35	29	3	Wednesday	f	f	\N	\N
20290830	2029-08-30	2029	3	8	August	35	30	4	Thursday	f	f	\N	\N
20290831	2029-08-31	2029	3	8	August	35	31	5	Friday	f	t	\N	\N
20290901	2029-09-01	2029	3	9	September	35	1	6	Saturday	t	f	\N	\N
20290902	2029-09-02	2029	3	9	September	35	2	7	Sunday	t	f	\N	\N
20290903	2029-09-03	2029	3	9	September	36	3	1	Monday	f	f	\N	\N
20290904	2029-09-04	2029	3	9	September	36	4	2	Tuesday	f	f	\N	\N
20290905	2029-09-05	2029	3	9	September	36	5	3	Wednesday	f	f	\N	\N
20290906	2029-09-06	2029	3	9	September	36	6	4	Thursday	f	f	\N	\N
20290907	2029-09-07	2029	3	9	September	36	7	5	Friday	f	f	\N	\N
20290908	2029-09-08	2029	3	9	September	36	8	6	Saturday	t	f	\N	\N
20290909	2029-09-09	2029	3	9	September	36	9	7	Sunday	t	f	\N	\N
20290910	2029-09-10	2029	3	9	September	37	10	1	Monday	f	f	\N	\N
20290911	2029-09-11	2029	3	9	September	37	11	2	Tuesday	f	f	\N	\N
20290912	2029-09-12	2029	3	9	September	37	12	3	Wednesday	f	f	\N	\N
20290913	2029-09-13	2029	3	9	September	37	13	4	Thursday	f	f	\N	\N
20290914	2029-09-14	2029	3	9	September	37	14	5	Friday	f	f	\N	\N
20290915	2029-09-15	2029	3	9	September	37	15	6	Saturday	t	f	\N	\N
20290916	2029-09-16	2029	3	9	September	37	16	7	Sunday	t	f	\N	\N
20290917	2029-09-17	2029	3	9	September	38	17	1	Monday	f	f	\N	\N
20290918	2029-09-18	2029	3	9	September	38	18	2	Tuesday	f	f	\N	\N
20290919	2029-09-19	2029	3	9	September	38	19	3	Wednesday	f	f	\N	\N
20290920	2029-09-20	2029	3	9	September	38	20	4	Thursday	f	f	\N	\N
20290921	2029-09-21	2029	3	9	September	38	21	5	Friday	f	f	\N	\N
20290922	2029-09-22	2029	3	9	September	38	22	6	Saturday	t	f	\N	\N
20290923	2029-09-23	2029	3	9	September	38	23	7	Sunday	t	f	\N	\N
20290924	2029-09-24	2029	3	9	September	39	24	1	Monday	f	f	\N	\N
20290925	2029-09-25	2029	3	9	September	39	25	2	Tuesday	f	f	\N	\N
20290926	2029-09-26	2029	3	9	September	39	26	3	Wednesday	f	f	\N	\N
20290927	2029-09-27	2029	3	9	September	39	27	4	Thursday	f	f	\N	\N
20290928	2029-09-28	2029	3	9	September	39	28	5	Friday	f	f	\N	\N
20290929	2029-09-29	2029	3	9	September	39	29	6	Saturday	t	f	\N	\N
20290930	2029-09-30	2029	3	9	September	39	30	7	Sunday	t	t	\N	\N
20291001	2029-10-01	2029	4	10	October	40	1	1	Monday	f	f	\N	\N
20291002	2029-10-02	2029	4	10	October	40	2	2	Tuesday	f	f	\N	\N
20291003	2029-10-03	2029	4	10	October	40	3	3	Wednesday	f	f	\N	\N
20291004	2029-10-04	2029	4	10	October	40	4	4	Thursday	f	f	\N	\N
20291005	2029-10-05	2029	4	10	October	40	5	5	Friday	f	f	\N	\N
20291006	2029-10-06	2029	4	10	October	40	6	6	Saturday	t	f	\N	\N
20291007	2029-10-07	2029	4	10	October	40	7	7	Sunday	t	f	\N	\N
20291008	2029-10-08	2029	4	10	October	41	8	1	Monday	f	f	\N	\N
20291009	2029-10-09	2029	4	10	October	41	9	2	Tuesday	f	f	\N	\N
20291010	2029-10-10	2029	4	10	October	41	10	3	Wednesday	f	f	\N	\N
20291011	2029-10-11	2029	4	10	October	41	11	4	Thursday	f	f	\N	\N
20291012	2029-10-12	2029	4	10	October	41	12	5	Friday	f	f	\N	\N
20291013	2029-10-13	2029	4	10	October	41	13	6	Saturday	t	f	\N	\N
20291014	2029-10-14	2029	4	10	October	41	14	7	Sunday	t	f	\N	\N
20291015	2029-10-15	2029	4	10	October	42	15	1	Monday	f	f	\N	\N
20291016	2029-10-16	2029	4	10	October	42	16	2	Tuesday	f	f	\N	\N
20291017	2029-10-17	2029	4	10	October	42	17	3	Wednesday	f	f	\N	\N
20291018	2029-10-18	2029	4	10	October	42	18	4	Thursday	f	f	\N	\N
20291019	2029-10-19	2029	4	10	October	42	19	5	Friday	f	f	\N	\N
20291020	2029-10-20	2029	4	10	October	42	20	6	Saturday	t	f	\N	\N
20291021	2029-10-21	2029	4	10	October	42	21	7	Sunday	t	f	\N	\N
20291022	2029-10-22	2029	4	10	October	43	22	1	Monday	f	f	\N	\N
20291023	2029-10-23	2029	4	10	October	43	23	2	Tuesday	f	f	\N	\N
20291024	2029-10-24	2029	4	10	October	43	24	3	Wednesday	f	f	\N	\N
20291025	2029-10-25	2029	4	10	October	43	25	4	Thursday	f	f	\N	\N
20291026	2029-10-26	2029	4	10	October	43	26	5	Friday	f	f	\N	\N
20291027	2029-10-27	2029	4	10	October	43	27	6	Saturday	t	f	\N	\N
20291028	2029-10-28	2029	4	10	October	43	28	7	Sunday	t	f	\N	\N
20291029	2029-10-29	2029	4	10	October	44	29	1	Monday	f	f	\N	\N
20291030	2029-10-30	2029	4	10	October	44	30	2	Tuesday	f	f	\N	\N
20291031	2029-10-31	2029	4	10	October	44	31	3	Wednesday	f	t	\N	\N
20291101	2029-11-01	2029	4	11	November	44	1	4	Thursday	f	f	\N	\N
20291102	2029-11-02	2029	4	11	November	44	2	5	Friday	f	f	\N	\N
20291103	2029-11-03	2029	4	11	November	44	3	6	Saturday	t	f	\N	\N
20291104	2029-11-04	2029	4	11	November	44	4	7	Sunday	t	f	\N	\N
20291105	2029-11-05	2029	4	11	November	45	5	1	Monday	f	f	\N	\N
20291106	2029-11-06	2029	4	11	November	45	6	2	Tuesday	f	f	\N	\N
20291107	2029-11-07	2029	4	11	November	45	7	3	Wednesday	f	f	\N	\N
20291108	2029-11-08	2029	4	11	November	45	8	4	Thursday	f	f	\N	\N
20291109	2029-11-09	2029	4	11	November	45	9	5	Friday	f	f	\N	\N
20291110	2029-11-10	2029	4	11	November	45	10	6	Saturday	t	f	\N	\N
20291111	2029-11-11	2029	4	11	November	45	11	7	Sunday	t	f	\N	\N
20291112	2029-11-12	2029	4	11	November	46	12	1	Monday	f	f	\N	\N
20291113	2029-11-13	2029	4	11	November	46	13	2	Tuesday	f	f	\N	\N
20291114	2029-11-14	2029	4	11	November	46	14	3	Wednesday	f	f	\N	\N
20291115	2029-11-15	2029	4	11	November	46	15	4	Thursday	f	f	\N	\N
20291116	2029-11-16	2029	4	11	November	46	16	5	Friday	f	f	\N	\N
20291117	2029-11-17	2029	4	11	November	46	17	6	Saturday	t	f	\N	\N
20291118	2029-11-18	2029	4	11	November	46	18	7	Sunday	t	f	\N	\N
20291119	2029-11-19	2029	4	11	November	47	19	1	Monday	f	f	\N	\N
20291120	2029-11-20	2029	4	11	November	47	20	2	Tuesday	f	f	\N	\N
20291121	2029-11-21	2029	4	11	November	47	21	3	Wednesday	f	f	\N	\N
20291122	2029-11-22	2029	4	11	November	47	22	4	Thursday	f	f	\N	\N
20291123	2029-11-23	2029	4	11	November	47	23	5	Friday	f	f	\N	\N
20291124	2029-11-24	2029	4	11	November	47	24	6	Saturday	t	f	\N	\N
20291125	2029-11-25	2029	4	11	November	47	25	7	Sunday	t	f	\N	\N
20291126	2029-11-26	2029	4	11	November	48	26	1	Monday	f	f	\N	\N
20291127	2029-11-27	2029	4	11	November	48	27	2	Tuesday	f	f	\N	\N
20291128	2029-11-28	2029	4	11	November	48	28	3	Wednesday	f	f	\N	\N
20291129	2029-11-29	2029	4	11	November	48	29	4	Thursday	f	f	\N	\N
20291130	2029-11-30	2029	4	11	November	48	30	5	Friday	f	t	\N	\N
20291201	2029-12-01	2029	4	12	December	48	1	6	Saturday	t	f	\N	\N
20291202	2029-12-02	2029	4	12	December	48	2	7	Sunday	t	f	\N	\N
20291203	2029-12-03	2029	4	12	December	49	3	1	Monday	f	f	\N	\N
20291204	2029-12-04	2029	4	12	December	49	4	2	Tuesday	f	f	\N	\N
20291205	2029-12-05	2029	4	12	December	49	5	3	Wednesday	f	f	\N	\N
20291206	2029-12-06	2029	4	12	December	49	6	4	Thursday	f	f	\N	\N
20291207	2029-12-07	2029	4	12	December	49	7	5	Friday	f	f	\N	\N
20291208	2029-12-08	2029	4	12	December	49	8	6	Saturday	t	f	\N	\N
20291209	2029-12-09	2029	4	12	December	49	9	7	Sunday	t	f	\N	\N
20291210	2029-12-10	2029	4	12	December	50	10	1	Monday	f	f	\N	\N
20291211	2029-12-11	2029	4	12	December	50	11	2	Tuesday	f	f	\N	\N
20291212	2029-12-12	2029	4	12	December	50	12	3	Wednesday	f	f	\N	\N
20291213	2029-12-13	2029	4	12	December	50	13	4	Thursday	f	f	\N	\N
20291214	2029-12-14	2029	4	12	December	50	14	5	Friday	f	f	\N	\N
20291215	2029-12-15	2029	4	12	December	50	15	6	Saturday	t	f	\N	\N
20291216	2029-12-16	2029	4	12	December	50	16	7	Sunday	t	f	\N	\N
20291217	2029-12-17	2029	4	12	December	51	17	1	Monday	f	f	\N	\N
20291218	2029-12-18	2029	4	12	December	51	18	2	Tuesday	f	f	\N	\N
20291219	2029-12-19	2029	4	12	December	51	19	3	Wednesday	f	f	\N	\N
20291220	2029-12-20	2029	4	12	December	51	20	4	Thursday	f	f	\N	\N
20291221	2029-12-21	2029	4	12	December	51	21	5	Friday	f	f	\N	\N
20291222	2029-12-22	2029	4	12	December	51	22	6	Saturday	t	f	\N	\N
20291223	2029-12-23	2029	4	12	December	51	23	7	Sunday	t	f	\N	\N
20291224	2029-12-24	2029	4	12	December	52	24	1	Monday	f	f	\N	\N
20291225	2029-12-25	2029	4	12	December	52	25	2	Tuesday	f	f	\N	\N
20291226	2029-12-26	2029	4	12	December	52	26	3	Wednesday	f	f	\N	\N
20291227	2029-12-27	2029	4	12	December	52	27	4	Thursday	f	f	\N	\N
20291228	2029-12-28	2029	4	12	December	52	28	5	Friday	f	f	\N	\N
20291229	2029-12-29	2029	4	12	December	52	29	6	Saturday	t	f	\N	\N
20291230	2029-12-30	2029	4	12	December	52	30	7	Sunday	t	f	\N	\N
20291231	2029-12-31	2029	4	12	December	1	31	1	Monday	f	t	\N	\N
20300101	2030-01-01	2030	1	1	January	1	1	2	Tuesday	f	f	\N	\N
20300102	2030-01-02	2030	1	1	January	1	2	3	Wednesday	f	f	\N	\N
20300103	2030-01-03	2030	1	1	January	1	3	4	Thursday	f	f	\N	\N
20300104	2030-01-04	2030	1	1	January	1	4	5	Friday	f	f	\N	\N
20300105	2030-01-05	2030	1	1	January	1	5	6	Saturday	t	f	\N	\N
20300106	2030-01-06	2030	1	1	January	1	6	7	Sunday	t	f	\N	\N
20300107	2030-01-07	2030	1	1	January	2	7	1	Monday	f	f	\N	\N
20300108	2030-01-08	2030	1	1	January	2	8	2	Tuesday	f	f	\N	\N
20300109	2030-01-09	2030	1	1	January	2	9	3	Wednesday	f	f	\N	\N
20300110	2030-01-10	2030	1	1	January	2	10	4	Thursday	f	f	\N	\N
20300111	2030-01-11	2030	1	1	January	2	11	5	Friday	f	f	\N	\N
20300112	2030-01-12	2030	1	1	January	2	12	6	Saturday	t	f	\N	\N
20300113	2030-01-13	2030	1	1	January	2	13	7	Sunday	t	f	\N	\N
20300114	2030-01-14	2030	1	1	January	3	14	1	Monday	f	f	\N	\N
20300115	2030-01-15	2030	1	1	January	3	15	2	Tuesday	f	f	\N	\N
20300116	2030-01-16	2030	1	1	January	3	16	3	Wednesday	f	f	\N	\N
20300117	2030-01-17	2030	1	1	January	3	17	4	Thursday	f	f	\N	\N
20300118	2030-01-18	2030	1	1	January	3	18	5	Friday	f	f	\N	\N
20300119	2030-01-19	2030	1	1	January	3	19	6	Saturday	t	f	\N	\N
20300120	2030-01-20	2030	1	1	January	3	20	7	Sunday	t	f	\N	\N
20300121	2030-01-21	2030	1	1	January	4	21	1	Monday	f	f	\N	\N
20300122	2030-01-22	2030	1	1	January	4	22	2	Tuesday	f	f	\N	\N
20300123	2030-01-23	2030	1	1	January	4	23	3	Wednesday	f	f	\N	\N
20300124	2030-01-24	2030	1	1	January	4	24	4	Thursday	f	f	\N	\N
20300125	2030-01-25	2030	1	1	January	4	25	5	Friday	f	f	\N	\N
20300126	2030-01-26	2030	1	1	January	4	26	6	Saturday	t	f	\N	\N
20300127	2030-01-27	2030	1	1	January	4	27	7	Sunday	t	f	\N	\N
20300128	2030-01-28	2030	1	1	January	5	28	1	Monday	f	f	\N	\N
20300129	2030-01-29	2030	1	1	January	5	29	2	Tuesday	f	f	\N	\N
20300130	2030-01-30	2030	1	1	January	5	30	3	Wednesday	f	f	\N	\N
20300131	2030-01-31	2030	1	1	January	5	31	4	Thursday	f	t	\N	\N
20300201	2030-02-01	2030	1	2	February	5	1	5	Friday	f	f	\N	\N
20300202	2030-02-02	2030	1	2	February	5	2	6	Saturday	t	f	\N	\N
20300203	2030-02-03	2030	1	2	February	5	3	7	Sunday	t	f	\N	\N
20300204	2030-02-04	2030	1	2	February	6	4	1	Monday	f	f	\N	\N
20300205	2030-02-05	2030	1	2	February	6	5	2	Tuesday	f	f	\N	\N
20300206	2030-02-06	2030	1	2	February	6	6	3	Wednesday	f	f	\N	\N
20300207	2030-02-07	2030	1	2	February	6	7	4	Thursday	f	f	\N	\N
20300208	2030-02-08	2030	1	2	February	6	8	5	Friday	f	f	\N	\N
20300209	2030-02-09	2030	1	2	February	6	9	6	Saturday	t	f	\N	\N
20300210	2030-02-10	2030	1	2	February	6	10	7	Sunday	t	f	\N	\N
20300211	2030-02-11	2030	1	2	February	7	11	1	Monday	f	f	\N	\N
20300212	2030-02-12	2030	1	2	February	7	12	2	Tuesday	f	f	\N	\N
20300213	2030-02-13	2030	1	2	February	7	13	3	Wednesday	f	f	\N	\N
20300214	2030-02-14	2030	1	2	February	7	14	4	Thursday	f	f	\N	\N
20300215	2030-02-15	2030	1	2	February	7	15	5	Friday	f	f	\N	\N
20300216	2030-02-16	2030	1	2	February	7	16	6	Saturday	t	f	\N	\N
20300217	2030-02-17	2030	1	2	February	7	17	7	Sunday	t	f	\N	\N
20300218	2030-02-18	2030	1	2	February	8	18	1	Monday	f	f	\N	\N
20300219	2030-02-19	2030	1	2	February	8	19	2	Tuesday	f	f	\N	\N
20300220	2030-02-20	2030	1	2	February	8	20	3	Wednesday	f	f	\N	\N
20300221	2030-02-21	2030	1	2	February	8	21	4	Thursday	f	f	\N	\N
20300222	2030-02-22	2030	1	2	February	8	22	5	Friday	f	f	\N	\N
20300223	2030-02-23	2030	1	2	February	8	23	6	Saturday	t	f	\N	\N
20300224	2030-02-24	2030	1	2	February	8	24	7	Sunday	t	f	\N	\N
20300225	2030-02-25	2030	1	2	February	9	25	1	Monday	f	f	\N	\N
20300226	2030-02-26	2030	1	2	February	9	26	2	Tuesday	f	f	\N	\N
20300227	2030-02-27	2030	1	2	February	9	27	3	Wednesday	f	f	\N	\N
20300228	2030-02-28	2030	1	2	February	9	28	4	Thursday	f	t	\N	\N
20300301	2030-03-01	2030	1	3	March	9	1	5	Friday	f	f	\N	\N
20300302	2030-03-02	2030	1	3	March	9	2	6	Saturday	t	f	\N	\N
20300303	2030-03-03	2030	1	3	March	9	3	7	Sunday	t	f	\N	\N
20300304	2030-03-04	2030	1	3	March	10	4	1	Monday	f	f	\N	\N
20300305	2030-03-05	2030	1	3	March	10	5	2	Tuesday	f	f	\N	\N
20300306	2030-03-06	2030	1	3	March	10	6	3	Wednesday	f	f	\N	\N
20300307	2030-03-07	2030	1	3	March	10	7	4	Thursday	f	f	\N	\N
20300308	2030-03-08	2030	1	3	March	10	8	5	Friday	f	f	\N	\N
20300309	2030-03-09	2030	1	3	March	10	9	6	Saturday	t	f	\N	\N
20300310	2030-03-10	2030	1	3	March	10	10	7	Sunday	t	f	\N	\N
20300311	2030-03-11	2030	1	3	March	11	11	1	Monday	f	f	\N	\N
20300312	2030-03-12	2030	1	3	March	11	12	2	Tuesday	f	f	\N	\N
20300313	2030-03-13	2030	1	3	March	11	13	3	Wednesday	f	f	\N	\N
20300314	2030-03-14	2030	1	3	March	11	14	4	Thursday	f	f	\N	\N
20300315	2030-03-15	2030	1	3	March	11	15	5	Friday	f	f	\N	\N
20300316	2030-03-16	2030	1	3	March	11	16	6	Saturday	t	f	\N	\N
20300317	2030-03-17	2030	1	3	March	11	17	7	Sunday	t	f	\N	\N
20300318	2030-03-18	2030	1	3	March	12	18	1	Monday	f	f	\N	\N
20300319	2030-03-19	2030	1	3	March	12	19	2	Tuesday	f	f	\N	\N
20300320	2030-03-20	2030	1	3	March	12	20	3	Wednesday	f	f	\N	\N
20300321	2030-03-21	2030	1	3	March	12	21	4	Thursday	f	f	\N	\N
20300322	2030-03-22	2030	1	3	March	12	22	5	Friday	f	f	\N	\N
20300323	2030-03-23	2030	1	3	March	12	23	6	Saturday	t	f	\N	\N
20300324	2030-03-24	2030	1	3	March	12	24	7	Sunday	t	f	\N	\N
20300325	2030-03-25	2030	1	3	March	13	25	1	Monday	f	f	\N	\N
20300326	2030-03-26	2030	1	3	March	13	26	2	Tuesday	f	f	\N	\N
20300327	2030-03-27	2030	1	3	March	13	27	3	Wednesday	f	f	\N	\N
20300328	2030-03-28	2030	1	3	March	13	28	4	Thursday	f	f	\N	\N
20300329	2030-03-29	2030	1	3	March	13	29	5	Friday	f	f	\N	\N
20300330	2030-03-30	2030	1	3	March	13	30	6	Saturday	t	f	\N	\N
20300331	2030-03-31	2030	1	3	March	13	31	7	Sunday	t	t	\N	\N
20300401	2030-04-01	2030	2	4	April	14	1	1	Monday	f	f	\N	\N
20300402	2030-04-02	2030	2	4	April	14	2	2	Tuesday	f	f	\N	\N
20300403	2030-04-03	2030	2	4	April	14	3	3	Wednesday	f	f	\N	\N
20300404	2030-04-04	2030	2	4	April	14	4	4	Thursday	f	f	\N	\N
20300405	2030-04-05	2030	2	4	April	14	5	5	Friday	f	f	\N	\N
20300406	2030-04-06	2030	2	4	April	14	6	6	Saturday	t	f	\N	\N
20300407	2030-04-07	2030	2	4	April	14	7	7	Sunday	t	f	\N	\N
20300408	2030-04-08	2030	2	4	April	15	8	1	Monday	f	f	\N	\N
20300409	2030-04-09	2030	2	4	April	15	9	2	Tuesday	f	f	\N	\N
20300410	2030-04-10	2030	2	4	April	15	10	3	Wednesday	f	f	\N	\N
20300411	2030-04-11	2030	2	4	April	15	11	4	Thursday	f	f	\N	\N
20300412	2030-04-12	2030	2	4	April	15	12	5	Friday	f	f	\N	\N
20300413	2030-04-13	2030	2	4	April	15	13	6	Saturday	t	f	\N	\N
20300414	2030-04-14	2030	2	4	April	15	14	7	Sunday	t	f	\N	\N
20300415	2030-04-15	2030	2	4	April	16	15	1	Monday	f	f	\N	\N
20300416	2030-04-16	2030	2	4	April	16	16	2	Tuesday	f	f	\N	\N
20300417	2030-04-17	2030	2	4	April	16	17	3	Wednesday	f	f	\N	\N
20300418	2030-04-18	2030	2	4	April	16	18	4	Thursday	f	f	\N	\N
20300419	2030-04-19	2030	2	4	April	16	19	5	Friday	f	f	\N	\N
20300420	2030-04-20	2030	2	4	April	16	20	6	Saturday	t	f	\N	\N
20300421	2030-04-21	2030	2	4	April	16	21	7	Sunday	t	f	\N	\N
20300422	2030-04-22	2030	2	4	April	17	22	1	Monday	f	f	\N	\N
20300423	2030-04-23	2030	2	4	April	17	23	2	Tuesday	f	f	\N	\N
20300424	2030-04-24	2030	2	4	April	17	24	3	Wednesday	f	f	\N	\N
20300425	2030-04-25	2030	2	4	April	17	25	4	Thursday	f	f	\N	\N
20300426	2030-04-26	2030	2	4	April	17	26	5	Friday	f	f	\N	\N
20300427	2030-04-27	2030	2	4	April	17	27	6	Saturday	t	f	\N	\N
20300428	2030-04-28	2030	2	4	April	17	28	7	Sunday	t	f	\N	\N
20300429	2030-04-29	2030	2	4	April	18	29	1	Monday	f	f	\N	\N
20300430	2030-04-30	2030	2	4	April	18	30	2	Tuesday	f	t	\N	\N
20300501	2030-05-01	2030	2	5	May	18	1	3	Wednesday	f	f	\N	\N
20300502	2030-05-02	2030	2	5	May	18	2	4	Thursday	f	f	\N	\N
20300503	2030-05-03	2030	2	5	May	18	3	5	Friday	f	f	\N	\N
20300504	2030-05-04	2030	2	5	May	18	4	6	Saturday	t	f	\N	\N
20300505	2030-05-05	2030	2	5	May	18	5	7	Sunday	t	f	\N	\N
20300506	2030-05-06	2030	2	5	May	19	6	1	Monday	f	f	\N	\N
20300507	2030-05-07	2030	2	5	May	19	7	2	Tuesday	f	f	\N	\N
20300508	2030-05-08	2030	2	5	May	19	8	3	Wednesday	f	f	\N	\N
20300509	2030-05-09	2030	2	5	May	19	9	4	Thursday	f	f	\N	\N
20300510	2030-05-10	2030	2	5	May	19	10	5	Friday	f	f	\N	\N
20300511	2030-05-11	2030	2	5	May	19	11	6	Saturday	t	f	\N	\N
20300512	2030-05-12	2030	2	5	May	19	12	7	Sunday	t	f	\N	\N
20300513	2030-05-13	2030	2	5	May	20	13	1	Monday	f	f	\N	\N
20300514	2030-05-14	2030	2	5	May	20	14	2	Tuesday	f	f	\N	\N
20300515	2030-05-15	2030	2	5	May	20	15	3	Wednesday	f	f	\N	\N
20300516	2030-05-16	2030	2	5	May	20	16	4	Thursday	f	f	\N	\N
20300517	2030-05-17	2030	2	5	May	20	17	5	Friday	f	f	\N	\N
20300518	2030-05-18	2030	2	5	May	20	18	6	Saturday	t	f	\N	\N
20300519	2030-05-19	2030	2	5	May	20	19	7	Sunday	t	f	\N	\N
20300520	2030-05-20	2030	2	5	May	21	20	1	Monday	f	f	\N	\N
20300521	2030-05-21	2030	2	5	May	21	21	2	Tuesday	f	f	\N	\N
20300522	2030-05-22	2030	2	5	May	21	22	3	Wednesday	f	f	\N	\N
20300523	2030-05-23	2030	2	5	May	21	23	4	Thursday	f	f	\N	\N
20300524	2030-05-24	2030	2	5	May	21	24	5	Friday	f	f	\N	\N
20300525	2030-05-25	2030	2	5	May	21	25	6	Saturday	t	f	\N	\N
20300526	2030-05-26	2030	2	5	May	21	26	7	Sunday	t	f	\N	\N
20300527	2030-05-27	2030	2	5	May	22	27	1	Monday	f	f	\N	\N
20300528	2030-05-28	2030	2	5	May	22	28	2	Tuesday	f	f	\N	\N
20300529	2030-05-29	2030	2	5	May	22	29	3	Wednesday	f	f	\N	\N
20300530	2030-05-30	2030	2	5	May	22	30	4	Thursday	f	f	\N	\N
20300531	2030-05-31	2030	2	5	May	22	31	5	Friday	f	t	\N	\N
20300601	2030-06-01	2030	2	6	June	22	1	6	Saturday	t	f	\N	\N
20300602	2030-06-02	2030	2	6	June	22	2	7	Sunday	t	f	\N	\N
20300603	2030-06-03	2030	2	6	June	23	3	1	Monday	f	f	\N	\N
20300604	2030-06-04	2030	2	6	June	23	4	2	Tuesday	f	f	\N	\N
20300605	2030-06-05	2030	2	6	June	23	5	3	Wednesday	f	f	\N	\N
20300606	2030-06-06	2030	2	6	June	23	6	4	Thursday	f	f	\N	\N
20300607	2030-06-07	2030	2	6	June	23	7	5	Friday	f	f	\N	\N
20300608	2030-06-08	2030	2	6	June	23	8	6	Saturday	t	f	\N	\N
20300609	2030-06-09	2030	2	6	June	23	9	7	Sunday	t	f	\N	\N
20300610	2030-06-10	2030	2	6	June	24	10	1	Monday	f	f	\N	\N
20300611	2030-06-11	2030	2	6	June	24	11	2	Tuesday	f	f	\N	\N
20300612	2030-06-12	2030	2	6	June	24	12	3	Wednesday	f	f	\N	\N
20300613	2030-06-13	2030	2	6	June	24	13	4	Thursday	f	f	\N	\N
20300614	2030-06-14	2030	2	6	June	24	14	5	Friday	f	f	\N	\N
20300615	2030-06-15	2030	2	6	June	24	15	6	Saturday	t	f	\N	\N
20300616	2030-06-16	2030	2	6	June	24	16	7	Sunday	t	f	\N	\N
20300617	2030-06-17	2030	2	6	June	25	17	1	Monday	f	f	\N	\N
20300618	2030-06-18	2030	2	6	June	25	18	2	Tuesday	f	f	\N	\N
20300619	2030-06-19	2030	2	6	June	25	19	3	Wednesday	f	f	\N	\N
20300620	2030-06-20	2030	2	6	June	25	20	4	Thursday	f	f	\N	\N
20300621	2030-06-21	2030	2	6	June	25	21	5	Friday	f	f	\N	\N
20300622	2030-06-22	2030	2	6	June	25	22	6	Saturday	t	f	\N	\N
20300623	2030-06-23	2030	2	6	June	25	23	7	Sunday	t	f	\N	\N
20300624	2030-06-24	2030	2	6	June	26	24	1	Monday	f	f	\N	\N
20300625	2030-06-25	2030	2	6	June	26	25	2	Tuesday	f	f	\N	\N
20300626	2030-06-26	2030	2	6	June	26	26	3	Wednesday	f	f	\N	\N
20300627	2030-06-27	2030	2	6	June	26	27	4	Thursday	f	f	\N	\N
20300628	2030-06-28	2030	2	6	June	26	28	5	Friday	f	f	\N	\N
20300629	2030-06-29	2030	2	6	June	26	29	6	Saturday	t	f	\N	\N
20300630	2030-06-30	2030	2	6	June	26	30	7	Sunday	t	t	\N	\N
20300701	2030-07-01	2030	3	7	July	27	1	1	Monday	f	f	\N	\N
20300702	2030-07-02	2030	3	7	July	27	2	2	Tuesday	f	f	\N	\N
20300703	2030-07-03	2030	3	7	July	27	3	3	Wednesday	f	f	\N	\N
20300704	2030-07-04	2030	3	7	July	27	4	4	Thursday	f	f	\N	\N
20300705	2030-07-05	2030	3	7	July	27	5	5	Friday	f	f	\N	\N
20300706	2030-07-06	2030	3	7	July	27	6	6	Saturday	t	f	\N	\N
20300707	2030-07-07	2030	3	7	July	27	7	7	Sunday	t	f	\N	\N
20300708	2030-07-08	2030	3	7	July	28	8	1	Monday	f	f	\N	\N
20300709	2030-07-09	2030	3	7	July	28	9	2	Tuesday	f	f	\N	\N
20300710	2030-07-10	2030	3	7	July	28	10	3	Wednesday	f	f	\N	\N
20300711	2030-07-11	2030	3	7	July	28	11	4	Thursday	f	f	\N	\N
20300712	2030-07-12	2030	3	7	July	28	12	5	Friday	f	f	\N	\N
20300713	2030-07-13	2030	3	7	July	28	13	6	Saturday	t	f	\N	\N
20300714	2030-07-14	2030	3	7	July	28	14	7	Sunday	t	f	\N	\N
20300715	2030-07-15	2030	3	7	July	29	15	1	Monday	f	f	\N	\N
20300716	2030-07-16	2030	3	7	July	29	16	2	Tuesday	f	f	\N	\N
20300717	2030-07-17	2030	3	7	July	29	17	3	Wednesday	f	f	\N	\N
20300718	2030-07-18	2030	3	7	July	29	18	4	Thursday	f	f	\N	\N
20300719	2030-07-19	2030	3	7	July	29	19	5	Friday	f	f	\N	\N
20300720	2030-07-20	2030	3	7	July	29	20	6	Saturday	t	f	\N	\N
20300721	2030-07-21	2030	3	7	July	29	21	7	Sunday	t	f	\N	\N
20300722	2030-07-22	2030	3	7	July	30	22	1	Monday	f	f	\N	\N
20300723	2030-07-23	2030	3	7	July	30	23	2	Tuesday	f	f	\N	\N
20300724	2030-07-24	2030	3	7	July	30	24	3	Wednesday	f	f	\N	\N
20300725	2030-07-25	2030	3	7	July	30	25	4	Thursday	f	f	\N	\N
20300726	2030-07-26	2030	3	7	July	30	26	5	Friday	f	f	\N	\N
20300727	2030-07-27	2030	3	7	July	30	27	6	Saturday	t	f	\N	\N
20300728	2030-07-28	2030	3	7	July	30	28	7	Sunday	t	f	\N	\N
20300729	2030-07-29	2030	3	7	July	31	29	1	Monday	f	f	\N	\N
20300730	2030-07-30	2030	3	7	July	31	30	2	Tuesday	f	f	\N	\N
20300731	2030-07-31	2030	3	7	July	31	31	3	Wednesday	f	t	\N	\N
20300801	2030-08-01	2030	3	8	August	31	1	4	Thursday	f	f	\N	\N
20300802	2030-08-02	2030	3	8	August	31	2	5	Friday	f	f	\N	\N
20300803	2030-08-03	2030	3	8	August	31	3	6	Saturday	t	f	\N	\N
20300804	2030-08-04	2030	3	8	August	31	4	7	Sunday	t	f	\N	\N
20300805	2030-08-05	2030	3	8	August	32	5	1	Monday	f	f	\N	\N
20300806	2030-08-06	2030	3	8	August	32	6	2	Tuesday	f	f	\N	\N
20300807	2030-08-07	2030	3	8	August	32	7	3	Wednesday	f	f	\N	\N
20300808	2030-08-08	2030	3	8	August	32	8	4	Thursday	f	f	\N	\N
20300809	2030-08-09	2030	3	8	August	32	9	5	Friday	f	f	\N	\N
20300810	2030-08-10	2030	3	8	August	32	10	6	Saturday	t	f	\N	\N
20300811	2030-08-11	2030	3	8	August	32	11	7	Sunday	t	f	\N	\N
20300812	2030-08-12	2030	3	8	August	33	12	1	Monday	f	f	\N	\N
20300813	2030-08-13	2030	3	8	August	33	13	2	Tuesday	f	f	\N	\N
20300814	2030-08-14	2030	3	8	August	33	14	3	Wednesday	f	f	\N	\N
20300815	2030-08-15	2030	3	8	August	33	15	4	Thursday	f	f	\N	\N
20300816	2030-08-16	2030	3	8	August	33	16	5	Friday	f	f	\N	\N
20300817	2030-08-17	2030	3	8	August	33	17	6	Saturday	t	f	\N	\N
20300818	2030-08-18	2030	3	8	August	33	18	7	Sunday	t	f	\N	\N
20300819	2030-08-19	2030	3	8	August	34	19	1	Monday	f	f	\N	\N
20300820	2030-08-20	2030	3	8	August	34	20	2	Tuesday	f	f	\N	\N
20300821	2030-08-21	2030	3	8	August	34	21	3	Wednesday	f	f	\N	\N
20300822	2030-08-22	2030	3	8	August	34	22	4	Thursday	f	f	\N	\N
20300823	2030-08-23	2030	3	8	August	34	23	5	Friday	f	f	\N	\N
20300824	2030-08-24	2030	3	8	August	34	24	6	Saturday	t	f	\N	\N
20300825	2030-08-25	2030	3	8	August	34	25	7	Sunday	t	f	\N	\N
20300826	2030-08-26	2030	3	8	August	35	26	1	Monday	f	f	\N	\N
20300827	2030-08-27	2030	3	8	August	35	27	2	Tuesday	f	f	\N	\N
20300828	2030-08-28	2030	3	8	August	35	28	3	Wednesday	f	f	\N	\N
20300829	2030-08-29	2030	3	8	August	35	29	4	Thursday	f	f	\N	\N
20300830	2030-08-30	2030	3	8	August	35	30	5	Friday	f	f	\N	\N
20300831	2030-08-31	2030	3	8	August	35	31	6	Saturday	t	t	\N	\N
20300901	2030-09-01	2030	3	9	September	35	1	7	Sunday	t	f	\N	\N
20300902	2030-09-02	2030	3	9	September	36	2	1	Monday	f	f	\N	\N
20300903	2030-09-03	2030	3	9	September	36	3	2	Tuesday	f	f	\N	\N
20300904	2030-09-04	2030	3	9	September	36	4	3	Wednesday	f	f	\N	\N
20300905	2030-09-05	2030	3	9	September	36	5	4	Thursday	f	f	\N	\N
20300906	2030-09-06	2030	3	9	September	36	6	5	Friday	f	f	\N	\N
20300907	2030-09-07	2030	3	9	September	36	7	6	Saturday	t	f	\N	\N
20300908	2030-09-08	2030	3	9	September	36	8	7	Sunday	t	f	\N	\N
20300909	2030-09-09	2030	3	9	September	37	9	1	Monday	f	f	\N	\N
20300910	2030-09-10	2030	3	9	September	37	10	2	Tuesday	f	f	\N	\N
20300911	2030-09-11	2030	3	9	September	37	11	3	Wednesday	f	f	\N	\N
20300912	2030-09-12	2030	3	9	September	37	12	4	Thursday	f	f	\N	\N
20300913	2030-09-13	2030	3	9	September	37	13	5	Friday	f	f	\N	\N
20300914	2030-09-14	2030	3	9	September	37	14	6	Saturday	t	f	\N	\N
20300915	2030-09-15	2030	3	9	September	37	15	7	Sunday	t	f	\N	\N
20300916	2030-09-16	2030	3	9	September	38	16	1	Monday	f	f	\N	\N
20300917	2030-09-17	2030	3	9	September	38	17	2	Tuesday	f	f	\N	\N
20300918	2030-09-18	2030	3	9	September	38	18	3	Wednesday	f	f	\N	\N
20300919	2030-09-19	2030	3	9	September	38	19	4	Thursday	f	f	\N	\N
20300920	2030-09-20	2030	3	9	September	38	20	5	Friday	f	f	\N	\N
20300921	2030-09-21	2030	3	9	September	38	21	6	Saturday	t	f	\N	\N
20300922	2030-09-22	2030	3	9	September	38	22	7	Sunday	t	f	\N	\N
20300923	2030-09-23	2030	3	9	September	39	23	1	Monday	f	f	\N	\N
20300924	2030-09-24	2030	3	9	September	39	24	2	Tuesday	f	f	\N	\N
20300925	2030-09-25	2030	3	9	September	39	25	3	Wednesday	f	f	\N	\N
20300926	2030-09-26	2030	3	9	September	39	26	4	Thursday	f	f	\N	\N
20300927	2030-09-27	2030	3	9	September	39	27	5	Friday	f	f	\N	\N
20300928	2030-09-28	2030	3	9	September	39	28	6	Saturday	t	f	\N	\N
20300929	2030-09-29	2030	3	9	September	39	29	7	Sunday	t	f	\N	\N
20300930	2030-09-30	2030	3	9	September	40	30	1	Monday	f	t	\N	\N
20301001	2030-10-01	2030	4	10	October	40	1	2	Tuesday	f	f	\N	\N
20301002	2030-10-02	2030	4	10	October	40	2	3	Wednesday	f	f	\N	\N
20301003	2030-10-03	2030	4	10	October	40	3	4	Thursday	f	f	\N	\N
20301004	2030-10-04	2030	4	10	October	40	4	5	Friday	f	f	\N	\N
20301005	2030-10-05	2030	4	10	October	40	5	6	Saturday	t	f	\N	\N
20301006	2030-10-06	2030	4	10	October	40	6	7	Sunday	t	f	\N	\N
20301007	2030-10-07	2030	4	10	October	41	7	1	Monday	f	f	\N	\N
20301008	2030-10-08	2030	4	10	October	41	8	2	Tuesday	f	f	\N	\N
20301009	2030-10-09	2030	4	10	October	41	9	3	Wednesday	f	f	\N	\N
20301010	2030-10-10	2030	4	10	October	41	10	4	Thursday	f	f	\N	\N
20301011	2030-10-11	2030	4	10	October	41	11	5	Friday	f	f	\N	\N
20301012	2030-10-12	2030	4	10	October	41	12	6	Saturday	t	f	\N	\N
20301013	2030-10-13	2030	4	10	October	41	13	7	Sunday	t	f	\N	\N
20301014	2030-10-14	2030	4	10	October	42	14	1	Monday	f	f	\N	\N
20301015	2030-10-15	2030	4	10	October	42	15	2	Tuesday	f	f	\N	\N
20301016	2030-10-16	2030	4	10	October	42	16	3	Wednesday	f	f	\N	\N
20301017	2030-10-17	2030	4	10	October	42	17	4	Thursday	f	f	\N	\N
20301018	2030-10-18	2030	4	10	October	42	18	5	Friday	f	f	\N	\N
20301019	2030-10-19	2030	4	10	October	42	19	6	Saturday	t	f	\N	\N
20301020	2030-10-20	2030	4	10	October	42	20	7	Sunday	t	f	\N	\N
20301021	2030-10-21	2030	4	10	October	43	21	1	Monday	f	f	\N	\N
20301022	2030-10-22	2030	4	10	October	43	22	2	Tuesday	f	f	\N	\N
20301023	2030-10-23	2030	4	10	October	43	23	3	Wednesday	f	f	\N	\N
20301024	2030-10-24	2030	4	10	October	43	24	4	Thursday	f	f	\N	\N
20301025	2030-10-25	2030	4	10	October	43	25	5	Friday	f	f	\N	\N
20301026	2030-10-26	2030	4	10	October	43	26	6	Saturday	t	f	\N	\N
20301027	2030-10-27	2030	4	10	October	43	27	7	Sunday	t	f	\N	\N
20301028	2030-10-28	2030	4	10	October	44	28	1	Monday	f	f	\N	\N
20301029	2030-10-29	2030	4	10	October	44	29	2	Tuesday	f	f	\N	\N
20301030	2030-10-30	2030	4	10	October	44	30	3	Wednesday	f	f	\N	\N
20301031	2030-10-31	2030	4	10	October	44	31	4	Thursday	f	t	\N	\N
20301101	2030-11-01	2030	4	11	November	44	1	5	Friday	f	f	\N	\N
20301102	2030-11-02	2030	4	11	November	44	2	6	Saturday	t	f	\N	\N
20301103	2030-11-03	2030	4	11	November	44	3	7	Sunday	t	f	\N	\N
20301104	2030-11-04	2030	4	11	November	45	4	1	Monday	f	f	\N	\N
20301105	2030-11-05	2030	4	11	November	45	5	2	Tuesday	f	f	\N	\N
20301106	2030-11-06	2030	4	11	November	45	6	3	Wednesday	f	f	\N	\N
20301107	2030-11-07	2030	4	11	November	45	7	4	Thursday	f	f	\N	\N
20301108	2030-11-08	2030	4	11	November	45	8	5	Friday	f	f	\N	\N
20301109	2030-11-09	2030	4	11	November	45	9	6	Saturday	t	f	\N	\N
20301110	2030-11-10	2030	4	11	November	45	10	7	Sunday	t	f	\N	\N
20301111	2030-11-11	2030	4	11	November	46	11	1	Monday	f	f	\N	\N
20301112	2030-11-12	2030	4	11	November	46	12	2	Tuesday	f	f	\N	\N
20301113	2030-11-13	2030	4	11	November	46	13	3	Wednesday	f	f	\N	\N
20301114	2030-11-14	2030	4	11	November	46	14	4	Thursday	f	f	\N	\N
20301115	2030-11-15	2030	4	11	November	46	15	5	Friday	f	f	\N	\N
20301116	2030-11-16	2030	4	11	November	46	16	6	Saturday	t	f	\N	\N
20301117	2030-11-17	2030	4	11	November	46	17	7	Sunday	t	f	\N	\N
20301118	2030-11-18	2030	4	11	November	47	18	1	Monday	f	f	\N	\N
20301119	2030-11-19	2030	4	11	November	47	19	2	Tuesday	f	f	\N	\N
20301120	2030-11-20	2030	4	11	November	47	20	3	Wednesday	f	f	\N	\N
20301121	2030-11-21	2030	4	11	November	47	21	4	Thursday	f	f	\N	\N
20301122	2030-11-22	2030	4	11	November	47	22	5	Friday	f	f	\N	\N
20301123	2030-11-23	2030	4	11	November	47	23	6	Saturday	t	f	\N	\N
20301124	2030-11-24	2030	4	11	November	47	24	7	Sunday	t	f	\N	\N
20301125	2030-11-25	2030	4	11	November	48	25	1	Monday	f	f	\N	\N
20301126	2030-11-26	2030	4	11	November	48	26	2	Tuesday	f	f	\N	\N
20301127	2030-11-27	2030	4	11	November	48	27	3	Wednesday	f	f	\N	\N
20301128	2030-11-28	2030	4	11	November	48	28	4	Thursday	f	f	\N	\N
20301129	2030-11-29	2030	4	11	November	48	29	5	Friday	f	f	\N	\N
20301130	2030-11-30	2030	4	11	November	48	30	6	Saturday	t	t	\N	\N
20301201	2030-12-01	2030	4	12	December	48	1	7	Sunday	t	f	\N	\N
20301202	2030-12-02	2030	4	12	December	49	2	1	Monday	f	f	\N	\N
20301203	2030-12-03	2030	4	12	December	49	3	2	Tuesday	f	f	\N	\N
20301204	2030-12-04	2030	4	12	December	49	4	3	Wednesday	f	f	\N	\N
20301205	2030-12-05	2030	4	12	December	49	5	4	Thursday	f	f	\N	\N
20301206	2030-12-06	2030	4	12	December	49	6	5	Friday	f	f	\N	\N
20301207	2030-12-07	2030	4	12	December	49	7	6	Saturday	t	f	\N	\N
20301208	2030-12-08	2030	4	12	December	49	8	7	Sunday	t	f	\N	\N
20301209	2030-12-09	2030	4	12	December	50	9	1	Monday	f	f	\N	\N
20301210	2030-12-10	2030	4	12	December	50	10	2	Tuesday	f	f	\N	\N
20301211	2030-12-11	2030	4	12	December	50	11	3	Wednesday	f	f	\N	\N
20301212	2030-12-12	2030	4	12	December	50	12	4	Thursday	f	f	\N	\N
20301213	2030-12-13	2030	4	12	December	50	13	5	Friday	f	f	\N	\N
20301214	2030-12-14	2030	4	12	December	50	14	6	Saturday	t	f	\N	\N
20301215	2030-12-15	2030	4	12	December	50	15	7	Sunday	t	f	\N	\N
20301216	2030-12-16	2030	4	12	December	51	16	1	Monday	f	f	\N	\N
20301217	2030-12-17	2030	4	12	December	51	17	2	Tuesday	f	f	\N	\N
20301218	2030-12-18	2030	4	12	December	51	18	3	Wednesday	f	f	\N	\N
20301219	2030-12-19	2030	4	12	December	51	19	4	Thursday	f	f	\N	\N
20301220	2030-12-20	2030	4	12	December	51	20	5	Friday	f	f	\N	\N
20301221	2030-12-21	2030	4	12	December	51	21	6	Saturday	t	f	\N	\N
20301222	2030-12-22	2030	4	12	December	51	22	7	Sunday	t	f	\N	\N
20301223	2030-12-23	2030	4	12	December	52	23	1	Monday	f	f	\N	\N
20301224	2030-12-24	2030	4	12	December	52	24	2	Tuesday	f	f	\N	\N
20301225	2030-12-25	2030	4	12	December	52	25	3	Wednesday	f	f	\N	\N
20301226	2030-12-26	2030	4	12	December	52	26	4	Thursday	f	f	\N	\N
20301227	2030-12-27	2030	4	12	December	52	27	5	Friday	f	f	\N	\N
20301228	2030-12-28	2030	4	12	December	52	28	6	Saturday	t	f	\N	\N
20301229	2030-12-29	2030	4	12	December	52	29	7	Sunday	t	f	\N	\N
20301230	2030-12-30	2030	4	12	December	1	30	1	Monday	f	f	\N	\N
20301231	2030-12-31	2030	4	12	December	1	31	2	Tuesday	f	t	\N	\N
\.


--
-- Data for Name: dim_marketplace; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_marketplace (id, marketplace_code, name, source_type, country_code, operates_in, domain, base_url, api_available, api_type, scraper_type, currency_code, locale, is_active, reliability_score, avg_response_ms, last_scrape_at, last_scrape_status, logo_url, monthly_visits, created_at, updated_at, product_quota, products_in_pool, requires_js, rate_limit_delay, custom_product_link_selector, custom_next_page_selector, custom_price_selector, custom_title_selector, last_discovery_at, last_discovery_status, last_discovery_products_found, discovery_error_count) FROM stdin;
\.


--
-- Data for Name: dim_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_product (id, name, name_normalized, sku_universal, mpn, category_id, brand_id, attributes, image_url, image_urls, hs_code, weight_kg, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dim_seller; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dim_seller (id, name, name_normalized, marketplace_id, external_seller_id, seller_type, store_url, rating, review_count, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fact_commodity_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_commodity_price (id, date_id, symbol, name, commodity_type, price_usd, price_eur, change_24h_pct, change_7d_pct, unit, source, fetched_at) FROM stdin;
\.


--
-- Data for Name: fact_crypto_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_crypto_price (id, date_id, symbol, name, price_usd, price_eur, market_cap_usd, volume_24h_usd, change_1h_pct, change_24h_pct, change_7d_pct, high_24h_usd, low_24h_usd, circulating_supply, total_supply, source, rank, fetched_at) FROM stdin;
\.


--
-- Data for Name: fact_currency_rate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_currency_rate (id, date_id, currency_code, rate_to_eur, rate_to_usd, source, fetched_at) FROM stdin;
\.


--
-- Data for Name: fact_fuel_price; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_fuel_price (id, date_id, country_code, fuel_type, price_local, currency_code, price_eur, change_week_pct, change_month_pct, source, fetched_at) FROM stdin;
\.


--
-- Data for Name: fact_listing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_listing (id, product_id, marketplace_id, seller_id, external_url, external_id, external_name, last_price, last_price_eur, last_original_price, last_currency_code, last_in_stock, last_rating, last_review_count, last_checked_at, scraper_type, scraper_config, scrape_interval_minutes, is_active, consecutive_errors, last_error, created_at, updated_at, url_hash) FROM stdin;
\.


--
-- Data for Name: fact_price_202601; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202601 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202602; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202602 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202603; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202603 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202604; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202604 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202605; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202605 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202606; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202606 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202607; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202607 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202608; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202608 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202609; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202609 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202610; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202610 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202611; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202611 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_price_202612; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_price_202612 (id, listing_id, date_id, price, original_price, currency_code, price_eur, discount_pct, price_change_pct, in_stock, delivery_days, delivery_cost, seller_name, promo_label, is_promoted, promo_type, scraped_at, scrape_job_id) FROM stdin;
\.


--
-- Data for Name: fact_promo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_promo (id, listing_id, marketplace_id, start_date_id, end_date_id, promo_type, promo_name, discount_pct, discount_amount, currency_code, is_marketplace_wide, category_id, detected_at, created_at) FROM stdin;
\.


--
-- Data for Name: fact_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_review (id, listing_id, date_id, rating_avg, review_count, rating_1_count, rating_2_count, rating_3_count, rating_4_count, rating_5_count, sentiment_score, sentiment_summary, new_reviews_24h, scraped_at) FROM stdin;
\.


--
-- Data for Name: fact_search_trend; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_search_trend (id, date_id, country_code, keyword, keyword_normalized, trend_index, search_volume, source, category_id, related_product_id, scraped_at) FROM stdin;
\.


--
-- Data for Name: fact_stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_stock (id, listing_id, date_id, in_stock, stock_quantity, stock_status, delivery_days_min, delivery_days_max, delivery_cost, delivery_type, scraped_at) FROM stdin;
\.


--
-- Data for Name: fact_tariff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fact_tariff (id, hs_code, origin_country, destination_country, duty_pct, vat_pct, excise_pct, trade_agreement, effective_from, effective_to, source, source_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scrape_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scrape_jobs (id, job_type, marketplace_id, status, started_at, completed_at, duration_ms, total_listings, successful, failed, skipped, config, triggered_by, created_at) FROM stdin;
\.


--
-- Data for Name: scrape_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scrape_logs (id, scrape_job_id, listing_id, marketplace_id, status, url, price_found, in_stock_found, duration_ms, response_code, proxy_used, scraper_type, error_message, error_category, retry_count, created_at) FROM stdin;
\.


--
-- Data for Name: user_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_products (id, user_id, product_id, custom_name, custom_sku, target_price, cost_price, currency_code, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_subscriptions (id, user_id, plan, status, started_at, expires_at, cancelled_at, payment_provider, external_id, amount_cents, currency_code, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password_hash, name, company_name, plan, trial_ends_at, language, timezone, ai_tone, default_currency, telegram_chat_id, telegram_link_code, telegram_username, is_superuser, force_password_change, is_active, avatar_url, last_login_at, last_login_ip, login_count, created_at, updated_at, preferences) FROM stdin;
8d9956e3-b04e-4b06-a41e-b06b4e254630	admin@imperecta.com	$2b$12$CA6c5NHWr6yN2suoflpQoe5kgO6xaRBxtpQn.Lq4gxTFWKLwzkMB6	Administrator	\N	pro	\N	en	UTC	balanced	EUR	\N	\N	\N	t	t	t	\N	2026-04-07 02:14:37.57633+00	\N	0	2026-04-07 01:37:36.773962+00	2026-04-07 02:14:37.272664+00	{}
\.


--
-- Name: ai_chat_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ai_chat_messages_id_seq', 1, false);


--
-- Name: alert_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.alert_events_id_seq', 1, false);


--
-- Name: api_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_logs_id_seq', 1, false);


--
-- Name: fact_commodity_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_commodity_price_id_seq', 1, false);


--
-- Name: fact_crypto_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_crypto_price_id_seq', 1, false);


--
-- Name: fact_currency_rate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_currency_rate_id_seq', 1, false);


--
-- Name: fact_fuel_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_fuel_price_id_seq', 1, false);


--
-- Name: fact_price_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_price_id_seq', 1, false);


--
-- Name: fact_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_review_id_seq', 1, false);


--
-- Name: fact_search_trend_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_search_trend_id_seq', 1, false);


--
-- Name: fact_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fact_stock_id_seq', 1, false);


--
-- Name: scrape_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.scrape_logs_id_seq', 1, false);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: alembic_meta; Owner: postgres
--

ALTER TABLE ONLY alembic_meta.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: ai_chat_messages ai_chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_pkey PRIMARY KEY (id);


--
-- Name: ai_chat_sessions ai_chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: alert_events alert_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_logs api_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_pkey PRIMARY KEY (id);


--
-- Name: data_exports data_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_pkey PRIMARY KEY (id);


--
-- Name: digests digests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT digests_pkey PRIMARY KEY (id);


--
-- Name: dim_brand dim_brand_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_brand
    ADD CONSTRAINT dim_brand_pkey PRIMARY KEY (id);


--
-- Name: dim_brand dim_brand_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_brand
    ADD CONSTRAINT dim_brand_slug_key UNIQUE (slug);


--
-- Name: dim_category dim_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_category
    ADD CONSTRAINT dim_category_pkey PRIMARY KEY (id);


--
-- Name: dim_category dim_category_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_category
    ADD CONSTRAINT dim_category_slug_key UNIQUE (slug);


--
-- Name: dim_country dim_country_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_country
    ADD CONSTRAINT dim_country_pkey PRIMARY KEY (country_code);


--
-- Name: dim_currency dim_currency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_currency
    ADD CONSTRAINT dim_currency_pkey PRIMARY KEY (currency_code);


--
-- Name: dim_date dim_date_full_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_date
    ADD CONSTRAINT dim_date_full_date_key UNIQUE (full_date);


--
-- Name: dim_date dim_date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_date
    ADD CONSTRAINT dim_date_pkey PRIMARY KEY (date_id);


--
-- Name: dim_marketplace dim_marketplace_marketplace_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_marketplace
    ADD CONSTRAINT dim_marketplace_marketplace_code_key UNIQUE (marketplace_code);


--
-- Name: dim_marketplace dim_marketplace_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_marketplace
    ADD CONSTRAINT dim_marketplace_pkey PRIMARY KEY (id);


--
-- Name: dim_product dim_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_product
    ADD CONSTRAINT dim_product_pkey PRIMARY KEY (id);


--
-- Name: dim_seller dim_seller_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_seller
    ADD CONSTRAINT dim_seller_pkey PRIMARY KEY (id);


--
-- Name: fact_commodity_price fact_commodity_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_commodity_price
    ADD CONSTRAINT fact_commodity_price_pkey PRIMARY KEY (id);


--
-- Name: fact_crypto_price fact_crypto_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_crypto_price
    ADD CONSTRAINT fact_crypto_price_pkey PRIMARY KEY (id);


--
-- Name: fact_currency_rate fact_currency_rate_date_id_currency_code_source_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_currency_rate
    ADD CONSTRAINT fact_currency_rate_date_id_currency_code_source_key UNIQUE (date_id, currency_code, source);


--
-- Name: fact_currency_rate fact_currency_rate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_currency_rate
    ADD CONSTRAINT fact_currency_rate_pkey PRIMARY KEY (id);


--
-- Name: fact_fuel_price fact_fuel_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_fuel_price
    ADD CONSTRAINT fact_fuel_price_pkey PRIMARY KEY (id);


--
-- Name: fact_listing fact_listing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_listing
    ADD CONSTRAINT fact_listing_pkey PRIMARY KEY (id);


--
-- Name: fact_listing fact_listing_product_id_marketplace_id_seller_id_external_u_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_listing
    ADD CONSTRAINT fact_listing_product_id_marketplace_id_seller_id_external_u_key UNIQUE (product_id, marketplace_id, seller_id, external_url);


--
-- Name: fact_price fact_price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price
    ADD CONSTRAINT fact_price_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202601 fact_price_202601_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202601
    ADD CONSTRAINT fact_price_202601_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202602 fact_price_202602_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202602
    ADD CONSTRAINT fact_price_202602_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202603 fact_price_202603_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202603
    ADD CONSTRAINT fact_price_202603_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202604 fact_price_202604_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202604
    ADD CONSTRAINT fact_price_202604_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202605 fact_price_202605_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202605
    ADD CONSTRAINT fact_price_202605_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202606 fact_price_202606_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202606
    ADD CONSTRAINT fact_price_202606_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202607 fact_price_202607_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202607
    ADD CONSTRAINT fact_price_202607_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202608 fact_price_202608_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202608
    ADD CONSTRAINT fact_price_202608_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202609 fact_price_202609_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202609
    ADD CONSTRAINT fact_price_202609_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202610 fact_price_202610_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202610
    ADD CONSTRAINT fact_price_202610_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202611 fact_price_202611_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202611
    ADD CONSTRAINT fact_price_202611_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_price_202612 fact_price_202612_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_price_202612
    ADD CONSTRAINT fact_price_202612_pkey PRIMARY KEY (id, date_id);


--
-- Name: fact_promo fact_promo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_pkey PRIMARY KEY (id);


--
-- Name: fact_review fact_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_review
    ADD CONSTRAINT fact_review_pkey PRIMARY KEY (id);


--
-- Name: fact_search_trend fact_search_trend_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend
    ADD CONSTRAINT fact_search_trend_pkey PRIMARY KEY (id);


--
-- Name: fact_stock fact_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_stock
    ADD CONSTRAINT fact_stock_pkey PRIMARY KEY (id);


--
-- Name: fact_tariff fact_tariff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_tariff
    ADD CONSTRAINT fact_tariff_pkey PRIMARY KEY (id);


--
-- Name: scrape_jobs scrape_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_jobs
    ADD CONSTRAINT scrape_jobs_pkey PRIMARY KEY (id);


--
-- Name: scrape_logs scrape_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_logs
    ADD CONSTRAINT scrape_logs_pkey PRIMARY KEY (id);


--
-- Name: fact_commodity_price uq_commodity_date_symbol_source; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_commodity_price
    ADD CONSTRAINT uq_commodity_date_symbol_source UNIQUE (date_id, symbol, source);


--
-- Name: fact_crypto_price uq_crypto_date_symbol_source; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_crypto_price
    ADD CONSTRAINT uq_crypto_date_symbol_source UNIQUE (date_id, symbol, source);


--
-- Name: fact_fuel_price uq_fuel_date_country_type_source; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_fuel_price
    ADD CONSTRAINT uq_fuel_date_country_type_source UNIQUE (date_id, country_code, fuel_type, source);


--
-- Name: user_products user_products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_products
    ADD CONSTRAINT user_products_pkey PRIMARY KEY (id);


--
-- Name: user_products user_products_user_id_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_products
    ADD CONSTRAINT user_products_user_id_product_id_key UNIQUE (user_id, product_id);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_fact_price_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_price_date ON ONLY public.fact_price USING btree (date_id);


--
-- Name: fact_price_202601_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202601_date_id_idx ON public.fact_price_202601 USING btree (date_id);


--
-- Name: idx_fact_price_listing_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_price_listing_date ON ONLY public.fact_price USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202601_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202601_listing_id_date_id_idx ON public.fact_price_202601 USING btree (listing_id, date_id DESC);


--
-- Name: idx_fact_price_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_price_listing ON ONLY public.fact_price USING btree (listing_id);


--
-- Name: fact_price_202601_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202601_listing_id_idx ON public.fact_price_202601 USING btree (listing_id);


--
-- Name: idx_fact_price_scraped; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_price_scraped ON ONLY public.fact_price USING btree (scraped_at);


--
-- Name: fact_price_202601_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202601_scraped_at_idx ON public.fact_price_202601 USING btree (scraped_at);


--
-- Name: fact_price_202602_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202602_date_id_idx ON public.fact_price_202602 USING btree (date_id);


--
-- Name: fact_price_202602_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202602_listing_id_date_id_idx ON public.fact_price_202602 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202602_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202602_listing_id_idx ON public.fact_price_202602 USING btree (listing_id);


--
-- Name: fact_price_202602_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202602_scraped_at_idx ON public.fact_price_202602 USING btree (scraped_at);


--
-- Name: fact_price_202603_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202603_date_id_idx ON public.fact_price_202603 USING btree (date_id);


--
-- Name: fact_price_202603_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202603_listing_id_date_id_idx ON public.fact_price_202603 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202603_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202603_listing_id_idx ON public.fact_price_202603 USING btree (listing_id);


--
-- Name: fact_price_202603_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202603_scraped_at_idx ON public.fact_price_202603 USING btree (scraped_at);


--
-- Name: fact_price_202604_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202604_date_id_idx ON public.fact_price_202604 USING btree (date_id);


--
-- Name: fact_price_202604_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202604_listing_id_date_id_idx ON public.fact_price_202604 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202604_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202604_listing_id_idx ON public.fact_price_202604 USING btree (listing_id);


--
-- Name: fact_price_202604_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202604_scraped_at_idx ON public.fact_price_202604 USING btree (scraped_at);


--
-- Name: fact_price_202605_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202605_date_id_idx ON public.fact_price_202605 USING btree (date_id);


--
-- Name: fact_price_202605_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202605_listing_id_date_id_idx ON public.fact_price_202605 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202605_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202605_listing_id_idx ON public.fact_price_202605 USING btree (listing_id);


--
-- Name: fact_price_202605_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202605_scraped_at_idx ON public.fact_price_202605 USING btree (scraped_at);


--
-- Name: fact_price_202606_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202606_date_id_idx ON public.fact_price_202606 USING btree (date_id);


--
-- Name: fact_price_202606_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202606_listing_id_date_id_idx ON public.fact_price_202606 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202606_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202606_listing_id_idx ON public.fact_price_202606 USING btree (listing_id);


--
-- Name: fact_price_202606_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202606_scraped_at_idx ON public.fact_price_202606 USING btree (scraped_at);


--
-- Name: fact_price_202607_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202607_date_id_idx ON public.fact_price_202607 USING btree (date_id);


--
-- Name: fact_price_202607_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202607_listing_id_date_id_idx ON public.fact_price_202607 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202607_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202607_listing_id_idx ON public.fact_price_202607 USING btree (listing_id);


--
-- Name: fact_price_202607_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202607_scraped_at_idx ON public.fact_price_202607 USING btree (scraped_at);


--
-- Name: fact_price_202608_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202608_date_id_idx ON public.fact_price_202608 USING btree (date_id);


--
-- Name: fact_price_202608_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202608_listing_id_date_id_idx ON public.fact_price_202608 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202608_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202608_listing_id_idx ON public.fact_price_202608 USING btree (listing_id);


--
-- Name: fact_price_202608_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202608_scraped_at_idx ON public.fact_price_202608 USING btree (scraped_at);


--
-- Name: fact_price_202609_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202609_date_id_idx ON public.fact_price_202609 USING btree (date_id);


--
-- Name: fact_price_202609_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202609_listing_id_date_id_idx ON public.fact_price_202609 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202609_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202609_listing_id_idx ON public.fact_price_202609 USING btree (listing_id);


--
-- Name: fact_price_202609_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202609_scraped_at_idx ON public.fact_price_202609 USING btree (scraped_at);


--
-- Name: fact_price_202610_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202610_date_id_idx ON public.fact_price_202610 USING btree (date_id);


--
-- Name: fact_price_202610_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202610_listing_id_date_id_idx ON public.fact_price_202610 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202610_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202610_listing_id_idx ON public.fact_price_202610 USING btree (listing_id);


--
-- Name: fact_price_202610_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202610_scraped_at_idx ON public.fact_price_202610 USING btree (scraped_at);


--
-- Name: fact_price_202611_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202611_date_id_idx ON public.fact_price_202611 USING btree (date_id);


--
-- Name: fact_price_202611_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202611_listing_id_date_id_idx ON public.fact_price_202611 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202611_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202611_listing_id_idx ON public.fact_price_202611 USING btree (listing_id);


--
-- Name: fact_price_202611_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202611_scraped_at_idx ON public.fact_price_202611 USING btree (scraped_at);


--
-- Name: fact_price_202612_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202612_date_id_idx ON public.fact_price_202612 USING btree (date_id);


--
-- Name: fact_price_202612_listing_id_date_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202612_listing_id_date_id_idx ON public.fact_price_202612 USING btree (listing_id, date_id DESC);


--
-- Name: fact_price_202612_listing_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202612_listing_id_idx ON public.fact_price_202612 USING btree (listing_id);


--
-- Name: fact_price_202612_scraped_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fact_price_202612_scraped_at_idx ON public.fact_price_202612 USING btree (scraped_at);


--
-- Name: idx_alert_events_alert; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_events_alert ON public.alert_events USING btree (alert_id);


--
-- Name: idx_alert_events_severity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_events_severity ON public.alert_events USING btree (severity);


--
-- Name: idx_alert_events_triggered; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alert_events_triggered ON public.alert_events USING btree (triggered_at);


--
-- Name: idx_alerts_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_active ON public.alerts USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_alerts_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_type ON public.alerts USING btree (alert_type);


--
-- Name: idx_alerts_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_alerts_user ON public.alerts USING btree (user_id);


--
-- Name: idx_api_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_created ON public.api_logs USING btree (created_at);


--
-- Name: idx_api_logs_service; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_service ON public.api_logs USING btree (service);


--
-- Name: idx_api_logs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_status ON public.api_logs USING btree (status);


--
-- Name: idx_api_logs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_api_logs_user ON public.api_logs USING btree (user_id) WHERE (user_id IS NOT NULL);


--
-- Name: idx_brand_normalized; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_brand_normalized ON public.dim_brand USING btree (name_normalized);


--
-- Name: idx_brand_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_brand_slug ON public.dim_brand USING btree (slug);


--
-- Name: idx_category_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_category_parent ON public.dim_category USING btree (parent_id);


--
-- Name: idx_category_path; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_category_path ON public.dim_category USING gin (path public.gin_trgm_ops);


--
-- Name: idx_category_slug; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_category_slug ON public.dim_category USING btree (slug);


--
-- Name: idx_chat_messages_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_messages_created ON public.ai_chat_messages USING btree (created_at);


--
-- Name: idx_chat_messages_session; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_messages_session ON public.ai_chat_messages USING btree (session_id);


--
-- Name: idx_chat_sessions_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_sessions_context ON public.ai_chat_sessions USING btree (context_type, context_id);


--
-- Name: idx_chat_sessions_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_chat_sessions_user ON public.ai_chat_sessions USING btree (user_id);


--
-- Name: idx_commodity_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_commodity_date ON public.fact_commodity_price USING btree (date_id);


--
-- Name: idx_commodity_date_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_commodity_date_symbol ON public.fact_commodity_price USING btree (date_id, symbol);


--
-- Name: idx_commodity_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_commodity_symbol ON public.fact_commodity_price USING btree (symbol);


--
-- Name: idx_crypto_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crypto_date ON public.fact_crypto_price USING btree (date_id);


--
-- Name: idx_crypto_date_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crypto_date_symbol ON public.fact_crypto_price USING btree (date_id, symbol);


--
-- Name: idx_crypto_symbol; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_crypto_symbol ON public.fact_crypto_price USING btree (symbol);


--
-- Name: idx_digests_period; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_digests_period ON public.digests USING btree (period_start, period_end);


--
-- Name: idx_digests_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_digests_type ON public.digests USING btree (digest_type);


--
-- Name: idx_digests_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_digests_user ON public.digests USING btree (user_id);


--
-- Name: idx_dim_date_full_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dim_date_full_date ON public.dim_date USING btree (full_date);


--
-- Name: idx_exports_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_exports_status ON public.data_exports USING btree (status);


--
-- Name: idx_exports_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_exports_user ON public.data_exports USING btree (user_id);


--
-- Name: idx_fact_review_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_review_date ON public.fact_review USING btree (date_id);


--
-- Name: idx_fact_review_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_review_listing ON public.fact_review USING btree (listing_id);


--
-- Name: idx_fact_review_listing_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_review_listing_date ON public.fact_review USING btree (listing_id, date_id DESC);


--
-- Name: idx_fact_stock_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_stock_date ON public.fact_stock USING btree (date_id);


--
-- Name: idx_fact_stock_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_stock_listing ON public.fact_stock USING btree (listing_id);


--
-- Name: idx_fact_stock_oos; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fact_stock_oos ON public.fact_stock USING btree (listing_id, in_stock) WHERE (in_stock = false);


--
-- Name: idx_fuel_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fuel_country ON public.fact_fuel_price USING btree (country_code);


--
-- Name: idx_fuel_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fuel_date ON public.fact_fuel_price USING btree (date_id);


--
-- Name: idx_fuel_date_country_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fuel_date_country_type ON public.fact_fuel_price USING btree (date_id, country_code, fuel_type);


--
-- Name: idx_listing_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listing_active ON public.fact_listing USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_listing_last_checked; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listing_last_checked ON public.fact_listing USING btree (last_checked_at);


--
-- Name: idx_listing_marketplace; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listing_marketplace ON public.fact_listing USING btree (marketplace_id);


--
-- Name: idx_listing_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listing_product ON public.fact_listing USING btree (product_id);


--
-- Name: idx_listing_seller; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_listing_seller ON public.fact_listing USING btree (seller_id);


--
-- Name: idx_listing_url_hash; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_listing_url_hash ON public.fact_listing USING btree (url_hash);


--
-- Name: idx_marketplace_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_code ON public.dim_marketplace USING btree (marketplace_code);


--
-- Name: idx_marketplace_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_country ON public.dim_marketplace USING btree (country_code);


--
-- Name: idx_marketplace_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_marketplace_type ON public.dim_marketplace USING btree (source_type);


--
-- Name: idx_mv_daily_price; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mv_daily_price ON public.mv_daily_price_summary USING btree (date_id, product_id, marketplace_id);


--
-- Name: idx_mv_daily_price_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mv_daily_price_category ON public.mv_daily_price_summary USING btree (category_id);


--
-- Name: idx_mv_daily_price_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mv_daily_price_date ON public.mv_daily_price_summary USING btree (date_id);


--
-- Name: idx_mv_daily_price_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mv_daily_price_product ON public.mv_daily_price_summary USING btree (product_id);


--
-- Name: idx_mv_marketplace_health; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_mv_marketplace_health ON public.mv_marketplace_health USING btree (marketplace_id);


--
-- Name: idx_product_attributes; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_attributes ON public.dim_product USING gin (attributes);


--
-- Name: idx_product_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_brand ON public.dim_product USING btree (brand_id);


--
-- Name: idx_product_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_category ON public.dim_product USING btree (category_id);


--
-- Name: idx_product_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_name ON public.dim_product USING gin (name_normalized public.gin_trgm_ops);


--
-- Name: idx_product_sku; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_product_sku ON public.dim_product USING btree (sku_universal) WHERE (sku_universal IS NOT NULL);


--
-- Name: idx_promo_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_promo_dates ON public.fact_promo USING btree (start_date_id, end_date_id);


--
-- Name: idx_promo_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_promo_listing ON public.fact_promo USING btree (listing_id);


--
-- Name: idx_promo_marketplace; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_promo_marketplace ON public.fact_promo USING btree (marketplace_id);


--
-- Name: idx_promo_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_promo_type ON public.fact_promo USING btree (promo_type);


--
-- Name: idx_rate_currency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_currency ON public.fact_currency_rate USING btree (currency_code);


--
-- Name: idx_rate_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_date ON public.fact_currency_rate USING btree (date_id);


--
-- Name: idx_rate_date_currency; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rate_date_currency ON public.fact_currency_rate USING btree (date_id, currency_code);


--
-- Name: idx_scrape_jobs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_jobs_created ON public.scrape_jobs USING btree (created_at);


--
-- Name: idx_scrape_jobs_marketplace; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_jobs_marketplace ON public.scrape_jobs USING btree (marketplace_id);


--
-- Name: idx_scrape_jobs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_jobs_status ON public.scrape_jobs USING btree (status);


--
-- Name: idx_scrape_logs_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_logs_created ON public.scrape_logs USING btree (created_at);


--
-- Name: idx_scrape_logs_job; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_logs_job ON public.scrape_logs USING btree (scrape_job_id);


--
-- Name: idx_scrape_logs_listing; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_logs_listing ON public.scrape_logs USING btree (listing_id);


--
-- Name: idx_scrape_logs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scrape_logs_status ON public.scrape_logs USING btree (status);


--
-- Name: idx_seller_external; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_seller_external ON public.dim_seller USING btree (marketplace_id, external_seller_id);


--
-- Name: idx_seller_marketplace; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_seller_marketplace ON public.dim_seller USING btree (marketplace_id);


--
-- Name: idx_seller_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_seller_name ON public.dim_seller USING gin (name_normalized public.gin_trgm_ops);


--
-- Name: idx_tariff_effective; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tariff_effective ON public.fact_tariff USING btree (effective_from, effective_to);


--
-- Name: idx_tariff_hs; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tariff_hs ON public.fact_tariff USING btree (hs_code);


--
-- Name: idx_tariff_route; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tariff_route ON public.fact_tariff USING btree (origin_country, destination_country);


--
-- Name: idx_trend_country; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trend_country ON public.fact_search_trend USING btree (country_code);


--
-- Name: idx_trend_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trend_date ON public.fact_search_trend USING btree (date_id);


--
-- Name: idx_trend_keyword; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trend_keyword ON public.fact_search_trend USING gin (keyword_normalized public.gin_trgm_ops);


--
-- Name: idx_trend_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_trend_source ON public.fact_search_trend USING btree (source);


--
-- Name: idx_user_products_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_products_product ON public.user_products USING btree (product_id);


--
-- Name: idx_user_products_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_products_user ON public.user_products USING btree (user_id);


--
-- Name: idx_user_subs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_subs_status ON public.user_subscriptions USING btree (status);


--
-- Name: idx_user_subs_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_subs_user ON public.user_subscriptions USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_plan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_plan ON public.users USING btree (plan);


--
-- Name: idx_users_telegram; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_telegram ON public.users USING btree (telegram_chat_id) WHERE (telegram_chat_id IS NOT NULL);


--
-- Name: fact_price_202601_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202601_date_id_idx;


--
-- Name: fact_price_202601_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202601_listing_id_date_id_idx;


--
-- Name: fact_price_202601_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202601_listing_id_idx;


--
-- Name: fact_price_202601_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202601_pkey;


--
-- Name: fact_price_202601_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202601_scraped_at_idx;


--
-- Name: fact_price_202602_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202602_date_id_idx;


--
-- Name: fact_price_202602_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202602_listing_id_date_id_idx;


--
-- Name: fact_price_202602_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202602_listing_id_idx;


--
-- Name: fact_price_202602_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202602_pkey;


--
-- Name: fact_price_202602_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202602_scraped_at_idx;


--
-- Name: fact_price_202603_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202603_date_id_idx;


--
-- Name: fact_price_202603_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202603_listing_id_date_id_idx;


--
-- Name: fact_price_202603_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202603_listing_id_idx;


--
-- Name: fact_price_202603_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202603_pkey;


--
-- Name: fact_price_202603_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202603_scraped_at_idx;


--
-- Name: fact_price_202604_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202604_date_id_idx;


--
-- Name: fact_price_202604_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202604_listing_id_date_id_idx;


--
-- Name: fact_price_202604_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202604_listing_id_idx;


--
-- Name: fact_price_202604_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202604_pkey;


--
-- Name: fact_price_202604_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202604_scraped_at_idx;


--
-- Name: fact_price_202605_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202605_date_id_idx;


--
-- Name: fact_price_202605_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202605_listing_id_date_id_idx;


--
-- Name: fact_price_202605_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202605_listing_id_idx;


--
-- Name: fact_price_202605_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202605_pkey;


--
-- Name: fact_price_202605_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202605_scraped_at_idx;


--
-- Name: fact_price_202606_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202606_date_id_idx;


--
-- Name: fact_price_202606_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202606_listing_id_date_id_idx;


--
-- Name: fact_price_202606_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202606_listing_id_idx;


--
-- Name: fact_price_202606_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202606_pkey;


--
-- Name: fact_price_202606_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202606_scraped_at_idx;


--
-- Name: fact_price_202607_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202607_date_id_idx;


--
-- Name: fact_price_202607_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202607_listing_id_date_id_idx;


--
-- Name: fact_price_202607_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202607_listing_id_idx;


--
-- Name: fact_price_202607_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202607_pkey;


--
-- Name: fact_price_202607_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202607_scraped_at_idx;


--
-- Name: fact_price_202608_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202608_date_id_idx;


--
-- Name: fact_price_202608_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202608_listing_id_date_id_idx;


--
-- Name: fact_price_202608_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202608_listing_id_idx;


--
-- Name: fact_price_202608_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202608_pkey;


--
-- Name: fact_price_202608_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202608_scraped_at_idx;


--
-- Name: fact_price_202609_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202609_date_id_idx;


--
-- Name: fact_price_202609_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202609_listing_id_date_id_idx;


--
-- Name: fact_price_202609_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202609_listing_id_idx;


--
-- Name: fact_price_202609_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202609_pkey;


--
-- Name: fact_price_202609_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202609_scraped_at_idx;


--
-- Name: fact_price_202610_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202610_date_id_idx;


--
-- Name: fact_price_202610_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202610_listing_id_date_id_idx;


--
-- Name: fact_price_202610_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202610_listing_id_idx;


--
-- Name: fact_price_202610_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202610_pkey;


--
-- Name: fact_price_202610_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202610_scraped_at_idx;


--
-- Name: fact_price_202611_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202611_date_id_idx;


--
-- Name: fact_price_202611_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202611_listing_id_date_id_idx;


--
-- Name: fact_price_202611_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202611_listing_id_idx;


--
-- Name: fact_price_202611_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202611_pkey;


--
-- Name: fact_price_202611_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202611_scraped_at_idx;


--
-- Name: fact_price_202612_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_date ATTACH PARTITION public.fact_price_202612_date_id_idx;


--
-- Name: fact_price_202612_listing_id_date_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing_date ATTACH PARTITION public.fact_price_202612_listing_id_date_id_idx;


--
-- Name: fact_price_202612_listing_id_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_listing ATTACH PARTITION public.fact_price_202612_listing_id_idx;


--
-- Name: fact_price_202612_pkey; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.fact_price_pkey ATTACH PARTITION public.fact_price_202612_pkey;


--
-- Name: fact_price_202612_scraped_at_idx; Type: INDEX ATTACH; Schema: public; Owner: postgres
--

ALTER INDEX public.idx_fact_price_scraped ATTACH PARTITION public.fact_price_202612_scraped_at_idx;


--
-- Name: ai_chat_messages ai_chat_messages_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_messages
    ADD CONSTRAINT ai_chat_messages_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.ai_chat_sessions(id) ON DELETE CASCADE;


--
-- Name: ai_chat_sessions ai_chat_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_chat_sessions
    ADD CONSTRAINT ai_chat_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: alert_events alert_events_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_alert_id_fkey FOREIGN KEY (alert_id) REFERENCES public.alerts(id) ON DELETE CASCADE;


--
-- Name: alert_events alert_events_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alert_events
    ADD CONSTRAINT alert_events_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.dim_category(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dim_country(country_code);


--
-- Name: alerts alerts_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.dim_product(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: api_logs api_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_logs
    ADD CONSTRAINT api_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: data_exports data_exports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_exports
    ADD CONSTRAINT data_exports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: digests digests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.digests
    ADD CONSTRAINT digests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dim_brand dim_brand_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_brand
    ADD CONSTRAINT dim_brand_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dim_country(country_code);


--
-- Name: dim_category dim_category_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_category
    ADD CONSTRAINT dim_category_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.dim_category(id) ON DELETE SET NULL;


--
-- Name: dim_country dim_country_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_country
    ADD CONSTRAINT dim_country_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.dim_currency(currency_code);


--
-- Name: dim_marketplace dim_marketplace_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_marketplace
    ADD CONSTRAINT dim_marketplace_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dim_country(country_code);


--
-- Name: dim_marketplace dim_marketplace_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_marketplace
    ADD CONSTRAINT dim_marketplace_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.dim_currency(currency_code);


--
-- Name: dim_product dim_product_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_product
    ADD CONSTRAINT dim_product_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.dim_brand(id) ON DELETE SET NULL;


--
-- Name: dim_product dim_product_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_product
    ADD CONSTRAINT dim_product_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.dim_category(id) ON DELETE SET NULL;


--
-- Name: dim_seller dim_seller_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dim_seller
    ADD CONSTRAINT dim_seller_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id) ON DELETE CASCADE;


--
-- Name: fact_commodity_price fact_commodity_price_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_commodity_price
    ADD CONSTRAINT fact_commodity_price_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_crypto_price fact_crypto_price_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_crypto_price
    ADD CONSTRAINT fact_crypto_price_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_currency_rate fact_currency_rate_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_currency_rate
    ADD CONSTRAINT fact_currency_rate_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.dim_currency(currency_code);


--
-- Name: fact_currency_rate fact_currency_rate_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_currency_rate
    ADD CONSTRAINT fact_currency_rate_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_fuel_price fact_fuel_price_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_fuel_price
    ADD CONSTRAINT fact_fuel_price_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dim_country(country_code);


--
-- Name: fact_fuel_price fact_fuel_price_currency_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_fuel_price
    ADD CONSTRAINT fact_fuel_price_currency_code_fkey FOREIGN KEY (currency_code) REFERENCES public.dim_currency(currency_code);


--
-- Name: fact_fuel_price fact_fuel_price_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_fuel_price
    ADD CONSTRAINT fact_fuel_price_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_listing fact_listing_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_listing
    ADD CONSTRAINT fact_listing_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id) ON DELETE CASCADE;


--
-- Name: fact_listing fact_listing_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_listing
    ADD CONSTRAINT fact_listing_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.dim_product(id) ON DELETE CASCADE;


--
-- Name: fact_listing fact_listing_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_listing
    ADD CONSTRAINT fact_listing_seller_id_fkey FOREIGN KEY (seller_id) REFERENCES public.dim_seller(id) ON DELETE SET NULL;


--
-- Name: fact_price fact_price_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_price
    ADD CONSTRAINT fact_price_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_price fact_price_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_price
    ADD CONSTRAINT fact_price_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE CASCADE;


--
-- Name: fact_price fact_price_scrape_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.fact_price
    ADD CONSTRAINT fact_price_scrape_job_id_fkey FOREIGN KEY (scrape_job_id) REFERENCES public.scrape_jobs(id);


--
-- Name: fact_promo fact_promo_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.dim_category(id);


--
-- Name: fact_promo fact_promo_end_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_end_date_id_fkey FOREIGN KEY (end_date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_promo fact_promo_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE SET NULL;


--
-- Name: fact_promo fact_promo_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id);


--
-- Name: fact_promo fact_promo_start_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_promo
    ADD CONSTRAINT fact_promo_start_date_id_fkey FOREIGN KEY (start_date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_review fact_review_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_review
    ADD CONSTRAINT fact_review_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_review fact_review_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_review
    ADD CONSTRAINT fact_review_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE CASCADE;


--
-- Name: fact_search_trend fact_search_trend_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend
    ADD CONSTRAINT fact_search_trend_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.dim_category(id);


--
-- Name: fact_search_trend fact_search_trend_country_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend
    ADD CONSTRAINT fact_search_trend_country_code_fkey FOREIGN KEY (country_code) REFERENCES public.dim_country(country_code);


--
-- Name: fact_search_trend fact_search_trend_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend
    ADD CONSTRAINT fact_search_trend_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_search_trend fact_search_trend_related_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_search_trend
    ADD CONSTRAINT fact_search_trend_related_product_id_fkey FOREIGN KEY (related_product_id) REFERENCES public.dim_product(id);


--
-- Name: fact_stock fact_stock_date_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_stock
    ADD CONSTRAINT fact_stock_date_id_fkey FOREIGN KEY (date_id) REFERENCES public.dim_date(date_id);


--
-- Name: fact_stock fact_stock_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_stock
    ADD CONSTRAINT fact_stock_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE CASCADE;


--
-- Name: fact_tariff fact_tariff_destination_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_tariff
    ADD CONSTRAINT fact_tariff_destination_country_fkey FOREIGN KEY (destination_country) REFERENCES public.dim_country(country_code);


--
-- Name: fact_tariff fact_tariff_origin_country_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fact_tariff
    ADD CONSTRAINT fact_tariff_origin_country_fkey FOREIGN KEY (origin_country) REFERENCES public.dim_country(country_code);


--
-- Name: scrape_jobs scrape_jobs_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_jobs
    ADD CONSTRAINT scrape_jobs_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id);


--
-- Name: scrape_jobs scrape_jobs_triggered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_jobs
    ADD CONSTRAINT scrape_jobs_triggered_by_fkey FOREIGN KEY (triggered_by) REFERENCES public.users(id);


--
-- Name: scrape_logs scrape_logs_listing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_logs
    ADD CONSTRAINT scrape_logs_listing_id_fkey FOREIGN KEY (listing_id) REFERENCES public.fact_listing(id) ON DELETE CASCADE;


--
-- Name: scrape_logs scrape_logs_marketplace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_logs
    ADD CONSTRAINT scrape_logs_marketplace_id_fkey FOREIGN KEY (marketplace_id) REFERENCES public.dim_marketplace(id);


--
-- Name: scrape_logs scrape_logs_scrape_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scrape_logs
    ADD CONSTRAINT scrape_logs_scrape_job_id_fkey FOREIGN KEY (scrape_job_id) REFERENCES public.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: user_products user_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_products
    ADD CONSTRAINT user_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.dim_product(id) ON DELETE CASCADE;


--
-- Name: user_products user_products_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_products
    ADD CONSTRAINT user_products_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_subscriptions user_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 5XxcEUzlgIedfZbhmbWRZ0gPYUb2izZQXN3JEhcJSCJ6be3RwJSXeati8bOWqi9

